# 有限事后稳健性核查方案 v1

本方案在已知原研究结果的情况下制定，属于明确标记的事后核查。锁定时间与文件 SHA256 由同目录 `PLAN_LOCK.json` 记录。本次新授权允许另存事后分析；不回写原 SAP，不把新分析追认为原预设研究。

## 固定问题、数据与解释

唯一目标是量化当前 MAIN 结论对一个明确的均值函数扩展、一个区间自由度规则以及抽样 PSU 的依赖，并重新核查四情景的协变量支持。唯一原主比较仍为 MAIN 的标准化绝对差之差 Delta，顺序 P00,P10,P01,P11,RD0,RD1,Delta，先暴露后表型。所有成功、失败和未运行项均报告，不用 p 值筛选，不从新结果中选“更好”主模型。

新增拟合只能读取此次 raw_reproduction 从 DEMO_F、ARQ_F、DPQ_F、PAQ_F 四原始 XPT 重新生成并有来源记录的数据。历史派生数据和结果 RDS 只能用于结果比对，不能作为新增 fit 输入。MAIN 定义、3687 人参考域、MEC 权重、编码、因子参考组、原 S6 分类器及缺失处理均保持原算法。不得为拟合成功删个体、改结局、改阈值或做临时插补。

## 冻结的四项核查

1. `MAIN_QUADRATIC`：只新增一个联合模型 `Y ~ A*G + age10 + I(age10^2) + sex + race + education + PIR + I(PIR^2)`。age10=(age−45)/10，PIR 保留 0–5。预期 rank=15；保留原 reduced-df 规则 min(16,16−rank+1)，故 df=2。四情景仍平均在同一 MAIN MEC 加权经验分布上。使用同样全正 MEC 设计、31 个 JKn、mse=TRUE、replicate-specific reference weighting 和 logit/原尺度 CI 规则。该联合二次项模型检验的是一种有限的线性假设敏感性，不能证明所有非线性、所有交互或模型正确。只有这一个新拟合模型；不试样条、不逐项挑选、不按结果重设次数或阶数。
2. `MAIN_DF16`：使用此次从原始 XPT 重跑所得 MAIN point、原尺度 covariance、logit covariance；只将临界值的 df 从 4 改成 design df=16，保持估计和协方差逐位相同。输出全部 7 量原区间及新规则区间，说明这是区间规则敏感性，不是经验覆盖率验证，不替换原主要区间。
3. `MAIN_PSU_DELETION`：读取此次 MAIN 的全部 31 个重新拟合 JKn estimand 向量。列出各删除 PSU 的 Delta、相对 full Delta 的百分点变化、绝对变化排序以及 `scale*rscale*(Delta_r−Delta)^2` 对保存 Delta 方差的贡献比例。报告所有 31 个，不能据其影响大小删 PSU 或更换模型。它是 jackknife 删除诊断，包含同层重加权与参考分布重加权，不是简单逐人删点、独立验证样本或 31 次主要假设检验。
4. `MAIN_SCENARIO_SUPPORT`：仅对 MAIN，按原 categorical sex×race×education 以及 age10/PIR 坐标重新核查四个情景的支持。固定原 age bins=[20,30),…,[60,70)，PIR cutpoints=−1e−8,1,2,4,5.000001，左闭右开。保存 categorical absent、categorical n<5、fine absent、within-category rectangle/hull outside、nearest standardized Euclidean distance>.5,>1,>2 的共同 MAIN 总 MEC 权重分母比例；SD 使用完整参考人群非加权 SD。几何容差沿用原 1e−9；无分类匹配者 hull=false、nearest=Inf，并留在分母。另列 categorical/fine cell count 和逐人 flag 作为核查附件。不得裁剪参考分布；支持诊断量不是偏倚百分比，不验证 D_PLUS 条件支持或 A_HIGH 支持。

## 失败规则和检查

MAIN_QUADRATIC 全样本及每个 31 重复均要求四 G×A 格有正权重 Y=0/Y=1、正权重矩阵满秩、拟合收敛、无任何拟合 warning、无 boundary、有限系数及四情景逐人有限预测，概率必须严格在 (1e−8,1−1e−8)。按原算法使用 active weights 归一化和 glm.fit quasibinomial，epsilon=1e−10,maxit=100。任一失败即记录 UNSTABLE/NOT_ESTIMABLE，不丢失败重复、不 clipping、不临时调算法；纯工程错误可以另存修正与尝试日志。

成功时保存 full+31 fits、系数、四情景预测、design、full/replicate analysis weights、完整结果 RDS、17 位/hex 标量导出、所有诊断。源数据/代码身份在运行前后核对；运行时记录 sessionInfo。检查全部模型和情景行按 SEQN 对齐、共同参考权重身份、对比矩阵、协方差对称及 expected rank≤4、CI 单位和 df。保存的数据均是此次重新执行的新对象，不填补历史对象身份。

不使用通用独立样本正态性/方差齐性检验作为二元复杂调查模型门控。检验假设、均值函数与支持的限制按该调查设计判断。本次不计算事后 observed power，不做多重插补、IPW、无依据的缺失机制建模、负对照搜寻或未测混杂定量模型。

## 仍不能解决的限制

完整回答者选择、未测混杂、单条目测量、共同自报、S0b 其他部位症状、横断面时序/反向关联和旧周期外推性只能准确披露。所有区间都依赖工作模型、设计近似与规则，没有新的模拟覆盖率证明；复杂调查的较小独立 PSU 数不能被个体 n=3687 替代。

## 方法依据与使用边界

- survey 官方 [`svyglm`](https://r-survey.r-forge.r-project.org/pkgdown/docs/reference/svyglm.html)：说明 quasibinomial 的用途，个体协变量下残差 df 规则可能保守，并允许以设计 df 作 Wald 规则选择。它不直接验证此处非线性标准化 Delta 的特定区间覆盖率。
- survey 官方 [`svrVar`](https://r-survey.r-forge.r-project.org/pkgdown/docs/reference/svrVar.html)：mse=TRUE 使用 full estimate 居中，结合 scale/rscales 汇总复制估计；这里用于保持既定 JKn 算法。
- Lumley 2004, [Analysis of Complex Survey Samples](https://www.jstatsoft.org/article/view/v009i08), doi:10.18637/jss.v009.i08：复杂抽样设计/复制权重和方差估计的原始软件论文。
- CDC [NHANES variance estimation tutorial](https://wwwn.cdc.gov/nchs/nhanes/tutorials/varianceestimation.aspx)：强调层/PSU 和设计权重、域分析及设计自由度；当前 NCHS 通常推荐 Taylor 线性化，本核查保留原研究已指定的 JKn，不把 CDC 对线性化的建议转写为对该 JKn 标准化区间的专门背书。

访问日期为本次执行日期。`as.svrepdesign`/`svrepdesign` 官方网页本次工具请求超时，不能列为已成功网页阅读；本地安装 survey 的函数/帮助与已成功读取的 `svrVar`、`svyglm` 文档可作为实现依据。
