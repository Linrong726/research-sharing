# NHANES 2009–2010 analysis reconstruction

Version: **v1.4.8-reproduction-r1**, 18 September 2026. Related manuscript: *Little interest or pleasure and recreational physical activity nonparticipation across questionnaire-defined lumbar symptom phenotypes: a cross-sectional NHANES 2009–2010 analysis*.

This package reconstructs the four adjusted analyses, the unadjusted comparison, descriptive tables, flow/missingness tables and 42 specified routing queries from four official public NHANES XPT files. It also runs four explicitly post hoc robustness checks. New outputs are stored in separately identified `REPRODUCTION_NEW` runs and provenance records. Original historical objects that were not located have not been recovered.

## Run

Install Python 3.9 or later and R 4.6.1 with the package versions in `docs/ENVIRONMENT.md`. Python uses only its standard library. From the extracted package directory, run:

```text
python code/run_all.py --out NEW_OUTPUT_DIRECTORY --rscript PATH_TO_RSCRIPT --lib PATH_TO_R_LIBRARY
```

Omit `--lib` if the pinned packages are installed in the normal R library; omit `--rscript` if Rscript is on PATH. The output directory must not already exist. The script downloads and verifies the four CDC files. To use existing files, add `--raw-dir DIRECTORY_CONTAINING_FOUR_XPT_FILES`; the same source-identity checks apply. Use a new output directory for every run.

The program performs these steps sequentially: package/version check, source SHA256 validation, four adjusted branches (128 fits), lossless aggregate export, two saved-object audits including an independent arithmetic implementation, unadjusted/descriptive/flow analyses, S12 routing queries, fixed post hoc robustness checks (32 additional fits), and comparison with the delivered aggregate reference files. Historical results do not enter any fit. The `expected/` files are read only by the final comparison step. A nonzero exit or a FAIL receipt requires investigation.

Check `NEW_OUTPUT_DIRECTORY/execution/PIPELINE_RECEIPT.json` and `aggregate_comparison/COMPARISON_RECEIPT.json`. The generated output includes participant-indexed data, survey objects, weights, fitted objects and scenario predictions for local audit; it is not the same as the curated external package.

## What was reproduced

The original four adjusted branches used 3,687 participants (MAIN and A_HIGH) or 3,686 (D_BASE and D_PLUS). In two fresh R-session reconstructions, all 28 estimates and intervals, all 31×7 replicate vectors per branch and the saved covariance matrices matched historical binary results exactly. New saved objects passed 396 checks; a separate implementation of matrix, weight, score, standardization, covariance and interval arithmetic passed 788 checks. Independent post hoc and adjusted data derivations also agreed.

Thirty-one descriptive/post hoc CSV comparisons covered 11,566 fields: no substantive mismatches, with 445 differences attributable only to documented historical 15-significant-digit output rounding. Historical descriptive CSV compatibility is not described as historical binary equality. S12's 42 specified queries were separately reconstructed and matched their recorded zero counts and denominators. Figure numerical sources were reconstructed; the Word layout and embedded images were not re-rendered. S11 records historical chronology and is not derivable from raw observations.

These are computational reproduction checks on the same Windows/R environment, using newly downloaded files and separate code/output directories. They are not an independent study, a cross-platform validation or proof of interval coverage. The original estimator's pure numerical functions are transparently included; independent arithmetic checks reduce, but do not eliminate, the possibility of shared implementation assumptions.

## Fixed post hoc checks

The plan in `plan/robustness/` was locked before obtaining the new robustness results, with the original manuscript results already known. It is not a preregistration of the original study. The only additional mean model adds age10² and PIR² together. The other checks change only the interval degrees of freedom, inspect all 31 PSU deletions, and recalculate scenario support.

| Analysis | Delta (percentage points) | 95% CI (percentage points) | CI df |
|---|---:|---:|---:|
| Original MAIN specification | 8.7014 | −7.4922 to 24.8950 | 4 |
| MAIN, design-df interval sensitivity | 8.7014 | −3.6629 to 21.0658 | 16 |
| Joint age/PIR quadratic model | 9.2290 | −15.3545 to 33.8125 | 2 |

All intervals include zero. The quadratic model changes both rank and residual df; its interval-width change is not attributable solely to nonlinearity. The support checks still show substantial extrapolation. These analyses do not remove complete-responder selection, unmeasured confounding, measurement error, reverse association or the limits of a historical cross-sectional survey cycle.

## Files and access boundary

`code/` contains portable computation and verification scripts; `expected/` contains machine-readable aggregate output; `plan/` contains the frozen post hoc plan; `docs/` documents definitions, evidence and boundaries. `PACKAGE_MANIFEST.json` records every distributed file's SHA256. The publication candidate contains no raw XPT files, participant-indexed RDS files, full individual weight matrices, individual predictions, original Word files, credentials or local runtime libraries. Public raw files are obtained from CDC by the included downloader.

Some flow and support summaries contain small cells, including n=1. Such summaries can sometimes be linked to the already public NHANES files; absence of SEQN is not a guarantee of anonymity. Detailed individual audit objects are regenerated locally rather than redistributed in this package.

This is a prepared release candidate, not evidence of an existing public deposit or DOI. The manuscript's availability statement must use a verified repository/Additional-file location after actual upload. No author approval or new reuse licence is asserted by this package.
