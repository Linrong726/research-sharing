# Data, definitions and result schema

Four public NHANES 2009–2010 modules are the only raw scientific inputs:

| Module | Role | Official documentation |
|---|---|---|
| DEMO_F | demographics, SEQN, MEC weight, masked strata/PSUs | [DEMO_F](https://wwwn.cdc.gov/Nchs/Data/Nhanes/Public/2009/DataFiles/DEMO_F.htm) |
| ARQ_F | lumbar history, sites, current status and episode history | [ARQ_F](https://wwwn.cdc.gov/Nchs/Data/Nhanes/Public/2009/DataFiles/ARQ_F.htm) |
| DPQ_F | DPQ010 interest/pleasure and DPQ020 depressed mood | [DPQ_F](https://wwwn.cdc.gov/Nchs/Data/Nhanes/Public/2009/DataFiles/DPQ_F.htm) |
| PAQ_F | PAQ650/PAQ665 recreational participation | [PAQ_F](https://wwwn.cdc.gov/Nchs/Data/Nhanes/Public/2009/DataFiles/PAQ_F.htm) |

`code/download_nhanes.py` contains exact official XPT URLs, byte counts and frozen SHA256 values. It rejects changed payloads and HTML error pages. The fresh-download receipt records the actual download separately from historical provenance.

DEMO is the left-hand population; each module joins one-to-one on SEQN after duplicate/missing-key checks. The full positive MEC design has 10,253 participants, 15 strata and 31 PSUs. Domain restriction follows full-design construction. The analysis flow is 10,537 DEMO records → 5,106 age-eligible → 5,001 module-linked → 5,001 positive MEC → 4,625 S0/S3 candidates → 4,052 known A and Y → 3,687 complete covariates; D-known has 3,686.

A is DPQ010 1–3 versus 0; A_HIGH is 2–3 versus 0–1. D is DPQ020 1–3 versus 0. G=1 denotes current lumbar symptoms within the qualifying history screen, with a history of an episode lasting at least three months (S3). G=0 denotes no reported lumbar symptoms satisfying the six-week history screening criterion (S0, comprising S0a and S0b). S3 does not establish that the current episode lasted three months, and S0 is not a pain-free control. The retained routing classifier detects only its implemented conflicts, not every possible questionnaire contradiction. Unknown values remain unknown.

For Y, either participation item equal to 1 establishes participation (Y=0) even if the other is unknown; both equal to 2 establish nonparticipation (Y=1); other legal unknown combinations remain unknown. Illegal substantive codes are rejected. age10=(age−45)/10. Sex has two fixed levels, race/ethnicity five and education three. PIR is continuous on the released 0–5 range. Coding and missing-value rules are executable in the included derivation functions.

MAIN and D_BASE use Y ~ A*G + age10 + sex + race + education + PIR. D_PLUS additionally adjusts for D on the identical D-known domain/reference rows. A_HIGH replaces both A terms. Each full/replicate fit predicts four scenarios over the corresponding weighted common reference distribution, using replicate-specific reference weights. JKn uses 31 deletions, mse=TRUE, scale=1, 28 rscales of 1/2 and three of 2/3. Original CI df are 4,4,3,4 for MAIN,D_BASE,D_PLUS,A_HIGH; UNADJ uses df=16.

The ordered vector is P00,P10,P01,P11,RD0,RD1,Delta. The first subscript is A, the second G. RD0=P10−P00, RD1=P11−P01 and Delta=RD1−RD0. Probabilities are stored as proportions; contrasts are stored in probability units. Multiplying by 100 gives percentages or percentage points respectively. Probability CIs use replicate-logit calculations; contrast CIs use the joint covariance on their original scale and are not clipped. UNADJ observed-cell proportions do not standardize to the common covariate distribution.

`adjusted_exact/all_numeric_values_exact.csv` is a long table with object, row/column indices and labels, 17-digit decimal values and hexadecimal binary64 values. Python float.fromhex can read hex values losslessly. `all_28_estimates_CIs_exact.csv` is the companion wide table. `expected/posthoc/results/` holds 17-digit new exports, including all flow and missingness denominators. The original descriptive exports had only approximately 15 significant digits; their historical comparison explicitly accounts for that saved precision. NA is not zero.

Full new design objects, combined.weights/degf fields, individual full/replicate weights, 128 original-specification fits, 32 quadratic-model fits and individual scenario predictions are generated under the run directory. They establish a new examinable execution chain. They do not change the identity or existence of missing historical objects (DES06, DES09, DES11 and archive audit label S10, which is distinct from Table S10).
