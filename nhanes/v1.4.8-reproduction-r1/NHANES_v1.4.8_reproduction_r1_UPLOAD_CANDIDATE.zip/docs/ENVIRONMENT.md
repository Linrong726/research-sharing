# Tested environment and dependency lock

Actual verification used Windows 10 x64, Python 3.12.14, R 4.6.1 (ucrt), default matrix products and LAPACK 3.12.1. Numerical thread counts were set to one. Python needs no external packages. No cloud service or historical analysis directory is required to compute the results.

| R package | Version returned by packageVersion |
|---|---|
| foreign | 0.8.91 |
| survey | 4.5 |
| Matrix | 1.7.5 |
| survival | 3.8.6 |
| DBI | 1.3.0 |
| mitools | 2.7 |
| Rcpp | 1.1.2 |
| minqa | 1.2.8 |
| numDeriv | 2016.8.1.1 |
| RcppArmadillo | 15.6.0.1 |

R package DESCRIPTION files can display hyphens where packageVersion returns dots, for example Matrix 1.7-5. Base and recommended R packages, including lattice 0.22-9, came with this R installation. Keep the same R distribution for the closest numerical comparison. The checker rejects differing R or listed package versions rather than silently substituting a newer environment.

Install R from the [R Project](https://www.r-project.org/) and packages from [CRAN](https://cran.r-project.org/). If a required version has moved from the current repository, obtain that exact version from its CRAN package archive; follow the [R installation manual](https://cran.r-project.org/doc/manuals/r-release/R-admin.html) for platform-specific source compilation. Compiled source packages may require the matching system toolchain. This bundle does not redistribute an R executable or third-party package binaries and does not claim that a clean installation on another machine has been tested.

For the local clean-directory check, the seven non-base package directories were copied into a separate library; computation used that library plus R's standard distribution. No historical participant or result objects were copied into the computational inputs. The raw data were newly downloaded from CDC. All source and output identities and actual session information remain in the local audit archive.

The local Windows runtime emitted C.UTF-8 locale startup warnings, then proceeded with its recorded locale. These were distinct from model-fitting warnings; fitted branches and independent checks passed. Preserve diagnostics on another system and investigate mismatches before changing thresholds.
