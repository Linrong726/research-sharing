# 调整模型复现代码的最终独立算术审阅

审阅日期：2026-09-18。审阅范围为当前四分支复现代码、新派生输入、新保存模型对象与既定原规则；不更改生产或复现代码，不新增拟合。

**结论：未发现变量定义、抽样设计、复制权重、标准化、对比方向或区间自由度相对于既定原规则的实质偏离。** 除既有 396 项保存对象检查外，本次用不加载原 estimator 的独立算术脚本完成 **788 项检查，全部通过**。

## 已独立核对的机制

| 机制 | 审阅结果 |
|---|---|
| 原始数据和联接 | 输入为四份 XPT，以唯一 SEQN 左连接至 DEMO；未将旧 derived RDS 或旧拟合结果作为科学输入 |
| 人群与分组 | 20–69 岁；最终 G=1 为 S3、G=0 为 S0；中间 Phase 1 的 S3/S1 变量在纯派生函数中移至带 `phase1_` 前缀字段，不用于新四分支 |
| A、A_high、D、Y | A=DPQ010 1–3 对 0；A_high=2–3 对 0–1；D=DPQ020 1–3 对 0；Y 仅依据休闲活动参与门项，保留原未知码与路由逻辑 |
| 协变量与因子 | age10=(年龄−45)/10，性别与种族固定参考水平，教育三分类及 PIR 范围与原代码一致；独立 `stats::model.matrix` 与保存预测一致 |
| 完整设计与域 | 使用全部 10253 个有效正 MEC 权重行建立设计后作域分析；各模型域完整覆盖 15 个 strata/31 个 PSU，设计 df=16 |
| 重复权重 | 逐一核对 31 次删除一个 PSU、同层剩余 PSU 按 k/(k−1) 放大、其余层不变；rscale=(k−1)/k，mse=TRUE，scale=1 |
| 模型方程 | 原始四分支列数/秩为 13，D_PLUS 为 14；128 次保存拟合的加权 logistic score 最大绝对值为 5.3030×10⁻¹¹（已除总权重），小于预设 10⁻⁸ |
| 归一化 | 保存 `glm.fit` 的 prior.weights 精确等于当前拟合正权重除其均值；此常数归一化不改变目标方程 |
| 标准化 | 逐次使用该次实际分析权重，对整个共同域内的四种 A/G 情景预测加权平均；不存在固定全样本权重代替重复参考权重的错误 |
| 对比方向 | 独立直接算术 RD0=P10−P00、RD1=P11−P01、Delta=RD1−RD0 与输出一致 |
| 协方差 | 独立累加 31 个 `scale*rscale*outer(rep−full,rep−full)`，不调用原 covariance 函数；与保存矩阵最大差为 2.1684×10⁻¹⁸，属运算顺序浮点误差 |
| CI | df=min(16,16−rank+1)，所以主分支 df=4、D_PLUS df=3；前四概率采用 logit 尺度 JKn 方差及 t 临界值，后三对比为未变换 t 区间；独立区间差最大 5.5511×10⁻¹⁷ |
| 保存仪器化 | `on.exit` 仅增加输出序列化；不替代数值计算或返回值。拟合器和原变量纯函数复制文件 SHA-256 与原件一致 |

## 需要准确表述、但不构成实质偏离的细节

**原 XPT 权重和 survey 实际 sampling weights 不应宣称逐位相同。** `survey` 内部以抽样概率及其倒数表示权重，产生浮点往返舍入：完整 10253 行中 1307 行的 double 表示有差异，最大绝对差 1.4551915×10⁻¹¹；主分析域其中 502 行。旧 engine 和新重建都使用同一实际 design sampling weight 路径，二者模型 reference 则逐位相同，因此这不是权重口径变化，也不应人为把新计算权重改为 raw 权重“纠正”它。

`data/D_common_reference_inputs.rds` 是 D_BASE/D_PLUS 的**输入**共同参考信息，里面的 WTMEC2YR 为原输入值。核对实际拟合或标准化权重时，应使用 `models/MODEL/analysis_weights.rds`、`complete_result.rds$reference` 或保存设计对象的 sampling weights；本次已保留逐行十六进制舍入差异证据。

当前 36 组历史结果比较证明当前运行与保留历史结果的数值身份；788 项独立算术复核进一步减少了“同一 engine 自证”的缺口。独立算术使用 R 基础线性代数与模型矩阵，不是另一个统计软件包的完全独立重实现。尤其是 phenotype 路由函数的科学合理性仍依赖问卷原义与既定分析计划，不因输出匹配自动得到验证。

## 尚不能由这项复现解决的边界

- 新保存的拟合、设计及预测对象是可审查的新对应物；不能据此声称已找回历史缺件。
- 这次验证限定于当前公开 XPT 内容、既定变量口径和所记录 R/包环境。主流程随后使用重新下载 XPT、单独复制的代码及 R 包库完成不带历史 baseline 的干净重放；跨操作系统/软件版本的逐位一致性尚未验证。
- 宽 CI、低有效自由度、横断面关联、反向因果、自报误差、完整案例选择和残余混杂均为科学局限；复现一致不等于已消除这些局限。
- 本审阅未把事后模型用于替换原四分支结果，新增稳健性结果应单独标记事后性质。

## 证据文件

`audit/adjusted/review_independent_arithmetic.R` 是本次独立审阅脚本；它不加载旧 estimator、不加载历史模型且不调用拟合函数。

- `audit/adjusted/independent_review/review_independent_arithmetic_checks.csv`：788 项独立核对。
- `audit/adjusted/independent_review/raw_to_actual_sampling_weight_roundoff.csv`：原始与实际 sampling weights 的逐行舍入差异和无损十六进制值。
- `audit/adjusted/saved_object_audit/saved_object_independent_checks.csv`：先前 396 项保存对象验证。
- `runs/adjusted/local_raw/audit/historical_comparison_checks.csv`：36 组历史结果比较。
- `audit/adjusted/vendor_source_identity.csv`：原纯函数及 engine 复制身份。

可对任意新复放目录再作本审阅，无须重拟合：

```text
Rscript --vanilla audit/adjusted/review_independent_arithmetic.R NEW_RUN_DIRECTORY NEW_REVIEW_DIRECTORY
```

## 干净重放后的复核补记

对 `cleanroom/runs/adjusted` 已在单独审计目录再次完成：36 组历史比较全部逐位相同、396 项保存对象核对全部通过、788 项不加载原 engine 的独立算术检查全部通过。没有重拟合或修改新模型输出。

另新增只读导出器 `code/adjusted/export_exact_adjusted.R NEW_RUN NEW_EMPTY_EXPORT_OUT`，从新 RDS 导出 point、CI、31×7 replicate、7×7 covariance 和 4×4 logit covariance 共 1268 个值，均含 `%.17g` 十进制及 `%a` 十六进制。20 组逐值反读检查确认两种表达均能无损恢复源 double。该导出器不修改原 15 位阅读用 CSV，也不读取历史对象。

新证据位置：

- `audit/adjusted/cleanroom_historical_comparison/historical_comparison_checks.csv`
- `audit/adjusted/cleanroom_saved_objects/saved_object_independent_checks.csv`
- `audit/adjusted/cleanroom_independent_review/review_independent_arithmetic_checks.csv`
- `cleanroom/exact_exports/adjusted/all_numeric_values_exact.csv`
- `cleanroom/exact_exports/adjusted/all_28_estimates_CIs_exact.csv`
- `cleanroom/exact_exports/adjusted/exact_roundtrip_checks.csv`
