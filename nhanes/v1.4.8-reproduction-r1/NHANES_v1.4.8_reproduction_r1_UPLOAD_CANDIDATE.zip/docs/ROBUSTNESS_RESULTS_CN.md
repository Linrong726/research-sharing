# 有限事后稳健性核查结果

最终成功路径为 `runs/robustness/run004/`。本轮仅拟合方案中锁定的一个年龄/PIR联合二次项模型，所有 32 个 full+JKn 拟合均通过；四项计划检查全部完成，14 项实现检查通过。新增数据输入来自本轮四原始 XPT 重建，未使用历史派生 RDS 作为拟合输入。原 MAIN 仍是唯一主比较，原稿和原 SAP 未修改。

## 结果

| 分析 | Delta（百分点） | 95% CI（百分点） | CI df |
|---|---:|---:|---:|
| 原规格 MAIN，本轮原始数据复现 | 8.7014 | -7.4922 至 24.8950 | 4 |
| MAIN，只有区间规则改为设计 df | 8.7014 | -3.6629 至 21.0658 | 16 |
| MAIN_QUADRATIC，age10² 与 PIR² 一并加入 | 9.2290 | -15.3545 至 33.8125 | 2 |

二次项模型相对原规格的点估计变化为 0.5276 个百分点；rank 从 13 增到 15，按同一 reduced-df 规则，区间 df 从 4 减到 2。因此该模型的区间宽度同时反映方差和自由度改变，不能把宽度差单独解释为非线性影响。四情景逐人预测在全部 32 次拟合中处于约 0.1071–0.9239，没有触发原数值边界、收敛或拟合警告规则。

三套 Delta 区间均包含零。加入这一种二次项后点估计变化较小，仅支持对此项有限函数扩展的数值稳定性；不能证明所有模型设定、剩余混杂或选择偏倚无关紧要，也不能声称两个表型关联相同。df=16 的区间较窄，但这是区间规则的事后敏感性展示，不证明真实覆盖率、不替换原主要区间。

31 个新 JKn 删除估计的 Delta 范围为 5.5184–12.2279 个百分点。绝对变化最大为删除 masked stratum 80、PSU 1 后增加 3.5265 个百分点，该重复对保存 Delta 方差的贡献为 18.28%；删除同层 PSU 2 后变化 -3.1830 个百分点。全部 31 个结果均保留，未删 PSU，也未把这些同层重加权/参考分布重加权后的重复当独立检验。

四情景支持重新计算与历史汇总 CSV 在 1e−10 绝对精度内一致。S3/A=1 情景的共同参考权重中，49.70% 无相同细分 age/PIR 组合、45.81% 在对应分类组的 age/PIR 凸包外；S3/A=0 对应 33.14% 和 36.48%。这再次显示模型依赖外推，不能被二次项点估计相近所消除。所有比例使用同一 MAIN 总 MEC 权重分母，条件可重叠，不可相加；未做任何裁剪或改参考群体。

## 数值与历史边界

同一 MAIN 成员及新 survey 对象实际 sampling weights 与新 MAIN reference 逐位一致。原始 WTMEC2YR 字段到 survey 对象 sampling weight 的逆概率往返产生 502 个二进制浮点差异，最大绝对差 1.4551915228366852e−11；这是约一个机器末位的数值现象，未改变既定权重算法。原始字段、实际模型权重和理论相同权重不能混称位级相等。完整记录见 `WEIGHT_FLOATING_POINT_ROUNDTRIP.csv`。

本轮保存新二次项设计、完整权重、32 拟合对象、系数与逐人四情景预测，是本轮新生成的可核查对象；不冒充历史对象恢复。个体文件在 `run004/individual/`，须与汇总公开材料分层。区间覆盖率、缺失机制、未测混杂、测量误差、横断面时序和旧周期外推性没有被本轮消除。

## 完整尝试记录

1. `run001`：在任何新增拟合前，过强的原始权重/实际 survey 权重位级相等断言触发失败。改为核对实际新 survey 权重与实际新 MAIN reference，并单列上述往返误差。输入前后哈希一致。
2. `run002`：32 个二次项拟合成功且完整新结果 RDS 已保存；随后无 rownames 的矩阵在 CSV 导出时报 0/31 行错误。通用异常处理当时把该工程错误记为 UNSTABLE；该原记录保留，但不是统计不稳定判定。
3. `exportfix003`：仅从 run002 已保存的新 RDS 修复矩阵 row_key 导出，未拟合或重算统计；保存 `ANALYSIS_STATUS_RECONCILED.csv` 纠正上一记录的分类。修复输入哈希不变。
4. `run004`：同一方案、同一模型和同一数据，对修复后的整条可运行路径作验证；四项全部 SUCCESS，输入前后哈希一致。6 份二次项精确输出文件与 exportfix003 字节 SHA 全部一致。没有因结果选择模型、重试阈值或丢弃失败复制。

上述启动日志中的 C.UTF-8 locale warning 属于运行环境；不是拟合 warning。计划、执行锁、源码版本快照和每次 stdout/stderr 全部保留于 `plan/robustness/`、`audit/robustness/` 与各 run 目录。

## 方法依据

survey 官方 [svyglm 文档](https://r-survey.r-forge.r-project.org/pkgdown/docs/reference/svyglm.html) 解释残差 df 对个体协变量可能保守，也列出设计 df 的选项；此说明针对回归 Wald 推断，并不自动验证本研究非线性标准化 Delta。官方 [svrVar 文档](https://r-survey.r-forge.r-project.org/pkgdown/docs/reference/svrVar.html) 说明 mse=TRUE 的 full-estimate 居中与 scale/rscales，和本轮保持的 JKn 运算相符。软件基本方法参见 [Lumley 2004](https://www.jstatsoft.org/article/view/v009i08)。

CDC [NHANES variance estimation tutorial](https://wwwn.cdc.gov/nchs/nhanes/tutorials/varianceestimation.aspx) 强调先保留全设计再做域分析及按 PSU/strata 判断自由度；其当前通常推荐 Taylor 线性化。本轮为保持原分析算法而保留 JKn，没有将此教程视为对该特定 JKn 区间覆盖率的认证。

## 使用文件

机器索引为 `audit/robustness/ROBUSTNESS_SUMMARY.json`，含文件 SHA256、分享分层和依赖路径。最终表为 `run004/MAIN_QUADRATIC_estimates.csv`、`MAIN_DF16_intervals.csv`、`MAIN_PSU_deletion_influence.csv`、`MAIN_scenario_support_summary.csv`。准确的二进制数值还保存为 RDS 与 hex CSV；不得从论文舍入值反推。

当前重跑入口为 `code/robustness/execute_portable.py`，用显式 `--adjusted-run`、`--core-code`、`--output` 传入本轮干净的 adjusted 复现目录、数值内核和新输出目录；具体命令、R 环境与包内相对方案路径见 `code/robustness/README_PORTABLE.md`。可选 `--support-baseline` 只比较保存的支持汇总；省略时不读取旧工作区，仍完整计算本轮支持诊断。`execute_locked.py`、`execute_export_repair.py` 与 `summarize_robustness.py` 留作本报告各次历史执行的追溯记录，不能作为当前可移植入口。此入口调整未改动本报告数值、冻结方案或已保存 run004 输出。

公共清单中的 categorical/fine support counts 可能含 n=1 的小单元。它们没有 SEQN 或逐人行，但可能与公开 NHANES 数据关联，不能据“汇总”标签承诺匿名性或不存在任何关联信息。
