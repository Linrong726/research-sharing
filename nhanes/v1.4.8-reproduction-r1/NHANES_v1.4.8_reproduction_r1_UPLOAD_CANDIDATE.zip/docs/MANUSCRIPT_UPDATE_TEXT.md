# Proposed manuscript updates after computational reproduction

Prepared from the two supplied v1.4.8 DOCX extracts and the executed reproduction records. These are proposed replacement and insertion passages; neither original DOCX has been edited. Paragraph identifiers below refer to the existing extraction, not printed page numbers. The target journal is BMC Musculoskeletal Disorders. No author approval, submission, supplementary-file upload or public repository deposit is asserted.

The editing principle is to report the newly executed raw-data reconstruction and refitting accurately, distinguish `REPRODUCTION_NEW` artifacts from missing historical originals, and preserve the remaining inferential limitations. MAIN, D_BASE, D_PLUS, A_HIGH, UNADJ_MAIN, JKn, Δ and percentage points retain their v1.4.8 meanings. The robustness model is labelled MAIN_QUADRATIC only in the supplementary implementation record; it does not replace MAIN.

## 1. Main manuscript P55–P59: replace P56 only

P55 is the heading “Analysis chronology, software and reproducibility”. P57 is “Ethics”, P58 is the ethics paragraph, and P59 is the “Results” heading. Retain these four elements. Replace P56, beginning “The original statistical analysis plan was finalized…”, with the following two paragraphs:

> The original statistical analysis plan was finalized after descriptive, missingness and support audits, but before the first recorded fit of the study association models. The study was not preregistered or fully blinded. The archived analysis session records R 4.6.1 and survey 4.5 [19,22]. During the present revision, the analysis data were reconstructed from the four public-use NHANES XPT files, and all four original adjusted analyses were refitted, including the full sample and all 31 jackknife replicates in each branch. The reconstructed reference domains and the saved adjusted estimates, replicate vectors, covariances and intervals agreed with the archived results. Descriptive summaries and the post hoc unadjusted analysis were also recalculated from the source files.

> Newly generated survey designs, complete analysis weights, fitted objects, coefficients and individual scenario predictions were retained with execution logs and file hashes. These artifacts are identified as REPRODUCTION_NEW: they document the current execution and do not establish the identity or recovery of historical objects that were not located. A separate, explicitly post hoc plan specified one joint quadratic extension of the age and PIR terms, a design-df interval sensitivity check, a PSU-deletion diagnostic and a repeat of the MAIN covariate-support assessment. These checks retained the original MAIN contrast as the sole primary comparison and did not change the phenotype definitions or reference population.

Editorial note: the numerical agreement refers to saved binary adjusted results and the recorded comparisons. It does not claim that every historical CSV field is byte-identical: some descriptive CSVs were originally serialized with fewer significant digits. The code uses the retained original numerical core with additional object capture; a separate arithmetic audit reduces, but does not remove, dependence on shared implementation choices.

## 2. Main manuscript Results: insert after P76, before P77 “Discussion”

Use the short heading “Post hoc computational checks” if a separate subheading is needed. The complete numerical and methodological record belongs in the supplementary insertion in section 7 below; no new table or file number has been assigned here.

> The post hoc joint quadratic age/PIR model gave Δ=9.23 percentage points (95% CI −15.35 to 33.81; interval df=2), compared with 8.70 (−7.49 to 24.90; df=4) for the original MAIN specification. Applying design df=16 to the unchanged MAIN estimate and covariance gave an interval of −3.66 to 21.07 percentage points. All three intervals included zero. Across the 31 MAIN PSU-deletion replicates, Δ ranged from 5.52 to 12.23 percentage points. Recalculated support diagnostics reproduced the archived summaries, including the limited age/PIR support for predictions in S3. These checks did not resolve the uncertainty in the primary between-phenotype contrast.

This is supporting evidence, not a new principal finding. Keep the primary interpretation in P67 and P79. Do not replace the primary interval with the narrower df=16 sensitivity interval.

## 3. Main manuscript P105–P106: availability statement

Retain P105 “Data availability statement”. Choose exactly one P106 version according to the actual sharing state.

### A. Current true status: no external upload or deposit

> The NHANES 2009–2010 public-use data are available from the National Center for Health Statistics through the NHANES website (https://www.cdc.gov/nchs/nhanes/). This analysis used DEMO_F, ARQ_F, DPQ_F and PAQ_F [7,12,14,16]. Study-specific data-processing instructions, analysis code, computational environment records, aggregate outputs and reproduction documentation have been prepared and retained locally. These materials have not yet been uploaded as journal supplementary files or deposited in a public repository. Newly generated individual-level audit objects are retained separately from the aggregate materials.

### B. Enable only after the BMC Additional file upload actually succeeds

> The NHANES 2009–2010 public-use data are available from the National Center for Health Statistics through the NHANES website (https://www.cdc.gov/nchs/nhanes/). This analysis used DEMO_F, ARQ_F, DPQ_F and PAQ_F [7,12,14,16]. Study-specific data-processing instructions, analysis code, computational environment records, aggregate outputs and reproduction documentation are included in the supplementary reproducibility package uploaded with this manuscript. The package identifies the source files and distinguishes newly generated reproduction artifacts from the historical archive. Individual-level audit objects are retained separately. No public repository deposit has been made.

Activation condition for B: verify a successful upload receipt and the actual attached contents. Journal submission access is not public access. If the journal later publishes the files, revise the access sentence to their actual published location and assigned labels; do not invent an Additional file number, URL or DOI. If a public repository deposit also occurs, replace the last sentence only after the deposit and access link have been checked. Neither version promises “available on request” without an actual author commitment.

The aggregate package may include small categorical/support cells, including counts of one. It omits SEQN and individual rows, but this is not an anonymity guarantee: small aggregates may be linked to public NHANES records.

## 4. Main manuscript P112: replace the AI-use paragraph

The existing sentence “The original four model-based analyses were not refitted during these revisions” is no longer accurate. Replace the full P112 with:

> OpenAI ChatGPT and OpenAI Codex assisted with language editing, manuscript organization, literature retrieval and source checking, code development, statistical reconstruction and consistency checks. During the present revision, AI-assisted code was executed to reconstruct the analysis data from the four public-use NHANES files, refit all four original adjusted model specifications with their jackknife replicates, recalculate the post hoc unadjusted and descriptive analyses, and perform the separately specified post hoc robustness checks. The resulting code, execution records and numerical comparisons were retained for review. Final author verification and approval of these new analyses, the revised text and the accompanying files remain pending before submission. The authors remain responsible for the accuracy, integrity and interpretation of the submitted work; the AI tools are not listed as authors.

This is a present-status draft. The sentence about pending author verification must not be silently replaced with a claim that all authors reviewed or approved the work. Once that review actually occurs, update the sentence to describe the verification performed, without implying that AI use was limited to language polishing.

## 5. Supplementary P17: replace the paragraph on JKn design construction

> The full positive-MEC design included 10,253 participants, 15 masked strata and 31 masked primary sampling units (PSUs), with one three-PSU stratum. The full survey design was constructed before domain restriction [17]. Both the archived production algorithm and the current raw-data reproduction generated stratified delete-one-PSU jackknife (JKn) weights with the survey package [18,19], using mse=TRUE. Deleting a PSU in stratum h assigned it zero weight and multiplied the other weights in that stratum by m_h/(m_h−1); weights in other strata were unchanged. Here m_h is the number of masked PSUs in stratum h. Scale and replicate-specific rscales were obtained from the survey object. The current reproduction retained its newly constructed design objects and complete individual analysis-weight matrices. These new objects permit inspection of the current design-to-estimation chain; they do not replace the historical identity of the original design objects and weight matrices that were not located (S-M5).

Do not equate the original XPT weight field with the survey object's actual sampling weights at the last binary digit. The recorded inverse-probability round trip produced machine-precision differences; the new and historical fitted-reference weights followed the same numerical path and matched. Detailed floating-point comparisons belong in the computational audit, not in this methods paragraph.

## 6. Supplementary P30: replace with two paragraphs

> The historical archive retains the plan, production code, reference-membership and weight checks, full-precision full-sample and replicate estimates, covariances, intervals and diagnostics. The bounded search did not locate the original survey-design objects (DES06), complete individual replicate analysis weights (DES09), original design-object fields including combined.weights (DES11), or the complete fitted-object, coefficient and individual scenario-prediction chain (S10). These findings describe that search and do not establish that the artifacts never existed.

> During the current reproduction, the analysis records were newly derived from DEMO_F, ARQ_F, DPQ_F and PAQ_F, and the four adjusted branches were fitted again under the retained specifications. New design objects, full and replicate analysis weights, all 128 fitted objects, coefficients and individual four-scenario predictions were saved as REPRODUCTION_NEW. Reference membership, estimates, replicate vectors, covariances and intervals were compared with the historical binary outputs; additional arithmetic checks used the newly saved objects to verify weight construction, model matrices, predictions, reference averaging, contrast direction and interval calculations. These records provide a newly executable and inspectable reconstruction of the specified procedure. They do not recover historical object identity, establish that the original scientific specification was correct, or demonstrate repeated-sampling interval coverage. The independent arithmetic checks used the recorded R environment rather than a fully independent statistical-software implementation.

If desired, the following sentence can be added after the second sentence of the second paragraph, because the separately recorded clean rerun has now also completed:

> A further clean rerun used freshly downloaded XPT files, separately copied code and a separate package library, without historical results as computational inputs.

Evidence for the optional clean-rerun sentence is the cleanroom execution and review records, not merely a proposed command. It does not establish cross-operating-system or cross-version bitwise reproducibility.

## 7. Supplementary insertion after P50, before P51/Table S1

Proposed new heading: “S-M9. Current reproduction and limited post hoc robustness checks”. This proposed section label is an editorial addition, not an existing v1.4.8 location. The paragraphs below contain the full four-part check so that the main-text addition can remain short.

> The limited robustness checks were specified in a separate plan after the original results were known and before the new checks were calculated. They were therefore post hoc, rather than preregistered or part of the original analysis plan. New fitting used the records reconstructed from the four public-use XPT files. The original MAIN membership, exposure and phenotype definitions, MEC-weighted common reference distribution and primary estimand were retained. No observation or PSU was excluded on the basis of the new results, and no sensitivity model was selected to replace MAIN.

> One additional mean model jointly added age10² and PIR² to the original MAIN specification: Y~A×G+age10+age10²+sex+race/ethnicity+education+PIR+PIR², where A×G denotes the two main effects and their product. All four scenarios were standardized over the same MAIN reference distribution. The full-sample fit and all 31 JKn fits passed the retained binary-cell, rank, convergence, warning and prediction-boundary rules. Model rank was 15, so the original reduced-df formula yielded interval df=2. The resulting Δ was 9.23 percentage points (95% CI −15.35 to 33.81), a point-estimate change of 0.53 percentage points from MAIN. This tests one specified extension of the linear age/PIR terms; it does not test all nonlinearities or interactions. Its interval width reflects both its estimated variance and the change in interval degrees of freedom.

> A separate interval-rule check retained the newly reproduced MAIN point estimates and covariance matrices and changed only the t critical value from df=4 to design df=16. For Δ, the interval changed from −7.49 to 24.90 to −3.66 to 21.07 percentage points, with the point estimate unchanged at 8.70. The original MAIN, quadratic-model and design-df intervals all included zero. Survey regression guidance notes that residual-df rules can be conservative for individual-level covariates [20], but that guidance does not establish the coverage of these nonlinear standardized contrasts. The design-df result is a sensitivity analysis and does not replace the primary interval.

> PSU-deletion influence was described using all 31 newly reproduced MAIN JKn vectors. The replicate Δ estimates ranged from 5.52 to 12.23 percentage points. The largest absolute change from the full estimate was +3.53 percentage points after deletion of masked stratum 80, PSU 1; that replicate contributed 18.28% of the saved JKn variance of Δ. Each deletion also reweighted the remaining PSUs in its stratum and the common-reference average. These are dependent jackknife diagnostics, not 31 independent hypothesis tests or grounds for excluding influential PSUs.

> Four-scenario MAIN support was recalculated using the retained exact sex×race/ethnicity×education matching, age/PIR bins, convex-hull rules and nearest-neighbour scaling described in S-M4 and S-M7. All proportions used the total MAIN MEC weight as the common denominator. The recalculated summaries agreed with the archived descriptive exports within their saved precision. For the S3/A=1 scenario, 49.70% of the reference weight lacked a matching fine age/PIR cell and 45.81% lay outside the within-category age/PIR convex hull; the corresponding S3/A=0 values were 33.14% and 36.48%. These overlapping diagnostics were not summed and no trimming followed. They document persistent reliance on model extrapolation, do not estimate its bias, and do not assess support for the redefined A_HIGH cells or the additional D dimension in D_PLUS.

> Newly generated design, weight, fit and individual-prediction artifacts were retained separately from aggregate results. Complete attempted-run logs were preserved, including a pre-fit floating-point identity assertion failure and a later matrix-export error; the latter occurred after all 32 quadratic fits had succeeded and was repaired from the saved result object. A final run of the repaired code completed all four checks and reproduced the repaired numerical exports. These engineering corrections did not change the locked robustness specification, eligibility, thresholds or inferential rules. The checks do not remove complete-responder selection, unmeasured confounding, measurement error, cross-sectional temporal ambiguity, limited covariate support or uncertainty about interval coverage.

The detailed engineering paragraph may instead reside in the submitted reproducibility documentation if that file is actually included. Do not describe the intermediate export error as a failed scientific model, and do not omit the attempt record from the computational materials.

## 8. Table S13 explanation: replace P158; retain P157 and P159

> UNADJ_MAIN reports survey-weighted observed-cell proportions, within-phenotype prevalence differences and their between-phenotype difference. Its post hoc JKn intervals use logit-scale limits for proportions and the original-scale joint covariance for differences, with design df=16. No regression is fitted for UNADJ_MAIN. During the current reproduction, these unadjusted quantities were recalculated from the four source XPT files. The adjusted MAIN column retains the original mean-model specification and df=4 interval rule; its values were confirmed by new full-sample and jackknife fits from the reconstructed records and matched the archived results. The newly executed analyses are documented separately as REPRODUCTION_NEW.

P159 correctly explains that the columns target different covariate distributions and that comparing them does not establish removed confounding, mediation, equivalence or robustness. Retain that explanation. P157 correctly identifies the 3,687-person sample and A/G definitions. Retain those as well.

## 9. Necessary consistency edits elsewhere

These short edits prevent the requested replacements from leaving contradictory statements in v1.4.8.

### Main P75: replace the first sentence only

> All four adjusted analyses completed the full-sample fit and all 31 jackknife replicates in the current raw-data reproduction without violating the retained fitting or stability rules; the corresponding archived diagnostics also recorded successful completion.

Retain the remaining domain/cell coverage information in P75.

### Main P76: replace its opening clause only

Replace “For MAIN, the archived pre-estimation support audit found that” with:

> For MAIN, the archived pre-estimation support audit and the current raw-data recalculation both found that

Retain the numbers and the distinction between support measures and bias proportions.

### Main P93: replace the full paragraph

> Precision remains limited, and the fixed reduced-df t approximation with df=4 or 3 does not guarantee nominal coverage for this nonlinear standardized contrast. The current raw-data reconstruction and refitting reproduced the archived adjusted results and saved new objects spanning the design-to-prediction chain. Missing historical objects remain an archival limitation, while the newly saved objects permit examination of the current implementation. Neither computational agreement nor the limited post hoc checks establish correct model specification or interval coverage. The historical single-cycle design also restricts transportability to contemporary populations and clinical settings. The target remains the specified weighted complete-responder distribution, not a causal effect in all adults.

P92 already retains the complete-responder, unmeasured-confounding, measurement and extrapolation limitations. Keep those; do not replace them with a general claim that the sensitivity analyses “resolved” bias. If P92 specifically attributes every current prediction to linear age/PIR terms, clarify that this describes the primary model and that the single post hoc quadratic extension did not remove the support limitation.

## Evidence map and unresolved actions

| Statement | Existing evidence relative to this task root | Boundary |
|---|---|---|
| Four adjusted branches really refitted from XPT | `audit/adjusted/RECONSTRUCTION_RESULT_CN.md`; `runs/adjusted/local_raw/provenance/actual_command.json` | New execution, not recovered historical objects |
| Adjusted binary agreement and saved-object checks | `audit/adjusted/FINAL_REVIEW_CN.md`; `audit/adjusted/cleanroom_historical_comparison/`; `audit/adjusted/cleanroom_saved_objects/`; `audit/adjusted/cleanroom_independent_review/` | Same recorded R environment; not a wholly independent software implementation |
| UNADJ and descriptive summaries recalculated | `audit/posthoc/POSTHOC_REPRODUCTION_CN.md`; `audit/posthoc/binary_comparison_local/`; `audit/posthoc/comparison_local_final/` | Historical descriptive CSV rounding is distinguished from binary equality |
| Four limited robustness checks and their attempts | `plan/robustness/ROBUSTNESS_PLAN_v1.md`; `audit/robustness/ROBUSTNESS_RESULTS_CN.md`; `runs/robustness/run004/` | Post hoc; one added mean model; original MAIN retained |
| Current AI contributions | Actual recorded code generation, execution, reconstruction and audits in this task | Final author verification/approval cannot be inferred from computational checks |
| External sharing | No successful external upload/deposit receipt used to prepare this draft | Current version A only; version B is expressly conditional |

Before submission, author verification, actual external attachment/upload status and any assigned supplementary identifiers must be reconciled with the final manuscript. These are remaining factual states, not grounds to describe already executed refitting as “not refitted”.
