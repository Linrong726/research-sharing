# 未调整分析与描述表的原始数据重跑结论

2026-09-18，使用现存四份官方来源 XPT，已实际完成从原始模块连接、变量派生、调查设计构建、复制权重构建到最终估计和汇总的计算。正式本地运行目录为 `runs/posthoc/local_raw_complete`；计算只读四份 XPT，不使用旧逐人数据或旧结果作为科学输入。旧结果在新运行完成后单独打开比较。

样本流程重算为 10,537 → 5,106 → 5,001 → 5,001 → 4,625 → 4,052 → 4,052 → 3,687；D-known 侧分支为 3,686。完整正 MEC 设计包含 10,253 人、15 层、31 个 PSU，JKn 为 31 个复制，实际设计自由度 16。

## 复核结果

- 31 份 CSV，11,566 个字段完成逐项比较：11,119 项文本完全相等，2 项数值完全相等但字符串写法不同，445 项只有历史 15 位 CSV 输出舍入差异，0 项超出该已知输出精度的差异。
- 七项 UNADJ_MAIN 点估计、全部 31×7 复制值、V4、V7、logit V4、scale/rscales/mse 与原保存二进制对象逐项完全一致；CI 各字段也完全一致。
- 独立 posthoc 派生与调整分析代理独立从四份 XPT 派生的数据逐字段完全相同；连同 UNADJ 对象，共 246 项对象/字段级 `identical` 检查全部通过。
- 主 Table 1、S1–S7、S10 的数值来源已重算；S13–S15 的未调整估计、流程及缺失表完整来源均已重算。
- 输入与计算源代码在运行前后 SHA-256 一致。完整 R stdout/stderr、sessionInfo、10 个包的版本/实际路径、二进制对象和逐字段差异均保存。

旧表里 445 项舍入差异有明确分类，不合并为“二进制相等”。其中 437 项来自既有描述表的 15 位导出，8 项来自旧 JKn 构建检查和数值实现检查的 15 位导出。UNADJ 最终 17 位估计、复制、协方差和流程/缺失汇总没有数值差异。

首次严格比较将上述 8 项辅助诊断显示为不相等。核查 `step3r/posthoc144/code/export_exact_saved_results.R` 后确认这两份诊断从未进入 17 位再导出；正式比较只为这两份辅助诊断标记既有 15 位舍入容差。初次结果保留在 `comparison_local/`，正式结果在 `comparison_local_final/`，以保留修正依据。

运行时 R 启动出现 LC_COLLATE、LC_CTYPE、LC_MONETARY、LC_TIME 四条 C.UTF-8 locale 警告；无计算/拟合警告，退出码 0，所有检查通过。当前验证在同一 Windows / R 4.6.1 环境完成，不等同于已测试其他操作系统或其他 R 版本。

## 核查入口

| 材料 | 相对本次任务根的路径 |
|---|---|
| 可移植运行及规则说明 | code/posthoc/README_CN.md |
| 运行完成收据 | runs/posthoc/local_raw_complete/audit/launch_receipt.json |
| 输入/代码 SHA-256 | runs/posthoc/local_raw_complete/audit/input_code_SHA256.csv |
| 全部输出 SHA-256 | runs/posthoc/local_raw_complete/audit/output_SHA256.csv |
| 逐字段旧值/新值/绝对差异/分类 | audit/posthoc/comparison_local_final/field_comparison.csv |
| 各文件比较摘要 | audit/posthoc/comparison_local_final/table_summary.csv |
| 机器可读总结果 | audit/posthoc/comparison_local_final/comparison_summary.json |
| 二进制与独立派生检查 | audit/posthoc/binary_comparison_local/binary_and_independent_derivation.csv |
| UNADJ 标量双精度十六进制 | audit/posthoc/binary_comparison_local/UNADJ_binary_scalar_hex.csv |

历史缺失对象的档案事实仍然存在；本次重建的完整设计、复制权重、逐人域和统计对象提供了新的可检查证据。它们是 `REPRODUCTION_NEW`，不能写成“找回原始对象”。重跑也不会修正横断面推断、非应答选择、残余混杂、低设计自由度或支持不足；这些限制需在稿件解释中继续准确保留。
