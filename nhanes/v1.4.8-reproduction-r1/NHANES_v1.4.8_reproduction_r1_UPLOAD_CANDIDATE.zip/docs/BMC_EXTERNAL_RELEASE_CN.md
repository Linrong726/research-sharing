# BMC Musculoskeletal Disorders 外部材料交付状态

本轮已经生成并实际运行可移植分析包，尚未建立真实的外部存储记录、审稿链接或 DOI。不能把本地 ZIP、校验值、GitHub 账户连接或预留的名称写成公开归档。

## 可直接使用的两条交付路径

1. **期刊 Additional file**：将 `NHANES_v1.4.8_reproduction_r1_UPLOAD_CANDIDATE.zip` 作为分析代码及汇总输出附件，与稿件一起上传至投稿系统。它含英文运行说明、四模块自动下载与SHA256验证、固定版本环境说明、全流程入口、完整精度输出、复核证据和事后方案。附件标题可用 “Analysis code, aggregate results and computational reproduction evidence for manuscript v1.4.8”。附件编号应以实际投稿系统分配或作者编排为准。
2. **作者控制的归档**：把同一 ZIP 上传到 Zenodo 草稿，填写确认的作者/机构、版本、稿件关系及适用许可；可先提供草稿审稿访问，再公开发布取得固定版本 DOI。GitHub 可放代码和说明，正式归档可关联固定提交或 release。不要把可变分支链接当成固定归档版本。

期刊要求说明支持结果的数据在哪里，鼓励公共仓库或补充材料，并不要求本研究必须使用某一个平台。当前准备好的附件路径可先解决投稿时审稿材料交付；作者控制的持久仓库有利于后续固定版本引用。依据：[Research article instructions](https://link.springer.com/journal/12891/submission-guidelines/research-article)、[Submission guidelines](https://link.springer.com/journal/12891/submission-guidelines)。本次 ZIP 按补充材料的单文件 20 MB 上限核验。

## 当前平台障碍

已连接的 GitHub 账户列表未返回可用仓库；当前连接工具不提供创建仓库操作，主机也没有可用 gh 命令。Zenodo 页面创建后，浏览器控制在连接/读取标签页时超时，一次恢复尝试仍失败；这不能解释为已登录、未登录或已有草稿。没有创建记录、上传文件、发出邀请或取得 DOI。

已向用户请求一个有写入权限的仓库地址，或已有 Zenodo 草稿链接。获得可用目标后，下一步是上传已封装候选包、记录版本/文件校验值，并从审稿人可使用的访问方式验证下载内容。无需重新设计或重新计算分析。

## 上传后的验收条件

核对平台文件名、大小和SHA256与本地封包收据一致；记录永久或版本固定链接；验证预期受众能访问代码和汇总结果；用真实URL更新主文数据/代码可用性声明。只预留DOI而没有发布记录，不算已经公开；Zenodo说明：[Create new upload](https://help.zenodo.org/docs/deposit/create-new-upload/)、[Sharing records](https://help.zenodo.org/docs/share/about/)。

完整逐人审计包不作为这一步的默认上传对象。公共候选包保留来自公开NHANES的小单元聚合，未包含SEQN逐人表、完整个体权重、逐人预测、设计RDS、原稿或本机路径。小单元可能与公开源数据关联，不能把“聚合”当成匿名保证。公开许可和作者元数据须使用作者确认的信息；本轮没有代替作者声明许可、签署平台条款或完成最终学术审核。
