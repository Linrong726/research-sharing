# 四个调整分析分支：从原始 XPT 的新重建结果

2026-09-18 已实际执行 `code/adjusted/run_adjusted.py`。运行目录为
`runs/adjusted/local_raw`。本次所有输出属于 **REPRODUCTION_NEW**，不能追认为历史原件。

## 已完成的证据链

1. 仅以本地四份 NHANES XPT 作为科学输入，按 SEQN 左连接至 DEMO，独立重建原始变量、S0/S3 分组、A、A_high、D、Y、协变量和分析域。
2. 重建主分析 3687 人及 D 已知 3686 人；总 DEMO 10537 人，完整正 MEC 权重设计 10253 人。
3. 依原规则实际执行 MAIN、D_BASE、D_PLUS、A_HIGH，每分支一次全样本拟合及 31 次 JKn 重复拟合，共 128 次；全部成功，无丢弃重复、无重试、无改变估计规则。
4. 保存每次完整 `glm.fit` 返回对象、系数、每人四情景预测、SEQN、分析权重；保存完整及分析域 Taylor/JKn 设计对象、完整及域内权重矩阵和 D 两分支共同参考输入。
5. 拟合完成后才由独立 R 进程读取历史汇总 RDS 进行比较。28 个估计及其 CI、所有 31×7 重复估计、7×7 协方差及 4×4 logit 协方差均逐位一致，最大绝对差为 **0**。SEQN 和参考权重也完全一致。36 组比较全部通过。
6. 另以新保存的系数、权重和新原始数据派生输入重算逐人预测及汇总，396 项自洽检查全部通过。涉及 1,887,488 个逐人情景概率，均精确一致。
7. 四份复用纯函数文件 SHA-256 与历史代码相同。运行前记录 XPT 及代码哈希、实际命令、容差规则，运行后校验原始输入/执行代码未变，并生成输出 SHA-256 清单。

## 复核入口

- `runs/adjusted/local_raw/provenance/actual_command.json`：实际命令、起止时间、退出码、输入未改变记录。
- `runs/adjusted/local_raw/provenance/input_code_manifest.json`：原始 XPT 和执行代码 SHA-256。
- `runs/adjusted/local_raw/audit/historical_comparison_checks.csv`：36 组历史值比较。
- `runs/adjusted/local_raw/audit/historical_28_estimate_CI_comparison.csv`：28 个估计和区间差异。
- `runs/adjusted/local_raw/audit/historical_numeric_hex_comparison.csv`：无损十六进制双精度值比较。
- `audit/adjusted/saved_object_audit/saved_object_independent_checks.csv`：396 项保存对象独立复算。
- `audit/adjusted/saved_object_audit/*_model_and_scenario_matrices.rds`：由新 inputs 重新生成的含 SEQN 模型及四情景矩阵。
- `audit/adjusted/vendor_source_identity.csv`：复制源文件逐字节一致证据。
- `audit/adjusted/SOURCE_AND_SCHEMA.md`：来源边界、仪器化机制、可移植运行入口及字段说明。

运行日志保留了 Windows 上 `C.UTF-8` locale 不可用的启动提示；R 继续使用所记录的 locale，拟合、数值比较及保存对象复算均成功。实际运行 R 4.6.1、survey 版本与依赖信息见每次运行 `environment` 目录。

## 结论范围

本项工作把原先“只能核对现存汇总输出”的边界推进为“从原始 XPT 完整重建四个既定调整分析分支，并与现存历史结果完全匹配”。缺失的历史拟合/设计对象已经有可重建、可审查的新对应物，但历史时间点对象的缺件记录仍保留，不能虚构其已被找回。

计算一致性不能排除横断面设计、反向因果、自报测量、完整案例选择、残余混杂与有限设计自由度带来的统计局限。此处没有新增敏感性模型；相关检验由独立事后分析方案负责，必须标明其事后性质。
