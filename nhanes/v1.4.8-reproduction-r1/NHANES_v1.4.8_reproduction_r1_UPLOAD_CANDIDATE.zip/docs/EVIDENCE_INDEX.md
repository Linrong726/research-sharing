# Evidence locations

The executed package receipt and its code SHA256 values are in `evidence/FINAL_PACKAGE_EXECUTION.json`; the exact aggregate comparison is in `FINAL_PACKAGE_AGGREGATE_RECEIPT.json`. The original-specification binary comparison is in `HISTORICAL_ADJUSTED_COMPARISON.csv`, and `HISTORICAL_28_ESTIMATES_CIS.csv` lists the estimate/interval differences. The 396 and 788 object checks have separate evidence CSVs. Historical post hoc CSV precision comparisons and table/figure coverage are also listed here.

The detailed Chinese reports retain project-relative paths to local audit records. Those paths describe the full local archive and are not promises that every individual-level object is bundled publicly. For the external package, use `expected/` for aggregate outputs and `code/run_all.py` to generate complete local objects. In the separate LOCAL_AUDIT archive, the final integrated run is under `canonical_run/`, and earlier robustness attempts are under `robustness_attempts/`.

No public repository deposit, anonymous reviewer link or DOI has been created by this package. The two ZIP files are local artifacts until actually uploaded to an authorized destination.
