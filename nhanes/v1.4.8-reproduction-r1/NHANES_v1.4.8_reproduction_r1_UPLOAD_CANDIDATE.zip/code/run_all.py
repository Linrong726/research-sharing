"""Run the complete reconstruction from four XPT files; no historical data objects.

Python 3.9+ standard library, R 4.6.1 and the pinned R packages are required.
All output is written to a new directory. Expected aggregate results are only read
after computation and the saved-object audits have completed.
"""
from pathlib import Path
import argparse, datetime, hashlib, json, os, shutil, subprocess, sys


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--out',required=True,type=Path)
    p.add_argument('--raw-dir',type=Path,help='Four XPT files. Omit to download from CDC.')
    p.add_argument('--rscript',default='Rscript')
    p.add_argument('--lib',type=Path)
    a=p.parse_args()
    code=Path(__file__).resolve().parent
    package=code.parent
    out=a.out.resolve()
    if out.exists():p.error('Output directory must not exist; prior runs are never overwritten.')
    rscript=shutil.which(a.rscript)
    if not rscript:p.error('Rscript not found; supply --rscript PATH.')
    lib=str(a.lib.resolve(strict=True)) if a.lib else ''
    raw=a.raw_dir.resolve(strict=True) if a.raw_dir else out/'raw'
    out.mkdir(parents=True)
    logs=out/'execution';logs.mkdir()
    env=os.environ.copy()
    env.update(OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1')
    if lib:env.update(R_LIBS_USER=lib,R_LIBS_SITE=lib)
    receipt={'origin':'REPRODUCTION_NEW','started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
             'historical_objects_used_for_calculation':False,'steps':[],'status':'RUNNING'}
    sources=[f for f in sorted(code.rglob('*')) if f.is_file() and '__pycache__' not in f.parts]
    hashes={f.relative_to(package).as_posix():hashlib.sha256(f.read_bytes()).hexdigest() for f in sources}
    receipt['code_sha256_before']=hashes
    def save(): (logs/'PIPELINE_RECEIPT.json').write_text(json.dumps(receipt,indent=2),encoding='utf-8')
    def run(label,args):
        print(label,flush=True)
        started=datetime.datetime.now(datetime.timezone.utc).isoformat()
        with (logs/(label+'.log')).open('w',encoding='utf-8') as f:
            proc=subprocess.run([str(v) for v in args],stdout=f,stderr=subprocess.STDOUT,env=env)
        receipt['steps'].append({'step':label,'command':[str(v) for v in args],'started_utc':started,'exit_code':proc.returncode})
        save()
        if proc.returncode:raise RuntimeError(label+' failed; inspect execution/'+label+'.log')
    R=[rscript,'--vanilla'];py=[sys.executable]
    try:
        run('01_environment',R+[code/'check_environment.R',lib])
        # The downloader is also the exact SHA256 validator for supplied inputs.
        args=py+[code/'download_nhanes.py','--output',raw,'--receipt',logs/'RAW_SOURCE_RECEIPT.json']
        if a.raw_dir:args+=['--verify-only']
        run('02_raw_source_identity',args)
        args=py+[code/'adjusted/run_adjusted.py','--raw-dir',raw,'--out',out/'adjusted','--rscript',rscript]
        if lib:args+=['--lib',lib]
        run('03_adjusted',args)
        run('04_exact_adjusted',R+[code/'adjusted/export_exact_adjusted.R',out/'adjusted',out/'adjusted_exact'])
        run('05_saved_object_audit',R+[code/'adjusted/audit_saved_objects.R',out/'adjusted',out/'saved_object_audit',lib])
        run('06_independent_arithmetic',R+[code/'adjusted/review_independent_arithmetic.R',out/'adjusted',out/'independent_arithmetic'])
        for label,script,folder in [('07_posthoc','run_with_manifest.py','posthoc'),('08_S12_routes','run_s12_routes.py','s12')]:
            args=py+[code/'posthoc'/script,'--raw',raw,'--out',out/folder,'--rscript',rscript]
            if lib:args+=['--lib',lib]
            run(label,args)
        args=py+[code/'robustness/execute_portable.py','--adjusted-run',out/'adjusted','--core-code',code/'adjusted/vendor/02_estimator_core.R',
                 '--output',out/'robustness','--audit-output',out/'robustness_audit','--rscript',rscript]
        if lib:args+=['--r-library',lib]
        run('09_robustness',args)
        run('10_expected_aggregates',py+[code/'verify_expected.py','--run',out,'--expected',package/'expected','--out',out/'aggregate_comparison'])
        receipt['code_unchanged']=all(hashlib.sha256((package/f).read_bytes()).hexdigest()==h for f,h in hashes.items())
        if not receipt['code_unchanged']:raise RuntimeError('Code changed during run.')
        receipt['status']='PASS'
    except Exception as e:
        receipt['status']='FAIL';receipt['error']=str(e)
        raise
    finally:
        receipt['finished_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();save()
    print(json.dumps({'status':receipt['status'],'output':str(out),'steps':len(receipt['steps'])}))


if __name__=='__main__':main()
