# Fixed post hoc audit. Raw-XPT rebuilt inputs only. Does not overwrite original files.
args<-commandArgs(trailingOnly=TRUE)
usage<-'Rscript run_robustness.R --adjusted-run PATH --core-code PATH --output NEW_DIRECTORY [--r-library PATH] [--support-baseline CSV]'
if(length(args)==1L && args[1]=='--help'){cat(usage,'\n');quit(status=0)}
if(!length(args)||length(args)%%2L!=0L)stop(usage)
options<-setNames(as.list(args[seq(2,length(args),by=2)]),args[seq(1,length(args),by=2)])
allowed<-c('--adjusted-run','--core-code','--output','--r-library','--support-baseline')
if(anyDuplicated(names(options))||any(!names(options)%in%allowed)||!all(c('--adjusted-run','--core-code','--output')%in%names(options)))stop(usage)
newroot<-normalizePath(options[['--adjusted-run']],winslash='/',mustWork=TRUE)
core_code<-normalizePath(options[['--core-code']],winslash='/',mustWork=TRUE)
out_path<-options[['--output']]
if(dir.exists(out_path)&&length(list.files(out_path,all.files=TRUE,no..=TRUE)))stop('Output directory must be new or empty')
if(file.exists(out_path)&&!dir.exists(out_path))stop('Output target is an existing file')
dir.create(out_path,recursive=TRUE,showWarnings=FALSE)
out<-normalizePath(out_path,winslash='/',mustWork=TRUE)
if('--r-library'%in%names(options)){
  rlib<-normalizePath(options[['--r-library']],winslash='/',mustWork=TRUE)
  .libPaths(c(rlib,.libPaths()))
}
support_baseline<-if('--support-baseline'%in%names(options))normalizePath(options[['--support-baseline']],winslash='/',mustWork=TRUE) else NULL
library(survey)
source(core_code)
inputs<-readRDS(file.path(newroot,'data/design_inputs.rds'))
outcome<-readRDS(file.path(newroot,'data/research_outcome.rds'))
main<-readRDS(file.path(newroot,'models/MAIN/complete_result.rds'))
aligned<-p2_align_inputs(inputs,outcome,FALSE)
inputs<-aligned$inputs; mask<-inputs$domain; d<-inputs[mask,]; y<-aligned$response[mask]
design_for_identity<-p2_design(inputs,mask)
stopifnot(nrow(d)==3687L,identical(d$SEQN,main$reference$SEQN),identical(design_for_identity$weights[mask],main$reference$WTMEC2YR))
write_exact<-function(x,name) {
  z<-x
  for(nm in names(z))if(is.numeric(z[[nm]]))z[[nm]]<-ifelse(is.na(z[[nm]]),'NA',sprintf('%.17g',z[[nm]]))
  write.csv(z,file.path(out,name),row.names=FALSE,na='NA')
}
status<-list(); checkrows<-list()
check<-function(id,ok,detail='') {checkrows[[length(checkrows)+1L]]<<-data.frame(check=id,passed=ok,detail=detail);if(!ok)stop(id)}
record<-function(id,state,detail='') {status[[length(status)+1L]]<<-data.frame(analysis=id,status=state,detail=detail)}
check('new_main_reference_identity',TRUE)
check('new_main_has_31x7_replicates',identical(dim(main$replicates),c(31L,7L)))
check('known_binary_response',all(!is.na(y)&y%in%0:1))
write_exact(data.frame(comparison='raw_MEC_to_actual_survey_sampling_weight',n=nrow(d),different_binary64=sum(d$WTMEC2YR!=design_for_identity$weights[mask]),max_absolute_difference=max(abs(d$WTMEC2YR-design_for_identity$weights[mask])),main_reference_exact_to_new_design=TRUE),'WEIGHT_FLOATING_POINT_ROUNDTRIP.csv')

# CI rule sensitivity on the new reproduced MAIN only.
intervals<-function(point,V,Vlogit,df) {
  se<-sqrt(diag(V)); tcrit<-qt(.975,df); low<-point-tcrit*se;high<-point+tcrit*se
  low[1:4]<-plogis(qlogis(point[1:4])-tcrit*sqrt(diag(Vlogit)))
  high[1:4]<-plogis(qlogis(point[1:4])+tcrit*sqrt(diag(Vlogit)))
  data.frame(estimand=names(point),estimate=unname(point),se=unname(se),lower=unname(low),upper=unname(high),estimate_pp=100*unname(point),lower_pp=100*unname(low),upper_pp=100*unname(high),ci_df=df)
}
df16<-intervals(main$estimate,main$covariance,main$probability_logit_covariance,16)
df16$original_lower_pp<-main$ci$lower_percent;df16$original_upper_pp<-main$ci$upper_percent;df16$original_df<-4
write_exact(df16,'MAIN_DF16_intervals.csv')
check('df16_points_unchanged',identical(df16$estimate,unname(main$estimate)))
record('MAIN_DF16','SUCCESS','Point/covariance unchanged; CI rule sensitivity only, no coverage claim')

# All 31 PSU deletions; no reordering or exclusions for estimation.
influence<-main$design_weight_audit
influence$Delta_probability<-main$replicates[,'Delta']; influence$Delta_pp<-100*influence$Delta_probability
influence$change_pp<-100*(influence$Delta_probability-main$estimate[['Delta']])
influence$absolute_change_rank<-rank(-abs(influence$change_pp),ties.method='min')
influence$variance_contribution<-main$metadata$scale*main$metadata$rscales*(influence$Delta_probability-main$estimate[['Delta']])^2
influence$variance_contribution_percent<-100*influence$variance_contribution/main$covariance['Delta','Delta']
check('delete_PSU_contributions_sum_to_Delta_variance',abs(sum(influence$variance_contribution)-main$covariance['Delta','Delta'])<1e-15)
write_exact(influence,'MAIN_PSU_deletion_influence.csv');record('MAIN_PSU_DELETION','SUCCESS','All 31 new JKn replicates; not independent tests')

# One and only one new mean model.
quad_fit<-function(w,X,sX,label) {
  active<-w>0;cells<-do.call(rbind,lapply(0:1,function(g)do.call(rbind,lapply(0:1,function(a){i<-active&d$G==g&d$A==a;data.frame(replicate=label,G=g,A=a,n=sum(i),Y0=sum(y[i]==0),Y1=sum(y[i]==1))}))))
  if(any(cells$n==0|cells$Y0==0|cells$Y1==0))stop(paste(label,'empty cell/outcome'))
  if(any(!is.finite(w)|w<0)||sum(w)<=0)stop(paste(label,'invalid weights'))
  rk<-qr(X[active,,drop=FALSE]*sqrt(w[active]/mean(w[active])))$rank
  if(rk!=15L)stop(paste(label,'rank',rk,'expected 15'))
  warns<-character()
  fit<-withCallingHandlers(glm.fit(x=X[active,,drop=FALSE],y=y[active],weights=w[active]/mean(w[active]),family=quasibinomial(),control=glm.control(maxit=100,epsilon=1e-10)),warning=function(e){warns<<-c(warns,conditionMessage(e));invokeRestart('muffleWarning')})
  # Save even unsuccessful fitted object before enforcing the fixed rejection rule.
  saveRDS(fit,file.path(out,'individual',paste0('QUADRATIC_fit_',label,'.rds')))
  if(!isTRUE(fit$converged)||isTRUE(fit$boundary)||length(warns)||fit$rank!=15L||any(!is.finite(fit$coefficients)))stop(paste(label,'fit failed',paste(warns,collapse=';')))
  pred<-vapply(sX,function(m)plogis(as.vector(m%*%fit$coefficients)),numeric(nrow(d)))
  saveRDS(data.frame(SEQN=d$SEQN,pred),file.path(out,'individual',paste0('QUADRATIC_predictions_',label,'.rds')))
  if(any(!is.finite(pred))||any(pred<=1e-8|pred>=1-1e-8))stop(paste(label,'prediction threshold'))
  list(estimate=p2_contrasts(colSums(pred*w)/sum(w)),cells=cells,coefficients=fit$coefficients,diagnostics=data.frame(replicate=label,n_positive=sum(active),rank=rk,converged=fit$converged,boundary=fit$boundary,n_warnings=length(warns),min_prediction=min(pred),max_prediction=max(pred),iterations=fit$iter))
}
dir.create(file.path(out,'individual'),showWarnings=FALSE)
quad_attempts<-list()
quad<-tryCatch({
  design<-design_for_identity
  saveRDS(design[c('taylor','replicate','weights','replicate_weights','weight_audit')],file.path(out,'individual/QUADRATIC_new_design_and_weights.rds'))
  f<-~A*G+age10+I(age10^2)+sex+race+education+PIR+I(PIR^2)
  ca<-lapply(p2_factor_levels,function(x)contr.treatment(x,base=1L));X<-model.matrix(f,d,contrasts.arg=ca)
  expected<-c('(Intercept)','A','G','age10','I(age10^2)','sex2','race2','race3','race4','race5','educationHS_GED','educationabove_HS','PIR','I(PIR^2)','A:G')
  check('quadratic_columns_exact',identical(colnames(X),expected));check('quadratic_rank_15',qr(X)$rank==15L)
  sX<-lapply(list(c(0,0),c(1,0),c(0,1),c(1,1)),function(ag){z<-d;z$A<-ag[1];z$G<-ag[2];model.matrix(f,z,contrasts.arg=ca)})
  labels<-c('full',paste0('JKn_',1:31));W<-cbind(full=design$weights[mask],design$replicate_weights[mask,,drop=FALSE])
  fits<-vector('list',32L)
  for(j in 1:32) {
    quad_attempts[[j]]<-data.frame(fit=labels[j],status='STARTED',detail='')
    z<-tryCatch(quad_fit(W[,j],X,sX,labels[j]),error=function(e){quad_attempts[[j]]<<-data.frame(fit=labels[j],status='FAILED',detail=conditionMessage(e));stop(e)})
    fits[[j]]<-z;quad_attempts[[j]]<-data.frame(fit=labels[j],status='SUCCESS',detail='')
  }
  point<-fits[[1]]$estimate;reps<-do.call(rbind,lapply(fits[-1],`[[`,'estimate'))
  V<-p2_covariance(reps,point,design$scale,design$rscales,design$mse)
  VL<-p2_covariance(qlogis(reps[,1:4,drop=FALSE]),qlogis(point[1:4]),design$scale,design$rscales,design$mse)
  ci_df<-min(16,16-qr(X)$rank+1);check('quadratic_ci_df_2',ci_df==2)
  check('quadratic_contrasts_all_replicates',max(abs(reps[,5:7,drop=FALSE]-reps[,1:4,drop=FALSE]%*%t(p2_contrast_matrix()[5:7,])))<1e-14)
  check('quadratic_covariance_symmetric',max(abs(V-t(V)))<1e-15)
  check('quadratic_covariance_rank_at_most_4',sum(eigen(V,symmetric=TRUE,only.values=TRUE)$values>1e-10)<=4)
  res<-list(estimate=point,replicates=reps,covariance=V,probability_logit_covariance=VL,ci=intervals(point,V,VL,ci_df),diagnostics=do.call(rbind,lapply(fits,`[[`,'diagnostics')),cell_support=do.call(rbind,lapply(fits,`[[`,'cells')),coefficients=do.call(rbind,lapply(fits,`[[`,'coefficients')),metadata=list(model='MAIN_QUADRATIC',new_posthoc=TRUE,n=nrow(d),rank=15,ci_df=ci_df,design_df=16,scale=design$scale,rscales=design$rscales,mse=design$mse,formula=deparse(f),reference='same MAIN pooled MEC empirical distribution',historical_objects_recovered=FALSE))
  saveRDS(res,file.path(out,'MAIN_QUADRATIC_result.rds'))
  write_exact(res$ci,'MAIN_QUADRATIC_estimates.csv');write_exact(res$diagnostics,'MAIN_QUADRATIC_diagnostics.csv');write_exact(res$cell_support,'MAIN_QUADRATIC_cell_support.csv')
  for(nm in c('replicates','covariance','probability_logit_covariance','coefficients')){
    rn<-rownames(res[[nm]]);if(is.null(rn))rn<-as.character(seq_len(nrow(res[[nm]])))
    write_exact(data.frame(row_key=rn,res[[nm]],check.names=FALSE),paste0('MAIN_QUADRATIC_',nm,'.csv'))
  }
  hexd<-res$ci;for(nm in names(hexd))if(is.numeric(hexd[[nm]]))hexd[[nm]]<-sprintf('%a',hexd[[nm]])
  write.csv(hexd,file.path(out,'MAIN_QUADRATIC_estimates_hex.csv'),row.names=FALSE)
  record('MAIN_QUADRATIC','SUCCESS','One joint age/PIR quadratic extension, rank15 and df2; not a replacement primary model')
  res
},error=function(e){record('MAIN_QUADRATIC','UNSTABLE_NOT_ESTIMABLE',conditionMessage(e));NULL})
if(length(quad_attempts))write.csv(do.call(rbind,quad_attempts),file.path(out,'MAIN_QUADRATIC_all_attempts.csv'),row.names=FALSE)

# Prespecified support diagnostics; same geometry and common denominator as original.
inside_hull<-function(points,query,tol=1e-9){
  points<-unique(points);np<-nrow(points);if(np==0)return(rep(FALSE,nrow(query)))
  if(np==1)return(rowSums(abs(sweep(query,2,points[1,],'-')))<tol)
  h<-chull(points[,1],points[,2]);v<-points[h,,drop=FALSE]
  if(length(h)<3){u<-v[nrow(v),]-v[1,];tt<-as.vector(sweep(query,2,v[1,],'-')%*%u/sum(u^2));proj<-outer(tt,u)+matrix(v[1,],nrow(query),2,byrow=TRUE);return(rowSums((query-proj)^2)<tol&tt>=-tol&tt<=1+tol)}
  cr<-sapply(seq_len(nrow(v)),function(i){j<-if(i==nrow(v))1 else i+1;(v[j,1]-v[i,1])*(query[,2]-v[i,2])-(v[j,2]-v[i,2])*(query[,1]-v[i,1])})
  apply(cr,1,function(x)all(x>=-tol)||all(x<=tol))
}
check('geometry_square_boundary',identical(inside_hull(rbind(c(0,0),c(1,0),c(1,1),c(0,1)),rbind(c(.5,.5),c(0,1),c(2,.5))),c(TRUE,TRUE,FALSE)))
check('geometry_degenerate_line',identical(inside_hull(rbind(c(0,0),c(2,2)),rbind(c(1,1),c(1,0))),c(TRUE,FALSE)))
d$catkey<-interaction(d$sex,d$race,d$education,drop=FALSE,sep='|')
d$agebin<-cut(d$age10*10+45,c(20,30,40,50,60,70),right=FALSE)
d$pirbin<-cut(d$PIR,c(-1e-8,1,2,4,5.000001),right=FALSE)
d$finekey<-interaction(d$catkey,d$agebin,d$pirbin,drop=FALSE,sep='|')
scales<-apply(d[c('age10','PIR')],2,sd);summ<-list();flags<-list();cats<-list();fines<-list()
for(g in 0:1)for(a in 0:1){
  target<-d[d$G==g&d$A==a,];catn<-table(target$catkey);finen<-table(target$finekey)
  nc<-as.integer(catn[as.character(d$catkey)]);nf<-as.integer(finen[as.character(d$finekey)])
  inrect<-inhull<-rep(FALSE,nrow(d));near<-rep(Inf,nrow(d))
  for(k in levels(d$catkey)){ti<-target$catkey==k;ri<-d$catkey==k;if(any(ti)&&any(ri)){
    pts<-as.matrix(target[ti,c('age10','PIR')]);qry<-as.matrix(d[ri,c('age10','PIR')])
    inrect[ri]<-qry[,1]>=min(pts[,1])&qry[,1]<=max(pts[,1])&qry[,2]>=min(pts[,2])&qry[,2]<=max(pts[,2])
    inhull[ri]<-inside_hull(pts,qry);ps<-sweep(pts,2,scales,'/');qs<-sweep(qry,2,scales,'/')
    near[ri]<-apply(qs,1,function(pt)min(sqrt(rowSums(sweep(ps,2,pt,'-')^2))))}}
  share<-function(x)100*sum(d$WTMEC2YR[x])/sum(d$WTMEC2YR)
  summ[[paste(g,a)]]<-data.frame(G=g,A=a,cat_absent_ref_pct=share(nc==0),cat_lt5_ref_pct=share(nc<5),fine_absent_ref_pct=share(nf==0),outside_within_category_rect_ref_pct=share(!inrect),outside_within_category_hull_ref_pct=share(!inhull),nearest_gt_0p5_SD_pct=share(near>.5),nearest_gt_1_SD_pct=share(near>1),nearest_gt_2_SD_pct=share(near>2),absent_reference_people=sum(nc==0))
  flags[[paste(g,a)]]<-data.frame(G=g,A=a,SEQN=d$SEQN,n_same_cat=nc,n_same_fine=nf,inrect=inrect,inhull=inhull,nearest=near)
  cats[[paste(g,a)]]<-data.frame(G=g,A=a,combination=names(catn),n=as.integer(catn))
  fines[[paste(g,a)]]<-data.frame(G=g,A=a,combination=names(finen),n=as.integer(finen))
}
support<-do.call(rbind,summ);write_exact(support,'MAIN_scenario_support_summary.csv')
write_exact(do.call(rbind,cats),'MAIN_categorical_support_counts.csv');write_exact(do.call(rbind,fines),'MAIN_fine_support_counts.csv')
saveRDS(do.call(rbind,flags),file.path(out,'individual/MAIN_scenario_support_flags.rds'))
if(!is.null(support_baseline)){
  old<-read.csv(support_baseline)
  stopifnot(identical(names(old),names(support)),nrow(old)==nrow(support))
  diffs<-vapply(names(old),function(nm)max(abs(old[[nm]]-support[[nm]])),numeric(1))
  write_exact(data.frame(field=names(diffs),max_absolute_difference=unname(diffs)),'SUPPORT_comparison_with_supplied_baseline.csv')
  check('support_recalculation_matches_supplied_baseline_precision',max(diffs)<1e-10)
} else {
  checkrows[[length(checkrows)+1L]]<-data.frame(check='support_baseline_comparison',passed=NA,detail='NOT_RUN: optional comparison baseline not supplied; support recalculation completed independently')
}
record('MAIN_SCENARIO_SUPPORT','SUCCESS','New raw-derived input, no trimming; does not certify all model assumptions')
write.csv(do.call(rbind,status),file.path(out,'ANALYSIS_STATUS.csv'),row.names=FALSE)
write.csv(do.call(rbind,checkrows),file.path(out,'CHECKS.csv'),row.names=FALSE)
writeLines(capture.output(sessionInfo()),file.path(out,'sessionInfo.txt'))
cat('All planned robustness tasks attempted.\n');print(do.call(rbind,status));print(df16[df16$estimand=='Delta',]);if(!is.null(quad))print(quad$ci[quad$ci$estimand=='Delta',]);print(support)
