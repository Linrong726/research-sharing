"""Portable fixed robustness entry; no default reference to a historical workspace."""
from pathlib import Path
import argparse,csv,datetime,hashlib,json,re,shutil,subprocess,sys

PUBLIC_OUTPUTS={
 'ANALYSIS_STATUS.csv','CHECKS.csv','WEIGHT_FLOATING_POINT_ROUNDTRIP.csv',
 'MAIN_DF16_intervals.csv','MAIN_PSU_deletion_influence.csv',
 'MAIN_QUADRATIC_result.rds','MAIN_QUADRATIC_estimates.csv','MAIN_QUADRATIC_estimates_hex.csv',
 'MAIN_QUADRATIC_replicates.csv','MAIN_QUADRATIC_covariance.csv','MAIN_QUADRATIC_probability_logit_covariance.csv',
 'MAIN_QUADRATIC_coefficients.csv','MAIN_QUADRATIC_diagnostics.csv','MAIN_QUADRATIC_cell_support.csv','MAIN_QUADRATIC_all_attempts.csv',
 'MAIN_scenario_support_summary.csv','MAIN_categorical_support_counts.csv','MAIN_fine_support_counts.csv',
 'SUPPORT_comparison_with_supplied_baseline.csv'}

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--adjusted-run',required=True,type=Path)
    p.add_argument('--core-code',required=True,type=Path)
    p.add_argument('--output',required=True,type=Path,help='Must not exist; all analysis outputs go here.')
    p.add_argument('--audit-output',type=Path,help='Must not exist; defaults to output name plus _audit.')
    p.add_argument('--rscript',default='Rscript',help='Rscript on PATH or an explicit executable path.')
    p.add_argument('--r-library',type=Path,help='Optional installed R library, otherwise standard .libPaths().')
    p.add_argument('--support-baseline',type=Path,help='Optional aggregate support CSV for comparison only.')
    p.add_argument('--plan-file',type=Path,help='Defaults to package-relative plan/robustness/ROBUSTNESS_PLAN_v1.md.')
    p.add_argument('--plan-lock',type=Path,help='Defaults to PLAN_LOCK.json alongside the plan.')
    a=p.parse_args()
    here=Path(__file__).resolve().parent
    package=here.parent.parent
    a.adjusted_run=a.adjusted_run.resolve(strict=True);a.core_code=a.core_code.resolve(strict=True)
    a.output=a.output.resolve();audit=(a.audit_output or a.output.with_name(a.output.name+'_audit')).resolve()
    if a.output.exists() or audit.exists(): p.error('Output and audit-output must both be new, nonexistent paths.')
    if a.output==audit: p.error('Output and audit-output must differ.')
    rscript=shutil.which(a.rscript)
    if not rscript: p.error('Rscript not found; set --rscript to the installed executable.')
    plan=(a.plan_file or package/'plan/robustness/ROBUSTNESS_PLAN_v1.md').resolve(strict=True)
    plan_lock=(a.plan_lock or plan.with_name('PLAN_LOCK.json')).resolve(strict=True)
    if a.support_baseline:a.support_baseline=a.support_baseline.resolve(strict=True)
    if a.r_library:a.r_library=a.r_library.resolve(strict=True)
    sha=lambda z:hashlib.sha256(z.read_bytes()).hexdigest()
    locked=json.loads(plan_lock.read_text(encoding='utf-8-sig'))
    if sha(plan)!=locked['plan_sha256']: p.error('Frozen scientific plan SHA256 mismatch.')
    rcode=here/'run_robustness.R'
    inputs={'adjusted_design_inputs':a.adjusted_run/'data/design_inputs.rds',
            'adjusted_outcome':a.adjusted_run/'data/research_outcome.rds',
            'adjusted_MAIN_result':a.adjusted_run/'models/MAIN/complete_result.rds',
            'estimator_core_code':a.core_code,'robustness_code':rcode,'portable_runner':Path(__file__).resolve(),
            'frozen_plan':plan,'frozen_plan_lock':plan_lock}
    if a.support_baseline:inputs['optional_support_comparison_baseline']=a.support_baseline
    def identities():return {k:dict(path=str(v),bytes=v.stat().st_size,sha256=sha(v)) for k,v in inputs.items()}
    before=identities();audit.mkdir(parents=True,exist_ok=False)
    # Keep file bytes for code provenance separately from public aggregate outputs.
    code_snap=audit/'executed_code';code_snap.mkdir()
    for key in ['estimator_core_code','robustness_code','portable_runner']:
        shutil.copy2(inputs[key],code_snap/inputs[key].name)
    cmd=[rscript,'--vanilla',str(rcode),'--adjusted-run',str(a.adjusted_run),'--core-code',str(a.core_code),'--output',str(a.output)]
    if a.r_library:cmd+=['--r-library',str(a.r_library)]
    if a.support_baseline:cmd+=['--support-baseline',str(a.support_baseline)]
    started=datetime.datetime.now(datetime.timezone.utc).isoformat()
    execution={'started_utc':started,'post_hoc':True,'new_mean_model_count':1,'inputs_before':before,'command':cmd,'frozen_plan_sha256':locked['plan_sha256']}
    (audit/'EXECUTION_LOCK.json').write_text(json.dumps(execution,indent=2),encoding='utf-8')
    done=subprocess.run(cmd,capture_output=True,text=True)
    (audit/'stdout.txt').write_text(done.stdout,encoding='utf-8');(audit/'stderr.txt').write_text(done.stderr,encoding='utf-8')
    after=identities();execution.update(ended_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),exit_code=done.returncode,inputs_after=after,input_hashes_unchanged=before==after)
    (audit/'EXECUTION_RESULT.json').write_text(json.dumps(execution,indent=2),encoding='utf-8')
    def readrows(name):
        z=a.output/name
        if not z.exists():return []
        with z.open(encoding='utf-8-sig',newline='') as f:return list(csv.DictReader(f))
    public=[];private=[]
    local_path_pattern=re.compile(r'(?i)\b[A-Z]:[/\\]|/(?:Users|home|mnt)/')
    if a.output.exists():
        for z in sorted(a.output.rglob('*')):
            if not z.is_file():continue
            rel=z.relative_to(a.output).as_posix()
            item=dict(path=rel,bytes=z.stat().st_size,sha256=sha(z))
            path_text=bool(z.suffix=='.csv' and local_path_pattern.search(z.read_text(encoding='utf-8-sig')))
            if rel in PUBLIC_OUTPUTS and not path_text:public.append(item)
            else:private.append(item)
    def public_rows(name):
        return [{k:('DETAIL_RETAINED_IN_LOCAL_AUDIT' if local_path_pattern.search(v) else v)
                 for k,v in row.items()} for row in readrows(name)]
    # Public summary deliberately contains no absolute paths, participant IDs, weights,
    # raw responses, fitted per-person data or run stdout/session environment details.
    summary={'post_hoc':True,'new_mean_model_count':1,'historical_objects_recovered':False,
             'frozen_plan_sha256':locked['plan_sha256'],'optional_support_comparison_requested':bool(a.support_baseline),
             'statuses':public_rows('ANALYSIS_STATUS.csv'),'checks':public_rows('CHECKS.csv'),
             'quadratic_intervals':readrows('MAIN_QUADRATIC_estimates.csv'),
             'MAIN_df16_intervals':readrows('MAIN_DF16_intervals.csv'),
             'scenario_support':readrows('MAIN_scenario_support_summary.csv'),
             'public_aggregate_files':public,
             'sharing_boundary':'Only the explicit public aggregate file list is intended for external materials. individual/, sessionInfo, execution logs and absolute-path provenance remain local audit material.'}
    (audit/'PUBLIC_AGGREGATE_SUMMARY.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2),encoding='utf-8')
    (audit/'LOCAL_AUDIT_FILES.json').write_text(json.dumps({'analysis_output_root':str(a.output),'private_or_unclassified_files':private,'execution_audit_directory':str(audit)},indent=2),encoding='utf-8')
    statuses=summary['statuses']
    completed=done.returncode==0 and len(statuses)==4 and all(z['status']=='SUCCESS' for z in statuses)
    print(json.dumps({'exit_code':done.returncode,'all_four_analyses_success':completed,'inputs_unchanged':before==after,'public_aggregate_files':len(public),'local_audit_files':len(private),'output':str(a.output),'audit':str(audit)},ensure_ascii=False))
    if not completed:print(done.stdout[-3000:]);print(done.stderr[-2000:])
    return 0 if completed and before==after else (done.returncode or 1)

if __name__=='__main__':raise SystemExit(main())
