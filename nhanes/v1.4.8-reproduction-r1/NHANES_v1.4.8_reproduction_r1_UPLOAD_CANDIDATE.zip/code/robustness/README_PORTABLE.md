# 可移植的有限事后稳健性运行

本入口只使用明确传入的本轮 adjusted 复现数据与 MAIN 结果，不默认访问旧工作区或历史派生对象。冻结科学方案、模型、阈值和区间规则未改动。新增模型只有 MAIN_QUADRATIC；MAIN 的 df 敏感性、PSU 删除诊断和四情景支持规则保持不变。

需要 Python 3 标准库、R 及 survey（及其依赖）已安装。包内至少保留：本目录 `execute_portable.py` 与 `run_robustness.R`、同一包根下 `plan/robustness/ROBUSTNESS_PLAN_v1.md` 和 `PLAN_LOCK.json`。旧 `execute_locked.py`、`execute_export_repair.py` 与 `summarize_robustness.py` 是历史工作区执行记录，不是本可移植入口。

已完成的 adjusted run 必须包含：

- `data/design_inputs.rds`：从四 XPT 重建、符合原 p2_align_inputs 契约的全正 MEC 输入。
- `data/research_outcome.rds`：同样从原始 XPT 派生并按 SEQN 标识的 RESEARCH outcome 契约。
- `models/MAIN/complete_result.rds`：该次新调整主分析的结果，含 reference、31×7 replicates、covariance、CI、design_weight_audit 与 metadata。

运行示例（路径可相对当前目录；Windows PowerShell 换行符为反引号）：

```powershell
python code/robustness/execute_portable.py `
  --adjusted-run runs/adjusted/fresh_download `
  --core-code code/adjusted/vendor/02_estimator_core.R `
  --output runs/robustness/fresh_download `
  --audit-output audit/robustness/fresh_download `
  --rscript 'C:/Program Files/R/R-4.6.1/bin/Rscript.exe' `
  --r-library 'PATH/TO/INSTALLED/R-LIBRARY'
```

在正常 R 库环境中可省略 `--r-library`；Rscript 已在 PATH 时可省略 `--rscript`。源码 `--core-code` 必须是本包中已核验的原数值内核，只加载函数，不加载历史数据。默认方案位置相对于脚本所在的包根；改变目录布局时显式传入 `--plan-file` 和 `--plan-lock`。

`--support-baseline some_aggregate.csv` 为可选的历史支持汇总比较。缺省时仍完整计算本轮四情景支持结果，只将额外的 baseline 比较标为 NOT_RUN，不因没有历史基准而中止。提供的基准只用于结果比较，不参与任何 fit、权重、参考样本或支持计算。

output 与 audit-output 必须是两个不存在的新目录；脚本拒绝覆盖旧运行。输入文件在运行前后记录 SHA256，代码原件复制到私有 audit 输出。计划文件核验原 SHA256，不生成新的“原研究预设”标签。

直接 R CLI 也可使用，输出目录需新建或为空：

```text
Rscript --vanilla code/robustness/run_robustness.R --adjusted-run NEW_ADJUSTED_RUN --core-code CORE.R --output NEW_OUTPUT [--r-library LIB] [--support-baseline SUMMARY.csv]
```

## 公共材料与本地逐人对象

Python 入口产生 `PUBLIC_AGGREGATE_SUMMARY.json`，只含相对路径、聚合数值及明确文件白名单。公开时仅收录该列表所列文件及必要代码/方案；不要直接打包整个 run 目录。`MAIN_QUADRATIC_result.rds` 只含聚合估计、重复估计/系数矩阵、协方差、CI、计数诊断和方法元数据，不含逐人记录。

分类组合与 fine support count 文件可能含 n=1 的小单元。这些汇总不含 SEQN 或逐人行，但可能与公开 NHANES 记录关联；本清单不提供匿名性保证，也不声称不存在任何关联信息。

`individual/` 中的 32 次拟合对象、逐人四情景预测、survey design、完整权重、SEQN 支持标识均留在本地独立核查包；`sessionInfo.txt`、stdout/stderr、含绝对路径的 EXECUTION_LOCK/RESULT 与 `LOCAL_AUDIT_FILES.json` 也归本地核查资料。公共摘要不能被理解为把所有保存的 RDS 都许可公开。全部新对象都属于此次执行，不能改称找回的历史对象。

统计结论必须继续保留事后分析、共同参考分布、rank/df 差异、覆盖率未经证明以及缺失/混杂/横断面/外推限制。分析成功不意味着这些局限已经消除。
