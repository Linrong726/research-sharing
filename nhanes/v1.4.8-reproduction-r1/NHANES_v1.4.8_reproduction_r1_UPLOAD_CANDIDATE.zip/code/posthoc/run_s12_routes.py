"""Independent S12 standard-library launcher: SHA-256 manifests and complete R stdout/stderr.

python run_s12_routes.py --rscript Rscript --raw raw --out new_run [--lib R-library]
Only four raw XPT files are scientific inputs. No baseline result is accessed.
"""
from pathlib import Path
import argparse, csv, datetime, hashlib, json, subprocess, sys


def sha256(path):
    h = hashlib.sha256()
    with path.open('rb') as f:
        for block in iter(lambda: f.read(1 << 20), b''):
            h.update(block)
    return h.hexdigest()


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--rscript', default='Rscript')
    p.add_argument('--raw', type=Path, required=True)
    p.add_argument('--out', type=Path, required=True)
    p.add_argument('--lib', default='')
    args = p.parse_args()
    code = Path(__file__).resolve().parent
    raw, out = args.raw.resolve(), args.out.resolve()
    if out.exists() and any(out.iterdir()):
        raise SystemExit('Output must be a new or empty directory.')
    files = [(f'raw/{m}.xpt', raw / f'{m}.xpt', 'scientific_input')
             for m in ('DEMO_F', 'ARQ_F', 'DPQ_F', 'PAQ_F')]
    files += [(f'code/{f.name}', f, 'computation_source') for f in sorted(code.glob('*.R'))]
    files.append((f'code/{Path(__file__).name}', Path(__file__).resolve(), 'launcher'))
    manifest = [dict(path=name, role=role, bytes=f.stat().st_size, sha256=sha256(f))
                for name, f, role in files]
    started = datetime.datetime.now(datetime.timezone.utc).isoformat()
    command = [args.rscript, '--vanilla', str(code / 'run_s12_routes.R'), str(raw), str(out)]
    if args.lib:
        command.append(str(Path(args.lib).resolve()))
    result = subprocess.run(command, capture_output=True)
    audit = out / 'audit'
    audit.mkdir(parents=True, exist_ok=True)
    (audit / 'R_stdout.log').write_bytes(result.stdout)
    (audit / 'R_stderr.log').write_bytes(result.stderr)
    with (audit / 'input_code_SHA256.csv').open('w', encoding='utf-8', newline='') as f:
        writer = csv.DictWriter(f, fieldnames=list(manifest[0]))
        writer.writeheader()
        writer.writerows(manifest)
    unchanged = all(row['sha256'] == sha256(path) for row, (_, path, _) in zip(manifest, files))
    receipt = dict(origin='REPRODUCTION_NEW', started_utc=started,
                   completed_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
                   command=command, returncode=result.returncode,
                   input_and_code_unchanged=unchanged, historical_results_read=False,
                   python_version=sys.version, completed=(audit / 'COMPLETION.csv').exists())
    (audit / 'launch_receipt.json').write_text(json.dumps(receipt, ensure_ascii=False, indent=2), encoding='utf-8')
    outputs = [dict(path=f.relative_to(out).as_posix(), bytes=f.stat().st_size, sha256=sha256(f))
               for f in sorted(out.rglob('*')) if f.is_file()]
    with (audit / 'output_SHA256.csv').open('w', encoding='utf-8', newline='') as f:
        writer = csv.DictWriter(f, fieldnames=['path', 'bytes', 'sha256'])
        writer.writeheader()
        writer.writerows(outputs)
    print(json.dumps(receipt, ensure_ascii=False))
    if result.returncode or not unchanged:
        sys.stderr.buffer.write(result.stderr)
        sys.exit(result.returncode or 2)


if __name__ == '__main__':
    main()
