# Comparison only, after new calculation. No model fitting or new estimation.
# Arguments: NEW_RUN OLD_POSTHOC_RESULTS INDEPENDENT_ADJUSTED_RUN NEW_AUDIT_OUT
args<-commandArgs(trailingOnly=TRUE);stopifnot(length(args)==4)
run<-args[1];old_dir<-args[2];other<-args[3];out<-args[4]
stopifnot(file.exists(file.path(run,'audit/COMPLETION.csv')))
dir.create(out,recursive=TRUE,showWarnings=FALSE)
fresh<-readRDS(file.path(run,'results/UNADJ_MAIN_complete_result.rds'))
old<-readRDS(file.path(old_dir,'UNADJ_MAIN_complete_result.rds'))
checks<-list();scalar_rows<-list()
for(field in c('point','replicates','V4','V7','Vlogit4','scale','rscales','mse')) {
  a<-old[[field]];b<-fresh[[field]]
  equal<-identical(a,b)
  checks[[length(checks)+1L]]<-data.frame(object='UNADJ_MAIN',field=field,elements=length(a),identical=equal)
  if(is.numeric(a))for(i in seq_along(a)) scalar_rows[[length(scalar_rows)+1L]]<-data.frame(object=field,index=i,
    old=sprintf('%.17g',a[i]),new=sprintf('%.17g',b[i]),old_hex=sprintf('%a',a[i]),new_hex=sprintf('%a',b[i]),
    bitwise_equal=identical(as.numeric(a[i]),as.numeric(b[i])))
}
for(field in names(old$ci)) {
  checks[[length(checks)+1L]]<-data.frame(object='UNADJ_MAIN_ci',field=field,elements=length(old$ci[[field]]),
    identical=identical(old$ci[[field]],fresh$ci[[field]]))
}
fresh_d<-readRDS(file.path(run,'data/raw_derived_REPRODUCTION_NEW.rds'))
independent_d<-readRDS(file.path(other,'data/phase2a_audit_data.rds'))
stopifnot(identical(fresh_d$SEQN,independent_d$SEQN))
for(field in names(fresh_d)) {
  a<-fresh_d[[field]];b<-independent_d[[field]]
  checks[[length(checks)+1L]]<-data.frame(object='independent_raw_derivation',field=field,elements=length(a),
    identical=identical(a,b))
}
z<-do.call(rbind,checks);write.csv(z,file.path(out,'binary_and_independent_derivation.csv'),row.names=FALSE)
write.csv(do.call(rbind,scalar_rows),file.path(out,'UNADJ_binary_scalar_hex.csv'),row.names=FALSE)
writeLines(capture.output(sessionInfo()),file.path(out,'comparison_sessionInfo.txt'))
cat(nrow(z),'object-field checks;',sum(!z$identical),'nonidentical.\n')
if(any(!z$identical)){print(z[!z$identical,]);stop('COMPARISON_FAILED')}
