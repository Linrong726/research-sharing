# Pure coding functions: raw missing codes are treated field by field.
yes_no <- function(x) ifelse(x %in% 1:2, x, NA_real_)
dpq_score <- function(x) ifelse(x %in% 0:3, x, NA_real_)
activity_nonparticipation <- function(vigorous, moderate) {
  v <- yes_no(vigorous); m <- yes_no(moderate)
  out <- rep(NA_integer_, length(v))
  out[which(v==2 & m==2)] <- 1L
  out[which(v==1 | m==1)] <- 0L
  out
}
lumbar_state <- function(d) {
  n <- nrow(d); loc <- as.matrix(d[paste0('ARQ020',LETTERS[1:7])])
  selected <- sweep(loc,2,1:7,`==`)
  any_location <- rowSums(selected, na.rm=TRUE)>0
  location_unknown <- rowSums(matrix(loc %in% c(777,999),nrow=n))>0
  has_d <- d$ARQ020D %in% 4
  gate_yes <- d$ARQ010 %in% 1; gate_no <- d$ARQ010 %in% 2
  current <- yes_no(d$ARQ022AD); history3 <- yes_no(d$ARQ024D)
  # Substantive data off the officially routed lumbar path are contradictions.
  details <- intersect(c('ARQ021AD','ARQ021BD','ARQ021CD','ARQ022D','ARQ022AD','ARQ023GD','ARQ023QD','ARQ024D'),names(d))
  detail <- rowSums(!is.na(d[details]))>0
  invalid_location <- rep(FALSE,n)
  for(j in 1:7) {
    valid_codes <- if(j==1) c(1,777,999) else j
    invalid_location <- invalid_location | (!is.na(loc[,j]) & !loc[,j] %in% valid_codes)
  }
  invalid_gate <- !is.na(d$ARQ010) & !d$ARQ010 %in% c(1,2,7,9)
  invalid_detail <- (!is.na(d$ARQ022AD)&!d$ARQ022AD%in%c(1,2,7,9)) | (!is.na(d$ARQ024D)&!d$ARQ024D%in%c(1,2,7,9))
  contradiction <- (!gate_yes & any_location) | (!has_d & detail) | (gate_no & detail) |
    (location_unknown & any_location) | invalid_location | invalid_gate | invalid_detail
  out <- rep('S5_insufficient',n)
  out[gate_no & !contradiction] <- 'S0_no_6wk_lumbar_history'
  out[gate_yes & any_location & !has_d & !location_unknown & !contradiction] <- 'S0_no_6wk_lumbar_history'
  valid <- gate_yes & has_d & !contradiction
  out[which(valid & current==2)] <- 'S1_former_qualifying_symptoms'
  out[which(valid & current==1 & history3==2)] <- 'S2_current_no_3mo_history'
  out[which(valid & current==1 & history3==1)] <- 'S3_current_with_3mo_history'
  out[which(valid & current==1 & is.na(history3))] <- 'S4_current_duration_unknown'
  out[contradiction] <- 'S6_path_inconsistent'
  out
}
state_levels <- c('S0_no_6wk_lumbar_history','S1_former_qualifying_symptoms',
 'S2_current_no_3mo_history','S3_current_with_3mo_history',
 'S4_current_duration_unknown','S5_insufficient','S6_path_inconsistent','OUTSIDE_ARQ_AGE')
