# Usage: Rscript --vanilla run_posthoc.R RAW_XPT_DIRECTORY NEW_OUTPUT_DIRECTORY [R_LIBRARY]
# Scientific inputs: DEMO_F.xpt ARQ_F.xpt DPQ_F.xpt PAQ_F.xpt only.
# The output directory must be new or empty. Baseline comparisons are a separate script.
args<-commandArgs(trailingOnly=TRUE)
if(length(args)<2)stop('Usage: run_posthoc.R RAW_XPT_DIRECTORY NEW_OUTPUT_DIRECTORY [R_LIBRARY]')
script_arg<-grep('^--file=',commandArgs(FALSE),value=TRUE)
code_dir<-dirname(normalizePath(sub('^--file=','',script_arg),winslash='/',mustWork=TRUE))
raw_dir<-normalizePath(args[1],winslash='/',mustWork=TRUE)
task<-normalizePath(args[2],winslash='/',mustWork=FALSE)
if(dir.exists(task)&&length(list.files(task,all.files=TRUE,no..=TRUE)))stop('OUTPUT_DIRECTORY_MUST_BE_EMPTY')
if(length(args)>=3&&nzchar(args[3])) .libPaths(c(normalizePath(args[3],winslash='/',mustWork=TRUE),.libPaths()))
stopifnot(requireNamespace('foreign',quietly=TRUE),requireNamespace('survey',quietly=TRUE))
suppressPackageStartupMessages(library(survey))
options(stringsAsFactors=FALSE,digits=17,na.action='na.fail',survey.lonely.psu='fail',survey.adjust.domain.lonely=FALSE)
for(p in c('results','individual_audit','audit','data'))dir.create(file.path(task,p),recursive=TRUE,showWarnings=FALSE)
sink(file.path(task,'audit/compute.log'),split=TRUE)
cat('Origin: REPRODUCTION_NEW\nStarted UTC:',format(Sys.time(),tz='UTC',usetz=TRUE),'\n')
cat('Scientific inputs: four raw XPT files only. Historical results are not read.\n')
out<-file.path(task,'results');ind<-file.path(task,'individual_audit')
fmt17<-function(x)if(is.numeric(x))ifelse(is.na(x),'NA',sprintf('%.17g',x))else x
wcsv<-function(x,name) {
  x<-as.data.frame(x);x[]<-lapply(x,fmt17)
  write.csv(x,file.path(out,paste0(name,'.csv')),row.names=FALSE,na='NA',fileEncoding='UTF-8')
}
wmat<-function(x,name) {
  x<-as.data.frame(x);x[]<-lapply(x,fmt17)
  write.csv(x,file.path(out,paste0(name,'.csv')),row.names=TRUE,na='NA',fileEncoding='UTF-8')
}
for(s in c('01_definitions.R','01_derive_candidate.R','unadjusted_core.R','flow_missing.R','derive_raw.R','descriptive_tables.R','reference_support.R'))source(file.path(code_dir,s))
inputs<-derive_from_raw(raw_dir);d<-inputs$data
wcsv(inputs$inventory,'Raw_Module_Inventory')
attr(d,'reproduction_origin')<-'REPRODUCTION_NEW; four raw XPT scientific inputs'
saveRDS(d,file.path(task,'data/raw_derived_REPRODUCTION_NEW.rds'),compress='xz')
writeLines(capture.output(sessionInfo()),file.path(task,'audit/sessionInfo_before.txt'))
pkgs<-c('foreign','survey','Matrix','survival','DBI','mitools','Rcpp','minqa','numDeriv','RcppArmadillo')
write.csv(data.frame(package=pkgs,version=vapply(pkgs,function(p)as.character(packageVersion(p)),character(1)),
  path=vapply(pkgs,find.package,character(1))),file.path(task,'audit/package_versions.csv'),row.names=FALSE)
f<-d[d$valid_design,];rownames(f)<-NULL
source(file.path(code_dir,'compute_posthoc.R'))
hx<-ci$ci;hx[]<-lapply(hx,function(x)if(is.numeric(x))ifelse(is.na(x),'NA',sprintf('%a',x))else x)
write.csv(hx,file.path(out,'UNADJ_MAIN_Exact_Hex.csv'),row.names=FALSE,na='NA')
reasons<-c('DPQ_module_absent','DPQ010_system_missing','DPQ010_refused_code_7','DPQ010_do_not_know_code_9')
unknown<-do.call(rbind,lapply(c('age20_69','positive_MEC','candidate_S3_S0'),function(dom) {
  z<-flow$person_audit[flow$masks[[dom]]&flow$person_audit$A_status%in%'A_unknown',]
  stopifnot(sum(z$A_unknown_reason%in%reasons)==nrow(z))
  data.frame(domain=dom,reason=reasons,n=vapply(reasons,function(r)sum(z$A_unknown_reason==r),numeric(1)),A_unknown_total=nrow(z))
}))
wcsv(unknown,'Flow_A_unknown_reasons')
descriptive<-reproduce_descriptive_tables(d,full_rep,W)
support<-reproduce_reference_support(d)
descriptive$TableS7_raw<-support$summary
saveRDS(support$individual,file.path(ind,'Reference_Support_Flags_REPRODUCTION_NEW.rds'),compress='xz')
for(nm in names(descriptive))wcsv(descriptive[[nm]],nm)
saveRDS(descriptive,file.path(out,'Descriptive_tables_REPRODUCTION_NEW.rds'),compress='xz')
write.csv(data.frame(status='COMPLETED',origin='REPRODUCTION_NEW',raw_modules=4,DEMO_n=nrow(d),
  positive_MEC_n=nrow(f),MAIN_n=sum(d$domain),D_known_n=sum(d$domain_D),replicates=ncol(W),
  design_df=degf(full_rep),historical_result_read=FALSE,completed_utc=format(Sys.time(),tz='UTC',usetz=TRUE)),
  file.path(task,'audit/COMPLETION.csv'),row.names=FALSE)
cat('REPRODUCTION_NEW complete: unadjusted result, S13-S15 sources and Table1/S1-S7/S10 recalculated.\n')
sink()
