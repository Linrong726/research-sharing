# The existing Table S7 geometry audit, reproduced from
# phase1b/code/03_support_audit.R. No new estimand or trimming decision.
reproduce_reference_support <- function(d) {
  cc<-d[d$domain,]
  cc$catkey<-interaction(cc$sex,cc$race,cc$education,drop=FALSE,sep='|')
  cc$agebin<-cut(cc$RIDAGEYR,c(20,30,40,50,60,70),right=FALSE,labels=c('20_29','30_39','40_49','50_59','60_69'))
  cc$pirbin<-cut(cc$PIR,c(-1e-8,1,2,4,5.000001),right=FALSE,labels=c('lt1','1_lt2','2_lt4','4_5'))
  cc$jointkey<-interaction(cc$catkey,cc$agebin,cc$pirbin,drop=FALSE,sep='|')
  keys<-levels(cc$catkey)
  inside_hull<-function(points,query,tol=1e-9) {
    points<-unique(points);np<-nrow(points)
    if(np==0)return(rep(FALSE,nrow(query)))
    if(np==1)return(rowSums(abs(sweep(query,2,points[1,],'-')))<tol)
    h<-chull(points[,1],points[,2]);v<-points[h,,drop=FALSE]
    if(length(h)<3) {
      u<-v[nrow(v),]-v[1,];t<-as.vector((sweep(query,2,v[1,],'-')%*%u)/sum(u^2))
      projection<-outer(t,u)+matrix(v[1,],nrow(query),2,byrow=TRUE)
      return(rowSums((query-projection)^2)<tol&t>=-tol&t<=1+tol)
    }
    cross<-sapply(seq_len(nrow(v)),function(i) {
      j<-if(i==nrow(v))1 else i+1
      (v[j,1]-v[i,1])*(query[,2]-v[i,2])-(v[j,2]-v[i,2])*(query[,1]-v[i,1])
    })
    apply(cross,1,function(x)all(x>=-tol)||all(x<=tol))
  }
  stopifnot(identical(inside_hull(rbind(c(0,0),c(1,0),c(1,1),c(0,1)),rbind(c(.5,.5),c(0,1),c(2,.5))),c(TRUE,TRUE,FALSE)),
    identical(inside_hull(rbind(c(0,0),c(2,2)),rbind(c(1,1),c(1,0))),c(TRUE,FALSE)))
  support_summary<-list();detail_list<-list();pooled_scales<-apply(cc[c('age10','PIR')],2,sd)
  for(g in 0:1)for(a in 0:1) {
    target<-cc[cc$G==g&cc$A==a,];cat_n<-table(target$catkey);fine_n<-table(target$jointkey)
    ncat<-as.integer(cat_n[as.character(cc$catkey)]);nfine<-as.integer(fine_n[as.character(cc$jointkey)])
    inrect<-rep(FALSE,nrow(cc));inhull<-rep(FALSE,nrow(cc));nearest_distance<-rep(Inf,nrow(cc))
    for(k in keys) {
      ti<-target$catkey==k;ri<-cc$catkey==k
      if(any(ti)&&any(ri)) {
        pts<-as.matrix(target[ti,c('age10','PIR')]);qry<-as.matrix(cc[ri,c('age10','PIR')])
        inrect[ri]<-qry[,1]>=min(pts[,1])&qry[,1]<=max(pts[,1])&qry[,2]>=min(pts[,2])&qry[,2]<=max(pts[,2])
        inhull[ri]<-inside_hull(pts,qry)
        pts_scaled<-sweep(pts,2,pooled_scales,'/');qry_scaled<-sweep(qry,2,pooled_scales,'/')
        nearest_distance[ri]<-apply(qry_scaled,1,function(point)min(sqrt(rowSums(sweep(pts_scaled,2,point,'-')^2))))
      }
    }
    share<-function(x)100*sum(cc$WTMEC2YR[x])/sum(cc$WTMEC2YR)
    support_summary[[paste(g,a)]]<-data.frame(G=g,A=a,cat_absent_ref_pct=share(ncat==0),cat_lt5_ref_pct=share(ncat<5),
      fine_absent_ref_pct=share(nfine==0),outside_within_category_rect_ref_pct=share(!inrect),
      outside_within_category_hull_ref_pct=share(!inhull),nearest_gt_0p5_SD_pct=share(nearest_distance>.5),
      nearest_gt_1_SD_pct=share(nearest_distance>1),nearest_gt_2_SD_pct=share(nearest_distance>2),absent_reference_people=sum(ncat==0))
    detail_list[[paste(g,a)]]<-data.frame(G=g,A=a,SEQN_reference=cc$SEQN,n_same_cat=ncat,n_same_fine=nfine,
      in_age_PIR_rect=inrect,in_age_PIR_hull=inhull,nearest_scaled_age_PIR=nearest_distance)
  }
  list(summary=do.call(rbind,support_summary),individual=do.call(rbind,detail_list))
}
