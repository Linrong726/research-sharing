"""Post-computation comparison only. Never used to calculate research results.

Historical posthoc estimates/flow files hold 17-digit values and are compared strictly.
Two auxiliary diagnostics were never re-exported by export_exact_saved_results.R
and retain the original 15-digit write.csv output.
Older manuscript descriptive CSVs held 15 significant digits; both exact equality
and compatibility with that documented output rounding are reported separately.
"""
from pathlib import Path
from decimal import Decimal, InvalidOperation, localcontext
from collections import Counter
import argparse, csv, hashlib, json


def read(path):
    with path.open(encoding='utf-8-sig', newline='') as f:
        reader = csv.DictReader(f)
        return reader.fieldnames, list(reader)


def numeric(value):
    try:
        n = Decimal(value)
        return n if n.is_finite() else None
    except InvalidOperation:
        return None


def compare_value(old, new, allow_15_digits):
    if old == new:
        return 'EXACT_TEXT', '0', '0'
    a, b = numeric(old), numeric(new)
    if a is None or b is None:
        return 'MISMATCH', '', ''
    delta = abs(a - b)
    if not delta:
        return 'EXACT_NUMERIC', '0', '0'
    rounding_bound = Decimal(0)
    if allow_15_digits and a:
        rounding_bound = Decimal('0.5') * Decimal(10) ** (a.adjusted() - 14)
    status = 'LEGACY_15_DIGIT_ROUNDING' if delta <= rounding_bound else 'MISMATCH'
    return status, str(delta), str(rounding_bound)


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--run', type=Path, required=True)
    p.add_argument('--posthoc-baseline', type=Path, required=True)
    p.add_argument('--tables-baseline', type=Path, required=True)
    p.add_argument('--out', type=Path, required=True)
    a = p.parse_args()
    if not (a.run / 'audit/COMPLETION.csv').is_file():
        raise SystemExit('New computation must complete before old outputs may be read.')
    a.out.mkdir(parents=True, exist_ok=True)
    ledger, summaries, hashes = [], [], []
    legacy_posthoc = {'JKn_Replicate_Construction_Checks.csv', 'Numerical_Implementation_Checks.csv'}
    pairs = [(f.name, f, a.run / 'results' / f.name, f.name in legacy_posthoc)
             for f in sorted(a.posthoc_baseline.glob('*.csv'))]
    pairs += [(f'Table{table}_raw.csv', a.tables_baseline / f'Table{table}_raw.csv',
               a.run / 'results' / f'Table{table}_raw.csv', True)
              for table in ('1', 'S1', 'S2', 'S3', 'S4', 'S5', 'S6', 'S7', 'S10')]
    for name, old_path, new_path, legacy in pairs:
        old_fields, old = read(old_path)
        new_fields, new = read(new_path)
        if old_fields != new_fields or len(old) != len(new):
            raise AssertionError(f'Schema or row count mismatch: {name}')
        for role, path in (('baseline', old_path), ('new', new_path)):
            hashes.append(dict(file=name, role=role, sha256=hashlib.sha256(path.read_bytes()).hexdigest()))
        statuses = Counter()
        maximum = Decimal(0)
        for i, (before, after) in enumerate(zip(old, new), 1):
            for field in old_fields:
                status, delta, bound = compare_value(before[field], after[field], legacy)
                statuses[status] += 1
                if delta:
                    maximum = max(maximum, Decimal(delta))
                ledger.append(dict(file=name, row=i, field=field,
                    baseline_value=before[field], reproduced_value=after[field],
                    classification=status, absolute_difference=delta,
                    permitted_legacy_output_rounding=bound))
        summaries.append(dict(file=name, rows=len(old), fields=len(old_fields), comparisons=len(old)*len(old_fields),
            exact_text=statuses['EXACT_TEXT'], exact_numeric=statuses['EXACT_NUMERIC'],
            legacy_15_digit_rounding=statuses['LEGACY_15_DIGIT_ROUNDING'], mismatch=statuses['MISMATCH'],
            max_absolute_difference=str(maximum), legacy_15_digit_csv=legacy))
    for name, rows in [('field_comparison.csv', ledger), ('table_summary.csv', summaries), ('comparison_SHA256.csv', hashes)]:
        with (a.out / name).open('w', encoding='utf-8', newline='') as f:
            w = csv.DictWriter(f, fieldnames=list(rows[0])); w.writeheader(); w.writerows(rows)
    report = dict(files=len(summaries), fields=len(ledger), mismatches=sum(r['mismatch'] for r in summaries),
        exact_text=sum(r['exact_text'] for r in summaries), exact_numeric=sum(r['exact_numeric'] for r in summaries),
        legacy_15_digit_rounding=sum(r['legacy_15_digit_rounding'] for r in summaries),
        old_outputs_read_only_after_new_computation=True)
    (a.out / 'comparison_summary.json').write_text(json.dumps(report, indent=2), encoding='utf-8')
    print(json.dumps(report))
    if report['mismatches']:
        raise SystemExit(1)


if __name__ == '__main__':
    with localcontext() as ctx:
        ctx.prec = 60
        main()
