# Reproduction source: audit_phase1/code/02_sample_audit.R and
# phase1b/code/01_derive_candidate.R. Only four official XPT files are read.
# No historical derived dataset or result is a computation input.
derive_from_raw <- function(raw_dir) {
  mods <- c('DEMO_F','ARQ_F','DPQ_F','PAQ_F')
  raw <- setNames(lapply(mods,function(m)
    foreign::read.xport(file.path(raw_dir,paste0(m,'.xpt')))),mods)
  d <- do.call(posthoc_left_link_modules, raw)
  for(v in c('PAQ650','PAQ665','DPQ010','DPQ020')) {
    allowed <- if(startsWith(v,'PAQ')) c(1,2,7,9) else c(0:3,7,9)
    if(any(!is.na(d[[v]]) & !d[[v]] %in% allowed)) stop('ILLEGAL_RAW_CODE: ',v)
  }
  d$eligible_age <- !is.na(d$RIDAGEYR) & d$RIDAGEYR>=20 & d$RIDAGEYR<=69
  d$state <- lumbar_state(d); d$state[!d$eligible_age] <- 'OUTSIDE_ARQ_AGE'
  d$state <- factor(d$state,levels=state_levels)
  d$DPQ010_clean <- dpq_score(d$DPQ010); d$DPQ020_clean <- dpq_score(d$DPQ020)
  d$A <- ifelse(is.na(d$DPQ010_clean),NA_integer_,as.integer(d$DPQ010_clean>=1))
  d$A_high <- ifelse(is.na(d$DPQ010_clean),NA_integer_,as.integer(d$DPQ010_clean>=2))
  d$Y <- activity_nonparticipation(d$PAQ650,d$PAQ665)
  d$age10 <- (d$RIDAGEYR-45)/10
  d$sex <- factor(d$RIAGENDR,levels=1:2)
  d$race <- factor(d$RIDRETH1,levels=1:5)
  d$education <- factor(ifelse(d$DMDEDUC2 %in% 1:2,'less_HS',
    ifelse(d$DMDEDUC2==3,'HS_GED',ifelse(d$DMDEDUC2 %in% 4:5,'above_HS',NA))),
    levels=c('less_HS','HS_GED','above_HS'))
  d$PIR <- ifelse(!is.na(d$INDFMPIR)&d$INDFMPIR>=0&d$INDFMPIR<=5,d$INDFMPIR,NA_real_)
  d$cov_complete <- complete.cases(d[c('age10','sex','race','education','PIR')])
  d$valid_design <- !is.na(d$WTMEC2YR)&d$WTMEC2YR>0&!is.na(d$SDMVSTRA)&!is.na(d$SDMVPSU)
  d <- derive_phase1b(d)
  d <- d[order(d$SEQN),]; rownames(d)<-NULL
  list(data=d,inventory=do.call(rbind,lapply(mods,function(m)
    data.frame(module=m,rows=nrow(raw[[m]]),columns=ncol(raw[[m]]),
      unique_SEQN=length(unique(raw[[m]]$SEQN)),MD5=unname(tools::md5sum(file.path(raw_dir,paste0(m,'.xpt'))))))))
}
