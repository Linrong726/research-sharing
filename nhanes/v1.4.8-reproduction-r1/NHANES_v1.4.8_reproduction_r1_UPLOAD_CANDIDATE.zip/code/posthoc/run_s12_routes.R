# Independent S12 reproduction. Usage: run_s12_routes.R RAW_XPT NEW_OUT [R_LIBRARY]
# Reproduces only the original three configurations x two predicates x seven
# overlapping domains. Zero matches do not prove exhaustive routing validity.
args<-commandArgs(trailingOnly=TRUE)
if(length(args)<2)stop('Usage: run_s12_routes.R RAW_XPT NEW_OUT [R_LIBRARY]')
script_arg<-grep('^--file=',commandArgs(FALSE),value=TRUE)
code_dir<-dirname(normalizePath(sub('^--file=','',script_arg),winslash='/',mustWork=TRUE))
raw_dir<-normalizePath(args[1],winslash='/',mustWork=TRUE)
out<-normalizePath(args[2],winslash='/',mustWork=FALSE)
if(dir.exists(out)&&length(list.files(out,all.files=TRUE,no..=TRUE)))stop('OUTPUT_DIRECTORY_MUST_BE_EMPTY')
if(length(args)>=3&&nzchar(args[3])).libPaths(c(normalizePath(args[3],winslash='/',mustWork=TRUE),.libPaths()))
options(stringsAsFactors=FALSE,digits=17)
dir.create(out,recursive=TRUE,showWarnings=FALSE);dir.create(file.path(out,'audit'))
sink(file.path(out,'audit/Route_Query_Run.log'),split=TRUE)
cat('REPRODUCTION_NEW: S12 from four raw XPT inputs.\n')
for(s in c('01_definitions.R','01_derive_candidate.R','flow_missing.R','derive_raw.R'))source(file.path(code_dir,s))
derived<-derive_from_raw(raw_dir);d<-derived$data
write.csv(derived$inventory,file.path(out,'audit/Raw_Module_Inventory.csv'),row.names=FALSE)
fields<-c('ARQ010',paste0('ARQ020',LETTERS[1:7]),'ARQ021AD','ARQ021BD','ARQ021CD','ARQ022D','ARQ022AD','ARQ023GD','ARQ023QD','ARQ024D','ARQ025D','ARD026D')
r<-d[c('SEQN',fields)];has_arq<-d$in_ARQ_F
domains<-list(DEMO_merged_all=rep(TRUE,nrow(d)),RAW_ARQ_all=has_arq,
  age20_69=d$RIDAGEYR>=20&d$RIDAGEYR<=69,positive_MEC_all=d$valid_design,
  age20_69_positive_MEC=d$eligible_age&d$valid_design,MAIN=d$domain,D_known=d$domain_D)
# Historical rule descriptions are retained verbatim to permit output comparison;
# they describe the original locked rule, not a file read by this new computation.
domain_rules<-c(DEMO_merged_all='all rows of frozen phase2a_audit_data.rds, DEMO anchored',
  RAW_ARQ_all='SEQN has a row in original ARQ_F.xpt',age20_69='RIDAGEYR >= 20 & RIDAGEYR <= 69',
  positive_MEC_all='frozen valid_design == TRUE; positive WTMEC2YR and nonmissing SDMVSTRA/SDMVPSU',
  age20_69_positive_MEC='frozen eligible_age & valid_design',MAIN='frozen domain == TRUE (also A_HIGH)',
  D_known='frozen domain_D == TRUE (both D_BASE and D_PLUS)')
stopifnot(all(vapply(domains,function(x)is.logical(x)&&!anyNA(x),logical(1))))
proto<-setNames(as.list(rep(NA_real_,length(fields))),fields);proto$ARQ010<-2
cases<-list();cases$ARQ025D<-proto;cases$ARQ025D$ARQ025D<-1
cases$ARD026D<-proto;cases$ARD026D$ARD026D<-1
cases$current_yes_last_not_now<-proto
cases$current_yes_last_not_now$ARQ010<-1;cases$current_yes_last_not_now$ARQ020D<-4
cases$current_yes_last_not_now$ARQ022AD<-1;cases$current_yes_last_not_now$ARQ024D<-1
cases$current_yes_last_not_now$ARQ023GD<-3
exact<-lapply(cases,function(x){ans<-has_arq;for(v in fields){want<-x[[v]];ans<-ans&if(is.na(want))is.na(r[[v]])else r[[v]]%in%want};ans})
exact_query<-vapply(cases,function(x)paste(c('has_ARQ_record',vapply(fields,function(v)
  if(is.na(x[[v]]))paste0('is.na(',v,')')else paste0(v,' %in% ',x[[v]]),character(1))),collapse=' & '),character(1))
broad<-list(ARQ025D=has_arq&!r$ARQ020D%in%4&!is.na(r$ARQ025D),
  ARD026D=has_arq&!r$ARQ020D%in%4&!is.na(r$ARD026D),
  current_yes_last_not_now=has_arq&r$ARQ022AD%in%1&(!is.na(r$ARQ023GD)|!is.na(r$ARQ023QD)))
broad_query<-c(ARQ025D='has_ARQ_record & !(ARQ020D %in% 4) & !is.na(ARQ025D)',
  ARD026D='has_ARQ_record & !(ARQ020D %in% 4) & !is.na(ARD026D)',
  current_yes_last_not_now='has_ARQ_record & (ARQ022AD %in% 1) & (!is.na(ARQ023GD) | !is.na(ARQ023QD))')
output<-list()
for(case in names(cases))for(scope in c('exact_18_field_counterexample','broader_offpath_family'))for(dom in names(domains)) {
  take<-domains[[dom]];pred<-if(scope=='exact_18_field_counterexample')exact[[case]]else broad[[case]]
  stopifnot(!anyNA(pred));hits<-take&pred
  output[[length(output)+1L]]<-data.frame(case_id=case,predicate_scope=scope,domain_id=dom,
    domain_definition=domain_rules[[dom]],denominator_n=sum(take),ARQ_record_available_n=sum(take&has_arq),
    outside_ARQ_record_n=sum(take&!has_arq),observed_count=sum(hits),
    SEQN_summary=if(any(hits))'MATCHES_EXIST_IDENTITIES_NOT_EXPORTED'else'NONE',
    exact_query=if(scope=='exact_18_field_counterexample')exact_query[[case]]else broad_query[[case]],
    query_status='EXECUTED_READ_ONLY',note='Domain denominator is not number of eligible ARQ answers; outside-ARQ rows explicitly reported')
}
result<-do.call(rbind,output)
stopifnot(nrow(result)==42)
write.csv(result,file.path(out,'Route_Domain_Counts_Raw.csv'),row.names=FALSE,na='NA',fileEncoding='UTF-8')
domain_table<-unique(result[c('domain_id','denominator_n','ARQ_record_available_n','outside_ARQ_record_n')])
write.csv(domain_table,file.path(out,'TableS12_domains_REPRODUCTION_NEW.csv'),row.names=FALSE)
inputs<-do.call(rbind,lapply(names(cases),function(case)data.frame(case_id=case,field=fields,
  input_value=vapply(cases[[case]],function(x)if(is.na(x))'NA'else as.character(x),character(1)))))
write.csv(inputs,file.path(out,'Counterexample_Complete_Inputs.csv'),row.names=FALSE)
writeLines(capture.output(sessionInfo()),file.path(out,'audit/sessionInfo.txt'))
write.csv(data.frame(origin='REPRODUCTION_NEW',scientific_inputs='four raw XPT files',query_count=nrow(result),
  total_observed_matches=sum(result$observed_count),domains=nrow(domain_table),historical_results_read=FALSE,
  exhaustive_validation=FALSE,completed_utc=format(Sys.time(),tz='UTC',usetz=TRUE)),file.path(out,'audit/COMPLETION.csv'),row.names=FALSE)
cat('Completed',nrow(result),'bounded queries; total matches',sum(result$observed_count),'.\n')
cat('The seven domains overlap; zeros are not exhaustive validation of questionnaire routing.\n')
sink()
