# Reuse Phase 1's audited pure coding functions; never source its output-writing entry.
derive_phase1b <- function(d) {
  state_new <- lumbar_state(d)
  state_new[!d$eligible_age] <- 'OUTSIDE_ARQ_AGE'
  stopifnot(identical(as.character(d$state),state_new))
  A_new <- ifelse(is.na(dpq_score(d$DPQ010)),NA_integer_,as.integer(dpq_score(d$DPQ010)>=1))
  Y_new <- activity_nonparticipation(d$PAQ650,d$PAQ665)
  stopifnot(identical(d$A,A_new),identical(d$Y,Y_new))
  # Avoid retaining old S3/S1 flags under names that could be mistaken for this domain.
  for(v in intersect(c('G','core_observed','strict_core','strict_cc'),names(d))) {
    d[[paste0('phase1_',v)]]<-d[[v]];d[[v]]<-NULL
  }
  d$G <- ifelse(state_new=='S3_current_with_3mo_history',1L,ifelse(state_new=='S0_no_6wk_lumbar_history',0L,NA_integer_))
  d$S0_source <- ifelse(state_new=='S0_no_6wk_lumbar_history' & d$ARQ010%in%2,'S0a',ifelse(state_new=='S0_no_6wk_lumbar_history' & d$ARQ010%in%1,'S0b',NA_character_))
  stopifnot(all(!is.na(d$S0_source[d$G%in%0])))
  d$D <- ifelse(is.na(dpq_score(d$DPQ020)),NA_integer_,as.integer(dpq_score(d$DPQ020)>=1))
  d$candidate <- d$eligible_age & !is.na(d$G)
  d$domain_core <- d$candidate & d$valid_design & !is.na(d$A) & !is.na(d$Y)
  d$domain <- d$domain_core & d$cov_complete
  d$domain_D <- d$domain & !is.na(d$D)
  d
}
