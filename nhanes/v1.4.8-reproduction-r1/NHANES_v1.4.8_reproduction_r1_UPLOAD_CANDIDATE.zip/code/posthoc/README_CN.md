# 从四份 XPT 复现描述表、未调整估计与流程/缺失表

本目录是 2026-09-18 用户授权的重新计算入口。科学输入仅为 NHANES 2009–2010 的 `DEMO_F.xpt`、`ARQ_F.xpt`、`DPQ_F.xpt`、`PAQ_F.xpt`。计算入口不读取旧逐人 RDS、旧模型对象或旧汇总结果。旧结果比较是完成计算后才执行的独立步骤。

## 运行

需要 Python 3（仅标准库）、R 和 `foreign`、`survey` 及其依赖。审计所用环境为 R 4.6.1，survey 4.5；运行时将保存实际包版本和会话信息。脚本不联网安装依赖。

```text
python code/posthoc/run_with_manifest.py --rscript /path/to/Rscript --raw /path/to/raw --out /path/to/NEW_EMPTY_RUN --lib /path/to/R-library
```

`--lib` 可省略，届时使用 R 默认库。输出目录须为新目录或空目录。路径通过参数传入，代码中没有原工作站绝对路径。直接用 R 也可运行：

```text
Rscript --vanilla code/posthoc/run_posthoc.R /path/to/raw /path/to/NEW_EMPTY_RUN /path/to/R-library
```

Python 启动器额外保存输入/代码 SHA-256、完整标准输出/错误输出、启动收据和输出文件 SHA-256。直接 R 入口仍保存运行日志、包版本、会话、输入 MD5、原始模块盘点和完成收据。

## 实际计算内容

- 从完整 DEMO 左连接三个问卷模块，按 SEQN 对齐且保留各模块记录存在标记。
- 复用原纯函数的腰部表型、DPQ、PAQ 规则；从原始字段派生年龄、性别、种族/族裔、教育、PIR、G、A、A_high、D、Y 和固定分析域。
- 在完整正 MEC 权重样本上新建 Taylor 设计与 JKn 复制权重，然后提取 MAIN 域。保留完整设计、全部复制权重、每个复制的分母/事件诊断及未调整联合协方差。
- 重算 `UNADJ_MAIN` 的七项点估计、31×7 复制估计、V4/V7、概率 logit 协方差和置信区间；执行与 `withReplicates`、`svrVar` 和线性对比公式的交叉验证。
- 重算主文 Table 1、补表 S1–S7/S10 的数值来源，以及 S13–S15 的未调整结果、流程和缺失来源。S7 是原已有支持范围描述，不是新增分析或新筛选规则。
- 所有汇总浮点数导出 17 位有效数字；未调整估计另存十六进制浮点表达。历史对象比较由另两个脚本执行。

函数 `posthoc_flow_missing(..., 'POSTHOC_LOCKED')` 保留原接口枚举；这只是既有函数的执行标签，不声称本次重跑预注册，也不改变历史分析的事后性质。

## 比较步骤（可选，非计算依赖）

```text
python code/posthoc/compare_results.py --run NEW_RUN --posthoc-baseline OLD_POSTHOC_RESULTS --tables-baseline OLD_TABLES --out NEW_COMPARISON_DIR
Rscript --vanilla code/posthoc/compare_binary.R NEW_RUN OLD_POSTHOC_RESULTS INDEPENDENT_ADJUSTED_RUN NEW_COMPARISON_DIR
```

第一个脚本逐字段比较 22 份旧 posthoc CSV 与 9 份稿件描述表。未调整主结果、复制结果、协方差、流程/缺失数值按 17 位严格比较；9 份旧描述表和 2 份原来未重新精确导出的辅助诊断只在旧 `write.csv` 15 位有效数字的半个末位单位内标记 `LEGACY_15_DIGIT_ROUNDING`。这种标记与完全相等明确分开，不称作二进制一致。

第二个脚本比较旧未调整 RDS 的点估计、全部复制、协方差、CI，以及另一个独立从原始 XPT 派生的调整分析数据。对象元数据中的新时间戳与旧时间戳不作科学数值相等要求。

## 输出边界

`results/` 是汇总结果；`data/` 和 `individual_audit/` 是本次产生的逐人派生数据及设计对象，仅供本地运行核查。它们标记为 `REPRODUCTION_NEW`，不冒充找回的历史对象。对外共享包可保留代码和汇总 CSV，让使用者从 CDC 自行获取四份 XPT 并在本地生成逐人对象。

本流程不重定义表型、不改变完整案例纳入、不增加模型/亚组/阈值搜索。成功重跑证明固定输入和实现的计算可复现，不会消除横断面设计、非应答选择、残余混杂、测量错分、有限设计自由度或参考支持不足。

## 原规则来源

| 新文件 | 原规则/实现来源 | 改动 |
|---|---|---|
| 01_definitions.R | audit_phase1/code/01_definitions.R | 原样复制纯函数 |
| 01_derive_candidate.R | phase1b/code/01_derive_candidate.R | 原样复制纯函数 |
| flow_missing.R | step3r/posthoc144/code/flow_missing.R | 原样复制纯函数 |
| unadjusted_core.R | step3r/posthoc144/code/unadjusted_core.R | 原样复制纯函数 |
| derive_raw.R | audit_phase1/code/02_sample_audit.R；phase1b/code/01_derive_candidate.R；step3r/posthoc144/code/prepare_identity.R | 仅保留原始字段派生与校验；独立从 XPT 计算，删除历史 RDS 输入 |
| compute_posthoc.R | step3r/posthoc144/code/run_posthoc_v1.0.2.R | 移除硬编码路径、旧对象读取与原目录写入；新对象增加来源标签；数值公式和检验保留 |
| descriptive_tables.R | phase1b/code/02_candidate_audit.R；phase1b/code/03_support_audit.R；phase2a/code/01_prepare_inputs.R；phase2b/code/01_build_tables.py | 提取已有描述统计公式/字段，将结果汇总成原表结构 |
| reference_support.R | phase1b/code/03_support_audit.R | 封装已有分类支持、分箱、矩形/凸包与标准化最近距离计算 |
| run_posthoc.R；run_with_manifest.py | 本次新建 | CLI、独立输出、完整精度、环境和哈希记录 |
| compare_results.py；compare_binary.R | 本次新建 | 仅计算完成后比较旧结果，不参与估计 |
