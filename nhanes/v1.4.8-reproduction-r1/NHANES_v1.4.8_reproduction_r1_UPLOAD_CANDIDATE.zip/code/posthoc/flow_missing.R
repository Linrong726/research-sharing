# Post hoc S14/S15 reporting helpers. Pure base-R functions; no input reads,
# output writes, model fits, or real-data execution occur when this is sourced.
# Frozen variable derivation remains the caller's responsibility.

ph_assert <- function(ok, message) {
  if (!isTRUE(ok)) stop(paste0('POSTHOC_FLOW: ', message), call. = FALSE)
}

ph_ids <- function(x, name) {
  ph_assert(is.data.frame(x) && 'SEQN' %in% names(x), paste(name, 'requires SEQN'))
  ph_assert(is.numeric(x$SEQN) && !anyNA(x$SEQN) &&
              all(is.finite(x$SEQN)) && all(x$SEQN == floor(x$SEQN)) &&
              !anyDuplicated(x$SEQN), paste(name, 'SEQN must be unique finite integers'))
}

posthoc_left_link_modules <- function(DEMO_F, ARQ_F, DPQ_F, PAQ_F) {
  # Preserve the complete DEMO anchor. Missing ARQ/PAQ never erase observed DPQ.
  ph_ids(DEMO_F, 'DEMO_F')
  d <- DEMO_F[order(DEMO_F$SEQN), , drop = FALSE]
  rownames(d) <- NULL
  modules <- list(ARQ_F = ARQ_F, DPQ_F = DPQ_F, PAQ_F = PAQ_F)
  for (module in names(modules)) {
    z <- modules[[module]]
    ph_ids(z, module)
    ph_assert(all(z$SEQN %in% d$SEQN), paste(module, 'contains non-DEMO SEQN'))
    fields <- setdiff(names(z), 'SEQN')
    ph_assert(!any(fields %in% names(d)), paste(module, 'has overlapping non-ID fields'))
    flag <- paste0('in_', module)
    ph_assert(!flag %in% names(d), paste('presence flag already exists:', flag))
    ix <- match(d$SEQN, z$SEQN)
    d[[flag]] <- !is.na(ix)
    for (field in fields) d[[field]] <- z[[field]][ix]
  }
  ph_assert(identical(d$SEQN, sort(DEMO_F$SEQN)), 'DEMO membership altered by link')
  d
}

posthoc_flow_missing <- function(d, execution_label) {
  ph_assert(!missing(execution_label) && length(execution_label) == 1L &&
              execution_label %in% c('SYNTHETIC_ONLY', 'POSTHOC_LOCKED'),
            'caller must identify SYNTHETIC_ONLY or POSTHOC_LOCKED execution')
  required <- c('SEQN','RIDAGEYR','WTMEC2YR','SDMVSTRA','SDMVPSU',
                'DPQ010','DPQ020','PAQ650','PAQ665',
                'in_ARQ_F','in_DPQ_F','in_PAQ_F','eligible_age','valid_design',
                'state','G','S0_source','A','Y','D',
                'age10','sex','race','education','PIR','cov_complete')
  ph_assert(all(required %in% names(d)),
            paste('missing columns:', paste(setdiff(required, names(d)), collapse = ', ')))
  ph_ids(d, 'derived complete DEMO data')
  d <- d[order(d$SEQN), , drop = FALSE]
  rownames(d) <- NULL
  n <- nrow(d)
  flags <- c('in_ARQ_F','in_DPQ_F','in_PAQ_F','eligible_age','valid_design','cov_complete')
  for (v in flags) ph_assert(is.logical(d[[v]]) && !anyNA(d[[v]]), paste(v, 'must be complete logical'))
  ph_assert(!any(is.infinite(d$WTMEC2YR)), 'infinite MEC weight')
  age <- !is.na(d$RIDAGEYR) & d$RIDAGEYR >= 20 & d$RIDAGEYR <= 69
  ph_assert(identical(d$eligible_age, age), 'eligible_age disagrees with RIDAGEYR')
  design <- !is.na(d$WTMEC2YR) & d$WTMEC2YR > 0 &
    !is.na(d$SDMVSTRA) & !is.na(d$SDMVPSU)
  ph_assert(identical(d$valid_design, design), 'valid_design disagrees with frozen definition')
  covars <- c('age10','sex','race','education','PIR')
  ph_assert(identical(d$cov_complete, complete.cases(d[covars])), 'cov_complete disagreement')
  rules <- list(DPQ010 = c(0:3,7,9), DPQ020 = c(0:3,7,9),
                PAQ650 = c(1,2,7,9), PAQ665 = c(1,2,7,9))
  for (v in names(rules)) {
    ph_assert(all(is.na(d[[v]]) | d[[v]] %in% rules[[v]]), paste('illegal raw code:', v))
  }
  ph_assert(all(d$in_DPQ_F | (is.na(d$DPQ010) & is.na(d$DPQ020))), 'DPQ values exist without DPQ module')
  ph_assert(all(d$in_PAQ_F | (is.na(d$PAQ650) & is.na(d$PAQ665))), 'PAQ values exist without PAQ module')
  expected_A <- ifelse(d$DPQ010 %in% 0:3, as.integer(d$DPQ010 >= 1), NA_integer_)
  expected_D <- ifelse(d$DPQ020 %in% 0:3, as.integer(d$DPQ020 >= 1), NA_integer_)
  expected_Y <- rep(NA_integer_, n)
  expected_Y[d$PAQ650 %in% 2 & d$PAQ665 %in% 2] <- 1L
  expected_Y[d$PAQ650 %in% 1 | d$PAQ665 %in% 1] <- 0L
  equal_values <- function(x,y) isTRUE(all.equal(x,y,check.attributes=FALSE,tolerance=0))
  ph_assert(equal_values(d$A, expected_A), 'A disagrees with raw DPQ010')
  ph_assert(equal_values(d$D, expected_D), 'D disagrees with raw DPQ020')
  ph_assert(equal_values(d$Y, expected_Y), 'Y disagrees with frozen PAQ rule')

  states <- c('S0_no_6wk_lumbar_history','S1_former_qualifying_symptoms',
              'S2_current_no_3mo_history','S3_current_with_3mo_history',
              'S4_current_duration_unknown','S5_insufficient','S6_path_inconsistent')
  ph_assert(all(as.character(d$state[age]) %in% states), 'unexpected age-eligible phenotype state')
  expected_G <- ifelse(d$state %in% states[4], 1L,
                       ifelse(d$state %in% states[1], 0L, NA_integer_))
  ph_assert(equal_values(d$G, expected_G), 'G disagrees with frozen classifier state')
  ph_assert(all(as.character(d$S0_source[d$G %in% 0]) %in% c('S0a','S0b')), 'S0 source missing/invalid')

  A_status <- rep(NA_character_, n) # Outside age range deliberately unassigned.
  A_status[age] <- 'A_unknown'
  A_status[age & expected_A %in% 0] <- 'A0'
  A_status[age & expected_A %in% 1] <- 'A1'
  A_unknown_reason <- rep('not_applicable', n)
  A_unknown_reason[age & !is.na(expected_A)] <- 'A_known'
  A_unknown_reason[age & is.na(expected_A) & !d$in_DPQ_F] <- 'DPQ_module_absent'
  A_unknown_reason[age & d$in_DPQ_F & is.na(d$DPQ010)] <- 'DPQ010_system_missing'
  A_unknown_reason[age & d$in_DPQ_F & d$DPQ010 %in% 7] <- 'DPQ010_refused_code_7'
  A_unknown_reason[age & d$in_DPQ_F & d$DPQ010 %in% 9] <- 'DPQ010_do_not_know_code_9'

  masks <- list(DEMO_all=rep(TRUE,n), age20_69=age)
  masks$four_modules <- age & d$in_ARQ_F & d$in_DPQ_F & d$in_PAQ_F
  masks$positive_MEC <- masks$four_modules & design
  masks$candidate_S3_S0 <- masks$positive_MEC & !is.na(d$G)
  masks$A_known <- masks$candidate_S3_S0 & !is.na(d$A)
  masks$Y_known_core <- masks$A_known & !is.na(d$Y)
  masks$covariate_complete <- masks$Y_known_core & d$cov_complete
  D_known <- masks$covariate_complete & !is.na(d$D) # Side branch, not a MAIN exclusion.
  for (i in seq_along(masks)) {
    ph_assert(is.logical(masks[[i]]) && !anyNA(masks[[i]]), 'incomplete stage mask')
    if(i>1) ph_assert(all(!masks[[i]] | masks[[i-1]]), 'non-nested stage masks')
  }
  for (pair in list(c('domain_core','Y_known_core'), c('domain','covariate_complete'))) {
    if(pair[1] %in% names(d)) ph_assert(identical(d[[pair[1]]],masks[[pair[2]]]),paste('frozen mask mismatch:',pair[1]))
  }
  if('domain_D' %in% names(d)) ph_assert(identical(d$domain_D,D_known),'frozen domain_D mismatch')

  missing_module_combination <- apply(!as.matrix(d[c('in_ARQ_F','in_DPQ_F','in_PAQ_F')]),1,
      function(x) if(any(x)) paste(c('ARQ_F','DPQ_F','PAQ_F')[x],collapse='+') else 'none')
  cov_missing_combination <- apply(is.na(d[covars]),1,
      function(x) if(any(x)) paste(covars[x],collapse='+') else 'none')
  first_failed_step <- rep('MAIN_retained',n)
  first_failed_detail <- rep('MAIN_retained',n)
  for (i in 2:length(masks)) {
    fail <- masks[[i-1]] & !masks[[i]]
    first_failed_step[fail] <- names(masks)[i]
    first_failed_detail[fail] <- switch(names(masks)[i],
      age20_69=ifelse(is.na(d$RIDAGEYR[fail]),'age_missing','outside_age20_69'),
      four_modules=missing_module_combination[fail],
      positive_MEC=rep('nonpositive_or_missing_MEC_or_missing_design_field',sum(fail)),
      candidate_S3_S0=as.character(d$state[fail]),
      A_known=A_unknown_reason[fail],
      Y_known_core=rep('no_explicit_PAQ_yes_with_at_least_one_unknown',sum(fail)),
      covariate_complete=cov_missing_combination[fail])
  }
  ph_assert(sum(first_failed_step=='MAIN_retained')==sum(masks$covariate_complete),'first-failed partition mismatch')
  for (i in 2:length(masks)) ph_assert(sum(first_failed_step==names(masks)[i])==sum(masks[[i-1]] & !masks[[i]]),'exclusion partition mismatch')

  groups <- c('Total','A0','A1','A_unknown')
  group_mask <- function(g) if(g=='Total') rep(TRUE,n) else !is.na(A_status) & A_status==g
  pct <- function(num,den) if(den>0) 100*num/den else NA_real_
  stage_counts <- list(); stage_exclusions <- list(); exclusion_details <- list()
  for(i in seq_along(masks)) {
    gs <- if(i==1) 'Total' else groups
    for(g in gs) stage_counts[[length(stage_counts)+1L]] <- data.frame(
      stage=names(masks)[i],stage_order=i,A_status=g,n=sum(masks[[i]] & group_mask(g)))
    if(i==1) next
    gs <- if(i==2) 'Total' else groups # Age exclusion cannot be assigned retrospective A.
    for(g in gs) {
      previous <- masks[[i-1]] & group_mask(g); retained <- masks[[i]] & group_mask(g)
      failed <- previous & !masks[[i]]
      stage_exclusions[[length(stage_exclusions)+1L]] <- data.frame(
        branch='main_flow',previous_stage=names(masks)[i-1],stage=names(masks)[i],A_status=g,
        previous_n=sum(previous),excluded_n=sum(failed),retained_n=sum(retained),
        excluded_pct=pct(sum(failed),sum(previous)))
      ph_assert(sum(previous)==sum(failed)+sum(retained),'flow arithmetic failure')
      for(reason in unique(first_failed_detail[failed])) exclusion_details[[length(exclusion_details)+1L]] <- data.frame(
        stage=names(masks)[i],A_status=g,reason=reason,n=sum(failed & first_failed_detail==reason))
    }
  }
  D_side <- do.call(rbind,lapply(groups,function(g){
    z <- masks$covariate_complete & group_mask(g)
    data.frame(branch='D_known_side',previous_stage='covariate_complete',stage='D_known',A_status=g,
      previous_n=sum(z),excluded_n=sum(z & is.na(d$D)),retained_n=sum(z & !is.na(d$D)),
      excluded_pct=pct(sum(z & is.na(d$D)),sum(z)))
  }))
  stage_counts <- do.call(rbind,stage_counts)
  stage_exclusions <- do.call(rbind,stage_exclusions)
  exclusion_details <- if(length(exclusion_details)) do.call(rbind,exclusion_details) else
    data.frame(stage=character(),A_status=character(),reason=character(),n=integer())
  for(s in names(masks)[-1]) {
    x <- stage_counts[stage_counts$stage==s,]
    ph_assert(x$n[x$A_status=='Total']==sum(x$n[x$A_status!='Total']),'A-group totals mismatch')
  }

  domain_keys <- c('positive_MEC','candidate_S3_S0','Y_known_core','covariate_complete')
  variables <- c(A='A',Y='Y',age='age10',sex='sex',race='race',education='education',PIR='PIR',D='D')
  missingness <- list(); missing_patterns <- list(); covariate_overlap <- list()
  for(key in domain_keys) for(g in groups) {
    z <- masks[[key]] & group_mask(g); den <- sum(z); wden <- sum(d$WTMEC2YR[z])
    ph_assert(all(is.finite(d$WTMEC2YR[z]) & d$WTMEC2YR[z]>0),'invalid weight in missingness domain')
    for(v in names(variables)) {
      miss <- z & is.na(d[[variables[[v]]]])
      nmiss <- sum(miss); wmiss <- sum(d$WTMEC2YR[miss])
      missingness[[length(missingness)+1L]] <- data.frame(domain=key,A_status=g,variable=v,
        source_column=variables[[v]],domain_n=den,missing_n=nmiss,missing_pct=pct(nmiss,den),
        domain_weight=wden,missing_weight=wmiss,missing_weighted_pct=pct(wmiss,wden))
    }
    if(den>0) {
      patterns <- apply(is.na(d[z,unname(variables),drop=FALSE]),1,function(x)
        if(any(x)) paste(names(variables)[x],collapse='+') else 'none')
      for(p in unique(patterns)) missing_patterns[[length(missing_patterns)+1L]] <- data.frame(
        domain=key,A_status=g,pattern=p,n=sum(patterns==p),weight=sum(d$WTMEC2YR[z][patterns==p]))
    }
    covariate_overlap[[length(covariate_overlap)+1L]] <- data.frame(domain=key,A_status=g,domain_n=den,
      any_primary_covariate_missing=sum(z & !d$cov_complete),education_missing=sum(z & is.na(d$education)),
      PIR_missing=sum(z & is.na(d$PIR)),education_and_PIR_missing=sum(z & is.na(d$education) & is.na(d$PIR)))
  }
  missingness <- do.call(rbind,missingness)
  for(key in domain_keys) for(v in names(variables)) {
    x <- missingness[missingness$domain==key & missingness$variable==v,]
    ph_assert(x$domain_n[x$A_status=='Total']==sum(x$domain_n[x$A_status!='Total']) &&
                x$missing_n[x$A_status=='Total']==sum(x$missing_n[x$A_status!='Total']),
              'missingness group arithmetic mismatch')
    ph_assert(isTRUE(all.equal(x$domain_weight[x$A_status=='Total'],sum(x$domain_weight[x$A_status!='Total']),tolerance=1e-12)), 'weight denominator group mismatch')
  }

  phenotype_category <- rep('outside_age',n)
  phenotype_category[age & d$in_ARQ_F & d$state %in% states[1]] <- 'S0'
  phenotype_category[age & d$in_ARQ_F & d$state %in% states[4]] <- 'S3'
  phenotype_category[age & d$in_ARQ_F & d$state %in% states[c(2,3)]] <- 'known_nonstudy_phenotype'
  phenotype_category[age & d$in_ARQ_F & d$state %in% states[c(5,6)]] <- 'insufficient_information'
  phenotype_category[age & d$in_ARQ_F & d$state %in% states[7]] <- 'detected_conflict'
  phenotype_category[age & !d$in_ARQ_F] <- 'ARQ_module_absent'
  cats <- c('S0','S3','known_nonstudy_phenotype','insufficient_information','detected_conflict','ARQ_module_absent')
  phenotype_categories <- list(); phenotype_states <- list()
  state_report <- as.character(d$state);state_report[age & !d$in_ARQ_F] <- 'ARQ_module_absent'
  for(key in c('age20_69',domain_keys)) for(g in groups) {
    z <- masks[[key]] & group_mask(g)
    ph_assert(sum(z)==sum(z & phenotype_category %in% cats),'phenotype category partition failure')
    for(category in cats) phenotype_categories[[length(phenotype_categories)+1L]] <- data.frame(
      domain=key,A_status=g,category=category,n=sum(z & phenotype_category==category))
    for(state in c(states,'ARQ_module_absent')) phenotype_states[[length(phenotype_states)+1L]] <- data.frame(
      domain=key,A_status=g,state=state,n=sum(z & state_report==state))
  }
  final_cells <- do.call(rbind,lapply(0:1,function(g)do.call(rbind,lapply(0:1,function(a){
    z <- masks$covariate_complete & d$G %in% g & d$A %in% a
    data.frame(G=g,A=a,n=sum(z),S0a_n=sum(z & d$S0_source %in% 'S0a'),S0b_n=sum(z & d$S0_source %in% 'S0b'))
  }))))
  people <- data.frame(SEQN=d$SEQN,A_status=A_status,A_unknown_reason=A_unknown_reason,
    first_failed_step=first_failed_step,first_failed_detail=first_failed_detail,
    missing_module_combination=missing_module_combination,cov_missing_combination=cov_missing_combination,
    phenotype_category=phenotype_category,state=as.character(d$state),D_known_side=D_known)
  for(k in names(masks)) people[[paste0('mask_',k)]] <- masks[[k]]
  list(execution_label=execution_label,sorted_SEQN=d$SEQN,stage_counts=stage_counts,stage_exclusions=stage_exclusions,
    exclusion_details=exclusion_details,D_side_branch=D_side,missingness=missingness,
    missing_patterns=if(length(missing_patterns))do.call(rbind,missing_patterns)else
      data.frame(domain=character(),A_status=character(),pattern=character(),n=integer(),weight=numeric()),
    covariate_overlap=do.call(rbind,covariate_overlap),
    phenotype_categories=do.call(rbind,phenotype_categories),phenotype_states=do.call(rbind,phenotype_states),
    final_cells=final_cells,person_audit=people,masks=masks,D_known_mask=D_known,
    notes=c('A_status is a retrospective linked-file reporting grouping, assigned only at ages 20–69.',
      'Unknown A is partitioned by module absence and observed DPQ010 missing/refusal/unknown codes.',
      'No individual reason for original-survey nonparticipation is inferred from public-file blanks.',
      'Missingness denominators include missing observations; empty-group percentages are NA.',
      'A missingness within A_unknown and covariate completeness within MAIN follow the group/domain definitions.',
      'D-known is a side branch; D missingness never removes a MAIN participant.'))
}
