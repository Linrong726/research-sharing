# UNADJ_MAIN pure functions. Probability order: A first, G second.
u_names <- c('U00','U10','U01','U11','U_RD0','U_RD1','U_Delta')
u_L <- rbind(diag(4),c(-1,1,0,0),c(0,0,-1,1),c(1,-1,-1,1))
dimnames(u_L)<-list(u_names,u_names[1:4])
u_cells <- function(w,d) {
 if(length(w)!=nrow(d)||any(!is.finite(w))||any(w<0)) stop('INVALID_WEIGHT')
 if(anyNA(d[c('A','G','Y')])||any(!d$A%in%0:1)||any(!d$G%in%0:1)||any(!d$Y%in%0:1)) stop('INVALID_MAIN_VALUE')
 z<-do.call(rbind,lapply(0:3,function(k) {
  take<-d$A==(k%%2)&d$G==(k%/%2)
  den<-sum(w[take]); num<-sum(w[take]*d$Y[take])
  c(n=sum(take),events=sum(d$Y[take]==1),positive_weight_n=sum(w[take]>0),positive_weight_events=sum(w[take]>0 & d$Y[take]==1),denominator=den,numerator=num,probability=if(den>0)num/den else NA_real_)
 })); rownames(z)<-u_names[1:4]; z
}
u_theta <- function(w,d) {
 cc<-u_cells(w,d); if(any(cc[,'denominator']<=0)||any(!is.finite(cc[,'probability']))) stop('NONPOSITIVE_OR_NONFINITE_CELL')
 setNames(as.vector(u_L%*%cc[,'probability']),u_names)
}
u_cov <- function(reps,point,scale,rscales) {
 if(length(scale)!=1||!is.finite(scale)||scale<0||any(!is.finite(rscales))||any(rscales<0)) stop('INVALID_VARIANCE_SCALING')
 if(ncol(reps)!=length(point)||nrow(reps)!=length(rscales)||any(!is.finite(reps))||any(!is.finite(point))) stop('INVALID_REPLICATE_VECTOR')
 z<-sweep(reps,2,point,'-'); scale*crossprod(z*sqrt(rscales))
}
u_intervals <- function(point,reps,V7,scale,rscales,df) {
 if(!is.finite(df)||df<=0) stop('INVALID_DF')
 if(!identical(dim(V7),c(7L,7L))||any(!is.finite(V7))||max(abs(V7-t(V7)))>1e-12||any(diag(V7)<0)) stop('INVALID_JOINT_COVARIANCE')
 out<-data.frame(branch='UNADJ_MAIN',estimand=u_names,estimate=point,se=sqrt(diag(V7)),df=df,lower=NA_real_,upper=NA_real_,ci_status='ESTIMABLE',ci_method=c(rep('JKn logit t',4),rep('JKn linear contrast t',3)),row.names=NULL)
 good<-vapply(1:4,function(k) all(is.finite(c(point[k],reps[,k])))&&all(c(point[k],reps[,k])>0&c(point[k],reps[,k])<1),logical(1))
 VL<-matrix(NA_real_,4,4,dimnames=list(u_names[1:4],u_names[1:4]))
 if(any(good)) {
  j<-which(good); VL[j,j]<-u_cov(qlogis(reps[,j,drop=FALSE]),qlogis(point[j]),scale,rscales)
  out$lower[j]<-plogis(qlogis(point[j])-qt(.975,df)*sqrt(diag(VL)[j])); out$upper[j]<-plogis(qlogis(point[j])+qt(.975,df)*sqrt(diag(VL)[j]))
 }
 out$ci_status[which(!good)]<-'NOT_ESTIMABLE_LOGIT_BOUNDARY'
 for(k in 5:7) {out$lower[k]<-point[k]-qt(.975,df)*out$se[k];out$upper[k]<-point[k]+qt(.975,df)*out$se[k]}
 out$estimate_display<-out$estimate*100;out$se_display<-out$se*100;out$lower_display<-out$lower*100;out$upper_display<-out$upper*100
 out$unit<-c(rep('percent',4),rep('percentage points',3))
 list(ci=out,V_logit=VL)
}
