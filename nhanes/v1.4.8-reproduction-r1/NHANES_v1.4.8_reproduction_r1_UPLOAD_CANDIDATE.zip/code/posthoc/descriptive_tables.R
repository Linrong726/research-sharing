# Recalculate sources for manuscript Table 1 and supplementary S1-S6/S10.
# Statistics and factor order follow phase1b/code/02_candidate_audit.R,
# phase1b/code/03_support_audit.R, phase2a/code/01_prepare_inputs.R.
# Presentation metadata are retained solely to locate historical table rows.
reproduce_descriptive_tables <- function(d, full_rep, W) {
  cc<-d[d$domain,]; lab<-function(x)ifelse(is.na(x),'Unknown',as.character(x))
  source_prefix<-'sources/phase2a/outputs/inherited_phase1b/'
  transition<-do.call(rbind,lapply(state_levels,function(s) {
    z<-d[d$eligible_age&d$state==s,]
    data.frame(source_file=paste0(source_prefix,'02_original_state_to_candidate.csv'),original_state=s,
      n_age=nrow(z),n_MEC=sum(z$valid_design),n_new_candidate=sum(z$candidate&z$valid_design),
      n_core=sum(z$domain_core),n_CC=sum(z$domain))
  }))
  masks<-list(DEMO_all=rep(TRUE,nrow(d)),age20_69=d$eligible_age,
    four_modules=d$eligible_age&d$in_ARQ_F&d$in_DPQ_F&d$in_PAQ_F)
  masks$positive_MEC<-masks$four_modules&d$valid_design
  masks$candidate_S3_S0<-masks$positive_MEC&d$candidate
  masks$A_known<-masks$candidate_S3_S0&!is.na(d$A)
  masks$Y_known_core<-masks$A_known&!is.na(d$Y)
  masks$covariate_complete<-masks$Y_known_core&d$cov_complete
  masks$D_known<-masks$covariate_complete&!is.na(d$D)
  flow<-data.frame(stage=names(masks),n=vapply(masks,sum,numeric(1)))
  flow$removed_previous<-c(NA,-diff(flow$n))
  missing<-do.call(rbind,lapply(c('age_MEC','candidate_MEC','core','CC'),function(nm) {
    take<-switch(nm,age_MEC=d$eligible_age&d$valid_design,candidate_MEC=d$candidate&d$valid_design,core=d$domain_core,CC=d$domain)
    z<-d[take,]
    do.call(rbind,lapply(c('A','Y','age10','sex','race','education','PIR','D'),function(v) {
      m<-is.na(z[[v]]);data.frame(domain=nm,variable=v,n=nrow(z),missing_n=sum(m),
        missing_pct=100*mean(m),weighted_missing_pct=100*sum(z$WTMEC2YR[m])/sum(z$WTMEC2YR))
    }))
  }))
  sel<-do.call(rbind,lapply(c('candidate_A_answered','core_covariates_complete'),function(step) {
    z<-if(step=='candidate_A_answered')d[d$candidate&d$valid_design,]else d[d$domain_core,]
    kept<-if(step=='candidate_A_answered')!is.na(z$A)&!is.na(z$Y)else z$cov_complete
    do.call(rbind,lapply(c(FALSE,TRUE),function(k) {
      q<-z[kept==k,];w<-q$WTMEC2YR
      data.frame(stage=step,kept=k,n=nrow(q),weight_sum=sum(w),mean_age_weighted=weighted.mean(q$RIDAGEYR,w),
        female_weight_pct=100*weighted.mean(q$RIAGENDR==2,w),G1_weight_pct=100*weighted.mean(q$G,w),
        S0b_weight_pct=100*weighted.mean(q$S0_source%in%'S0b',w),PIR_missing_pct=100*mean(is.na(q$PIR)))
    }))
  }))
  s0<-do.call(rbind,lapply(c('S0a','S0b'),function(s) {
    z<-d[d$S0_source%in%s,]
    data.frame(source=s,n_age=nrow(z),n_MEC=sum(z$valid_design),n_core=sum(z$domain_core),n_CC=sum(z$domain),
      CC_weight_sum=sum(z$WTMEC2YR[z$domain]),CC_A0=sum(z$domain&z$A%in%0),CC_A1=sum(z$domain&z$A%in%1))
  }))
  cats<-do.call(rbind,lapply(0:1,function(g)do.call(rbind,lapply(0:1,function(a)do.call(rbind,
    lapply(c('sex','race','education','DPQ020_clean','D'),function(v) {
      z<-cc[cc$G==g&cc$A==a,]
      lv<-if(v=='DPQ020_clean')as.character(0:3)else if(v=='D')as.character(0:1)else levels(z[[v]])
      do.call(rbind,lapply(c(lv,'Unknown'),function(l) {
        take<-lab(z[[v]])==l
        data.frame(G=g,A=a,variable=v,level=l,n=sum(take),weight_pct=100*sum(z$WTMEC2YR[take])/sum(z$WTMEC2YR),
          PSU=nrow(unique(z[take,c('SDMVSTRA','SDMVPSU')])),strata=length(unique(z$SDMVSTRA[take])))
      }))
    }))))))
  cont<-do.call(rbind,lapply(0:1,function(g)do.call(rbind,lapply(0:1,function(a)do.call(rbind,
    lapply(c('RIDAGEYR','PIR'),function(v) {
      z<-cc[cc$G==g&cc$A==a,];q<-quantile(z[[v]],c(0,.1,.25,.5,.75,.9,1))
      data.frame(G=g,A=a,variable=v,n=nrow(z),weighted_mean=weighted.mean(z[[v]],z$WTMEC2YR),
        min=q[1],p10=q[2],p25=q[3],median=q[4],p75=q[5],p90=q[6],max=q[7])
    }))))))
  long<-list()
  for(kind in c('cats','cont')) {
    z<-if(kind=='cats')cats else cont
    src<-paste0(source_prefix,if(kind=='cats')'11_four_cell_covariate_distributions.csv'else'12_four_cell_continuous_distributions.csv')
    for(i in seq_len(nrow(z)))for(k in names(z)) {
      val<-z[[k]][i];val<-if(is.numeric(val))sprintf('%.17g',val)else as.character(val)
      long[[length(long)+1L]]<-data.frame(source_file=src,
        row_key=paste0('G',z$G[i],'A',z$A[i],':',z$variable[i],':',if(kind=='cats')z$level[i]else''),variable=k,raw_value=val)
    }
  }
  inputs<-d[d$valid_design,];support<-list()
  for(id in c('MAIN','A_HIGH')) {
    z<-inputs[inputs$domain,];if(id=='A_HIGH')z$A<-z$A_high
    wr<-cbind(FULL=inputs$WTMEC2YR[inputs$domain],W[inputs$domain,,drop=FALSE])
    colnames(wr)<-c('FULL',sprintf('REP%02d',1:31))
    for(k in seq_len(ncol(wr)))for(g in 0:1)for(a in 0:1) {
      active<-wr[,k]>0;take<-active&z$G==g&z$A==a;zz<-z[take,];ww<-wr[take,k]
      support[[length(support)+1L]]<-data.frame(model_id=id,weight_set=colnames(wr)[k],G=g,exposure=a,n=sum(take),
        n_Y0=sum(z$Y[take]==0),n_Y1=sum(z$Y[take]==1),Kish=sum(ww)^2/sum(ww^2),
        PSU=nrow(unique(zz[c('SDMVSTRA','SDMVPSU')])),strata=length(unique(zz$SDMVSTRA)))
    }
  }
  list(Table1_raw=do.call(rbind,long),TableS1_raw=transition,TableS2_raw=flow,TableS3_raw=missing,
    TableS4_raw=sel,TableS5_raw=s0,TableS6_raw=do.call(rbind,support),TableS10_raw=cont,
    Table1_categorical=cats,Table1_continuous=cont)
}
