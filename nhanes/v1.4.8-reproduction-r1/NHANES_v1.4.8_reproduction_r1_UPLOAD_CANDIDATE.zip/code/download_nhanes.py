"""Download the four official NHANES 2009-2010 files and verify frozen SHA256 identities.
Python 3.9+ standard library only. Refuses HTML errors, changed files and overwrites.
"""
from pathlib import Path
from datetime import datetime,timezone
import argparse, hashlib, json, urllib.request

FILES={
 'DEMO_F':('78c4d4a6e5eafa9da3bbb24a90d140fef5d8c0cda932a7ff8ee609288d4fae07',3631600),
 'ARQ_F':('78596ae95bf2b2c75d1de48f4da98874a6cf717f97c2ebf3b7dc45c7a6a3b7c3',5124240),
 'DPQ_F':('31fcc0a2df520b38e69ff42426201a6bb4755c59446cecc97b444663e62a3974',562000),
 'PAQ_F':('02d25e8312a36103ff6ed416dfd597fb109f5a299cc951477337ff8fe694aa84',1645280)}

def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--output',required=True,type=Path)
    ap.add_argument('--receipt',type=Path,help='New receipt path, separate from input data when verifying existing files.')
    ap.add_argument('--verify-only',action='store_true',help='Read existing XPT only; never download or write into the input directory.')
    args=ap.parse_args();dest=args.output.resolve()
    if args.verify_only and not dest.is_dir():raise ValueError('Verification input directory does not exist')
    if not args.verify_only:dest.mkdir(parents=True,exist_ok=True)
    receipt_path=args.receipt.resolve() if args.receipt else dest/'DOWNLOAD_RECEIPT.json'
    if receipt_path.exists():raise ValueError('Receipt already exists; supply a new --receipt path to preserve prior evidence')
    records=[]
    for name,(expected,size) in FILES.items():
        url=f'https://wwwn.cdc.gov/Nchs/Data/Nhanes/Public/2009/DataFiles/{name}.xpt'
        p=dest/(name+'.xpt');started=datetime.now(timezone.utc).isoformat()
        if p.exists():
            payload=p.read_bytes();mode='existing_verified';final_url=None;content_type=None
        else:
            if args.verify_only:raise FileNotFoundError(str(p))
            req=urllib.request.Request(url,headers={'User-Agent':'NHANES-reproducibility-check/1.0'})
            with urllib.request.urlopen(req,timeout=45) as response:
                payload=response.read(12000000);final_url=response.url;content_type=response.headers.get('Content-Type')
            mode='downloaded'
        digest=hashlib.sha256(payload).hexdigest()
        if not expected or digest!=expected or len(payload)!=int(size):
            raise ValueError(f'{name}: source identity mismatch; did not save: bytes={len(payload)}, sha256={digest}')
        if not payload.startswith(b'HEADER RECORD'):raise ValueError(name+': not SAS XPORT header')
        if mode=='downloaded':p.write_bytes(payload)
        records.append({'component':name,'official_url':url,'resolved_url':final_url,'bytes':len(payload),
                        'sha256':digest,'expected_sha256':expected,'matches_frozen_source':True,
                        'mode':mode,'content_type':content_type,'started_utc':started,
                        'completed_utc':datetime.now(timezone.utc).isoformat()})
        print(name,mode,len(payload),digest,flush=True)
    receipt={'status':'PASS','verify_only':args.verify_only,'files':records,'note':'Receipt distinguishes fresh downloads from validation of existing files; existing XPT inputs are unchanged.'}
    receipt_path.parent.mkdir(parents=True,exist_ok=True)
    receipt_path.write_text(json.dumps(receipt,indent=2),encoding='utf-8')

if __name__=='__main__':main()
