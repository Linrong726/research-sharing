"""Compare new aggregate CSVs with the delivered reference, after all calculations.
Checks schema, row order, text and numeric cells; never feeds numbers to an estimator.
Tolerance: abs(error) <= 1e-10 + 1e-12 * abs(expected). Count fields must be exact.
"""
from pathlib import Path
import argparse,csv,hashlib,json,math

def table(p):
    with p.open(encoding='utf-8-sig',newline='') as f:return list(csv.reader(f))

def numeric(x):
    try:
        if x.lower().startswith(('0x','-0x')):return float.fromhex(x)
        return float(x)
    except ValueError:return None

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--run',required=True,type=Path);p.add_argument('--expected',required=True,type=Path)
    p.add_argument('--out',required=True,type=Path);a=p.parse_args()
    if a.out.exists():p.error('Comparison output must not exist.')
    a.out.mkdir(parents=True)
    manifest=json.loads((a.expected/'EXPECTED_MANIFEST.json').read_text(encoding='utf-8'))
    summary=[];differences=[]
    for spec in manifest['files']:
        rel=spec['path'];ref=a.expected/rel;new=a.run/rel
        if hashlib.sha256(ref.read_bytes()).hexdigest()!=spec['sha256']:raise ValueError('Reference changed: '+rel)
        expected=table(ref);observed=table(new)
        if len(expected)!=len(observed) or expected[0]!=observed[0]:raise ValueError('Schema/row mismatch: '+rel)
        n=0;bad=0;maxabs=0.;exact=0
        for i,(row1,row2) in enumerate(zip(expected[1:],observed[1:]),1):
            if len(row1)!=len(row2):raise ValueError('Column mismatch: '+rel)
            for header,x,y in zip(expected[0],row1,row2):
                n+=1
                if x==y:exact+=1;continue
                v,w=numeric(x),numeric(y)
                if v is None or w is None or not math.isfinite(v) or not math.isfinite(w):
                    ok=False;err=None
                else:
                    err=abs(v-w);maxabs=max(maxabs,err)
                    count=header.lower() in {'n','unweighted_n','count','rank','ci_df','design_df','psus','strata','replicates'}
                    ok=(err==0) if count else err<=1e-10+1e-12*abs(v)
                if not ok:
                    bad+=1;differences.append(dict(file=rel,row=i,field=header,expected=x,observed=y,absolute_difference=err))
        summary.append(dict(file=rel,cells=n,exact_text=exact,mismatches=bad,maximum_numeric_absolute_difference=maxabs))
    with (a.out/'file_comparison.csv').open('w',encoding='utf-8',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(summary[0]));w.writeheader();w.writerows(summary)
    (a.out/'differences.json').write_text(json.dumps(differences,indent=2),encoding='utf-8')
    report={'status':'FAIL' if differences else 'PASS','files':len(summary),'cells':sum(x['cells'] for x in summary),
            'exact_text_cells':sum(x['exact_text'] for x in summary),'mismatches':len(differences),
            'comparison_after_computation':True,'scope':'Numerical aggregate reproducibility, not independent evidence of statistical validity.'}
    (a.out/'COMPARISON_RECEIPT.json').write_text(json.dumps(report,indent=2),encoding='utf-8');print(json.dumps(report))
    if differences:raise SystemExit(1)

if __name__=='__main__':main()
