args <- commandArgs(trailingOnly=TRUE)
if(length(args) && nzchar(args[1])) .libPaths(c(normalizePath(args[1],mustWork=TRUE),.libPaths()))
expected <- c(foreign='0.8.91',survey='4.5',Matrix='1.7.5',survival='3.8.6',
              DBI='1.3.0',mitools='2.7',Rcpp='1.1.2',minqa='1.2.8',
              numDeriv='2016.8.1.1',RcppArmadillo='15.6.0.1')
stopifnot(as.character(getRversion())=='4.6.1')
for(p in names(expected)) {
  if(!requireNamespace(p,quietly=TRUE)) stop('Missing required package: ',p)
  actual <- as.character(packageVersion(p))
  if(actual!=expected[[p]]) stop('Version mismatch: ',p,' expected ',expected[[p]],' actual ',actual)
  cat(p,actual,'\n')
}
cat('PINNED_ENVIRONMENT_PASS\n')
