# Independent read-only arithmetic audit of newly saved reconstruction artifacts.
# No original RDS read; no regression is fitted. Output goes to the supplied audit directory.
args<-commandArgs(trailingOnly=TRUE);stopifnot(length(args)==3L)
run<-normalizePath(args[1],winslash='/',mustWork=TRUE)
out<-args[2];dir.create(out,recursive=TRUE,showWarnings=FALSE)
if(nzchar(args[3])) .libPaths(c(args[3],.libPaths()))
suppressPackageStartupMessages(library(survey))
script_arg<-grep('^--file=',commandArgs(),value=TRUE)
code<-dirname(normalizePath(sub('^--file=','',script_arg[1]),winslash='/',mustWork=TRUE))
source(file.path(code,'vendor/02_estimator_core.R'))
inputs<-readRDS(file.path(run,'data/design_inputs.rds'))
outcome<-readRDS(file.path(run,'data/research_outcome.rds'))
checks<-list()
add<-function(mid,item,n,maxdiff,pass)checks[[length(checks)+1L]]<<-data.frame(model_id=mid,item=item,n=n,max_abs_difference=maxdiff,pass=pass)
for(mid in p2_model_ids){
 folder<-file.path(run,'models',mid)
 result<-readRDS(file.path(folder,'complete_result.rds'))
 designs<-readRDS(file.path(folder,'survey_designs.rds'))
 weights<-readRDS(file.path(folder,'analysis_weights.rds'))
 domain<-if(mid%in%c('D_BASE','D_PLUS'))inputs$domain_D else inputs$domain
 d<-inputs[domain,];if(mid=='A_HIGH')d$A<-d$A_high
 form<-if(mid=='D_PLUS')~A*G+age10+sex+race+education+PIR+D else ~A*G+age10+sex+race+education+PIR
 cols<-p2_expected_columns(mid=='D_PLUS')
 X<-p2_matrix(form,d,cols)
 scenarios<-lapply(list(c(0,0),c(1,0),c(0,1),c(1,1)),function(ag){z<-d;z$A<-ag[1];z$G<-ag[2];p2_matrix(form,z,cols)})
 ids_ok<-identical(d$SEQN,designs$domain_Taylor$variables$SEQN)&&identical(d$SEQN,designs$domain_replicate$variables$SEQN)&&identical(inputs$SEQN,weights$full$SEQN)
 add(mid,'saved_design_ID_alignment',length(d$SEQN),0,ids_ok)
 tw<-as.numeric(weights(designs$full_Taylor));rw<-as.matrix(weights(designs$full_replicate,type='analysis'))
 err<-max(abs(tw-weights$full$FULL),abs(rw-as.matrix(weights$full[,-c(1,2,3)])))
 add(mid,'saved_design_weights',length(tw)+length(rw),err,err==0)
 reconstructed<-matrix(NA_real_,32,7)
 for(k in seq_len(32L)){
  label<-if(k==1L)'full' else paste0('JKn_',k-1L)
  z<-readRDS(file.path(folder,'fits',paste0(label,'.rds')))
  saved_w<-if(k==1L)weights$domain$FULL else weights$domain[[3+k-1L]]
  add(mid,paste(label,'SEQNs_weights_response'),nrow(d),max(abs(z$weights-saved_w)),identical(z$SEQN,d$SEQN)&&identical(z$response,outcome$response[domain])&&identical(z$active,z$weights>0)&&max(abs(z$weights-saved_w))==0)
  fresh_pred<-vapply(scenarios,function(m)plogis(as.vector(m%*%z$fit$coefficients)),numeric(nrow(d)))
  err<-max(abs(fresh_pred-z$scenario_predictions))
  add(mid,paste(label,'individual_scenario_predictions'),length(fresh_pred),err,err==0&&isTRUE(z$fit$converged)&&length(z$warnings)==0)
  reconstructed[k,]<-p2_contrasts(colSums(z$scenario_predictions*z$weights)/sum(z$weights))
  orig<-if(k==1)result$estimate else result$replicates[k-1,]
  err<-max(abs(reconstructed[k,]-orig))
  add(mid,paste(label,'seven_estimates_from_saved_predictions'),length(orig),err,err==0)
 }
 V<-weights$scale*crossprod(sweep(reconstructed[-1,,drop=FALSE],2,reconstructed[1,],'-')*sqrt(weights$rscales))
 err<-max(abs(V-result$covariance))
 add(mid,'covariance_from_all_saved_replicates',length(V),err,err==0)
 # New reusable matrix artifact derived entirely from saved run inputs. All rows map to SEQN.
 saveRDS(list(artifact_status='REPRODUCTION_NEW',SEQN=d$SEQN,model_matrix=X,
              scenario_matrices=setNames(scenarios,c('P00','P10','P01','P11'))),
         file.path(out,paste0(mid,'_model_and_scenario_matrices.rds')))
}
checks<-do.call(rbind,checks)
write.csv(checks,file.path(out,'saved_object_independent_checks.csv'),row.names=FALSE)
writeLines(capture.output(sessionInfo()),file.path(out,'sessionInfo.txt'))
stopifnot(all(checks$pass))
cat(nrow(checks),'saved-object checks passed; every prediction and aggregate reconstructed exactly.\n')
