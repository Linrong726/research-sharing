# No estimator source, no original analysis object, and no fitting.
# Read newly reconstructed inputs and saved fits; check independently written arithmetic.
args<-commandArgs(trailingOnly=TRUE);stopifnot(length(args)==2L)
run<-args[1];out<-args[2];dir.create(out,recursive=TRUE,showWarnings=FALSE)
inputs<-readRDS(file.path(run,'data/design_inputs.rds'))
y_all<-readRDS(file.path(run,'data/research_outcome.rds'))$response
checks<-list();rounding<-list()
check<-function(mid,what,value,tol,ok=NULL){
 if(is.null(ok))ok<-is.finite(value)&&value<=tol
 checks[[length(checks)+1L]]<<-data.frame(model_id=mid,check=what,value=value,tolerance=tol,pass=ok)
}
for(mid in c('MAIN','D_BASE','D_PLUS','A_HIGH')){
 folder<-file.path(run,'models',mid)
 r<-readRDS(file.path(folder,'complete_result.rds'))
 wa<-readRDS(file.path(folder,'analysis_weights.rds'))
 dom<-if(mid%in%c('D_BASE','D_PLUS'))inputs$domain_D else inputs$domain
 d<-inputs[dom,];y<-y_all[dom]
 if(mid=='A_HIGH')d$A<-d$A_high
 fo<-if(mid=='D_PLUS')~A*G+age10+sex+race+education+PIR+D else ~A*G+age10+sex+race+education+PIR
 cm<-list(sex=contr.treatment(c('1','2')),race=contr.treatment(as.character(1:5)),education=contr.treatment(c('less_HS','HS_GED','above_HS')))
 X<-model.matrix(fo,d,contrasts.arg=cm)
 check(mid,'model_rank',abs(qr(X)$rank-if(mid=='D_PLUS')14 else 13),0)
 sf<-unique(inputs[c('SDMVSTRA','SDMVPSU')]);nf<-nrow(sf)-length(unique(sf$SDMVSTRA))
 sd<-unique(d[c('SDMVSTRA','SDMVPSU')]);nd<-nrow(sd)-length(unique(sd$SDMVSTRA))
 check(mid,'full_and_domain_design_df_16',max(abs(c(nf,nd)-16)),0)
 check(mid,'CI_df_exact_original_rule',abs(r$metadata$ci_df-min(nd,nd-qr(X)$rank+1)),0)
 check(mid,'JKn_mse_scale',max(abs(c(as.integer(wa$mse)-1,wa$scale-1))),0)
 fw<-wa$full$FULL;rw<-as.matrix(wa$full[,-(1:3)])
 rr<-data.frame(model_id=mid,SEQN=inputs$SEQN,raw_WTMEC2YR=inputs$WTMEC2YR,actual_sampling_weight=fw,
 difference=fw-inputs$WTMEC2YR,raw_hex=sprintf('%a',inputs$WTMEC2YR),actual_hex=sprintf('%a',fw))
 rounding[[mid]]<-rr[rr$difference!=0,]
 for(j in seq_len(31)){
  deleted<-unique(inputs[rw[,j]==0,c('SDMVSTRA','SDMVPSU')])
  stopifnot(nrow(deleted)==1)
  k<-sum(sf$SDMVSTRA==deleted$SDMVSTRA)
  expected_ratio<-ifelse(inputs$SDMVSTRA!=deleted$SDMVSTRA,1,ifelse(inputs$SDMVPSU==deleted$SDMVPSU,0,k/(k-1)))
  check(mid,paste0('JKn_',j,'_PSU_delete_and_inflate'),max(abs(rw[,j]/fw-expected_ratio)),1e-12)
  check(mid,paste0('JKn_',j,'_rscale'),abs(wa$rscales[j]-(k-1)/k),0)
 }
 all_est<-matrix(NA_real_,32,7)
 for(i in seq_len(32)){
  label<-if(i==1)'full'else paste0('JKn_',i-1)
  f<-readRDS(file.path(folder,'fits',paste0(label,'.rds')))
  b<-f$fit$coefficients;w<-f$weights
  pred<-matrix(NA_real_,nrow(d),4)
  conditions<-list(c(0,0),c(1,0),c(0,1),c(1,1))
  for(k in 1:4){
   z<-d;z$A<-conditions[[k]][1];z$G<-conditions[[k]][2]
   M<-model.matrix(fo,z,contrasts.arg=cm)
   pred[,k]<-plogis(drop(M%*%b))
  }
  check(mid,paste(label,'independent_model_matrix_and_predictions'),max(abs(pred-f$scenario_predictions)),0)
  prob<-colSums(pred*w)/sum(w)
  independent<-c(prob,prob[2]-prob[1],prob[4]-prob[3],(prob[4]-prob[3])-(prob[2]-prob[1]))
  all_est[i,]<-independent
  target<-if(i==1)r$estimate else r$replicates[i-1,]
  check(mid,paste(label,'independent_standardization_contrasts'),max(abs(independent-target)),1e-15)
  # First-order estimating equation; normalized score avoids arbitrary weight scale.
  score<-crossprod(X,w*(y-plogis(drop(X%*%b))))/sum(w)
  check(mid,paste(label,'weighted_logistic_score'),max(abs(score)),1e-8)
  active<-w>0
  check(mid,paste(label,'prior_weights_mean_normalization'),max(abs(f$fit$prior.weights-w[active]/mean(w[active]))),0)
 }
 # Independently sum every outer product; do not call the original covariance function.
 V<-matrix(0,7,7);LV<-matrix(0,4,4)
 for(j in 1:31){
  dev<-all_est[j+1,]-all_est[1,]
  V<-V+wa$scale*wa$rscales[j]*outer(dev,dev)
  ldev<-qlogis(all_est[j+1,1:4])-qlogis(all_est[1,1:4])
  LV<-LV+wa$scale*wa$rscales[j]*outer(ldev,ldev)
 }
 check(mid,'independent_outer_product_covariance',max(abs(V-r$covariance)),1e-15)
 check(mid,'independent_logit_covariance',max(abs(LV-r$probability_logit_covariance)),1e-14)
 crit<-qt(.975,r$metadata$ci_df)
 low<-all_est[1,]-crit*sqrt(diag(V));high<-all_est[1,]+crit*sqrt(diag(V))
 low[1:4]<-plogis(qlogis(all_est[1,1:4])-crit*sqrt(diag(LV)))
 high[1:4]<-plogis(qlogis(all_est[1,1:4])+crit*sqrt(diag(LV)))
 check(mid,'independent_CI_arithmetic',max(abs(low-r$ci$lower),abs(high-r$ci$upper)),1e-12)
}
tab<-do.call(rbind,checks);rwtab<-do.call(rbind,rounding)
write.csv(tab,file.path(out,'review_independent_arithmetic_checks.csv'),row.names=FALSE)
write.csv(rwtab,file.path(out,'raw_to_actual_sampling_weight_roundoff.csv'),row.names=FALSE)
stopifnot(all(tab$pass))
cat(nrow(tab),'independent checks passed; no fitting was performed.\n')
print(aggregate(abs(difference)~model_id,rwtab,max))
