# Separate comparison process: no fitting, no data derivation, historical RDS read only here.
args<-commandArgs(trailingOnly=TRUE);stopifnot(length(args)==2L)
out<-normalizePath(args[1],winslash='/',mustWork=TRUE)
baseline<-normalizePath(args[2],winslash='/',mustWork=TRUE)
stopifnot(file.exists(file.path(out,'FIT_SUCCESS.txt')))
rows<-list();ci_rows<-list();hex_rows<-list()
for(mid in c('MAIN','D_BASE','D_PLUS','A_HIGH')){
 new<-readRDS(file.path(out,'models',mid,'complete_result.rds'))
 old<-readRDS(file.path(baseline,mid,'complete_result.rds'))
 fields<-c('estimate','replicates','covariance','probability_logit_covariance')
 for(field in fields){
  x<-new[[field]];y<-old[[field]];tol<-if(grepl('covariance',field))1e-12 else 1e-10
  delta<-max(abs(x-y));same_shape<-identical(dim(x),dim(y))&&identical(names(x),names(y))&&identical(dimnames(x),dimnames(y))
  rows[[length(rows)+1L]]<-data.frame(model_id=mid,field=field,numeric_values=length(x),max_abs_difference=delta,tolerance=tol,shape_names_identical=same_shape,bitwise_identical=identical(x,y),pass=same_shape&&is.finite(delta)&&delta<=tol)
  hex_rows[[length(hex_rows)+1L]]<-data.frame(model_id=mid,field=field,index=seq_along(x),new_hex=sprintf('%a',as.vector(x)),historical_hex=sprintf('%a',as.vector(y)))
 }
 for(field in c('estimate','se','lower','upper')){
  x<-new$ci[[field]];y<-old$ci[[field]];delta<-max(abs(x-y))
  rows[[length(rows)+1L]]<-data.frame(model_id=mid,field=paste0('ci_',field),numeric_values=length(x),max_abs_difference=delta,tolerance=1e-10,shape_names_identical=identical(new$ci$estimand,old$ci$estimand),bitwise_identical=identical(x,y),pass=is.finite(delta)&&delta<=1e-10&&identical(new$ci$estimand,old$ci$estimand))
 }
 for(j in seq_len(nrow(new$ci)))ci_rows[[length(ci_rows)+1L]]<-data.frame(model_id=mid,estimand=new$ci$estimand[j],historical_estimate=old$ci$estimate[j],reproduced_estimate=new$ci$estimate[j],estimate_difference=new$ci$estimate[j]-old$ci$estimate[j],lower_difference=new$ci$lower[j]-old$ci$lower[j],upper_difference=new$ci$upper[j]-old$ci$upper[j],historical_hex=sprintf('%a',old$ci$estimate[j]),reproduced_hex=sprintf('%a',new$ci$estimate[j]))
 rows[[length(rows)+1L]]<-data.frame(model_id=mid,field='reference_SEQN_weights_exact',numeric_values=nrow(new$reference)*2,max_abs_difference=max(abs(as.matrix(new$reference)-as.matrix(old$reference))),tolerance=0,shape_names_identical=identical(names(new$reference),names(old$reference)),bitwise_identical=identical(new$reference,old$reference),pass=identical(new$reference,old$reference))
}
checks<-do.call(rbind,rows)
write.csv(checks,file.path(out,'audit/historical_comparison_checks.csv'),row.names=FALSE)
write.csv(do.call(rbind,ci_rows),file.path(out,'audit/historical_28_estimate_CI_comparison.csv'),row.names=FALSE)
write.csv(do.call(rbind,hex_rows),file.path(out,'audit/historical_numeric_hex_comparison.csv'),row.names=FALSE)
print(checks)
stopifnot(all(checks$pass))
writeLines('PASS: all four adjusted branches matched retained historical estimates, CIs, replicate estimates and covariance matrices within predeclared tolerances.',file.path(out,'COMPARISON_SUCCESS.txt'))
