"""Portable, fail-closed launcher: raw XPT -> newly reconstructed adjusted analyses.
Python >=3.9 standard library only. R needs foreign and survey.
Historical results, if supplied, are opened by a separate comparison process only
AFTER fitting has finished. Neither a historical RDS nor an old derived input is
an input to run_adjusted.R.
"""
import argparse
import csv
import hashlib
import json
import os
import platform
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path


def sha(path):
    h = hashlib.sha256()
    with path.open('rb') as f:
        for block in iter(lambda: f.read(1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--raw-dir', type=Path, required=True)
    p.add_argument('--out', type=Path, required=True, help='New, empty run directory')
    p.add_argument('--rscript', default='Rscript')
    p.add_argument('--lib', type=Path, help='Optional preinstalled R package library')
    p.add_argument('--baseline', type=Path, help='Optional historical models directory; comparison ONLY')
    a = p.parse_args()
    code = Path(__file__).resolve().parent
    raw = a.raw_dir.resolve(strict=True)
    out = a.out.resolve()
    if out.exists() and any(out.iterdir()):
        p.error('Output directory must be new or empty; no overwriting of previous runs.')
    source_paths = [raw / (m + '.xpt') for m in ('DEMO_F', 'ARQ_F', 'DPQ_F', 'PAQ_F')]
    for path in source_paths:
        if not path.is_file():
            p.error(f'Missing XPT: {path}')
    out.mkdir(parents=True, exist_ok=True)
    prov = out / 'provenance'
    prov.mkdir()
    # Frozen before fitting and before reading any comparison values.
    rules = {'artifact_status': 'REPRODUCTION_NEW', 'probability_absolute_tolerance': 1e-10,
             'covariance_absolute_tolerance': 1e-12, 'membership_and_counts': 'exact',
             'fields': ['estimate', 'ci:estimate,se,lower,upper', 'replicates:31x7',
                        'covariance:7x7', 'probability_logit_covariance:4x4'],
             'historical_RDS_input_to_model': False,
             'failure_policy': 'Any missing/failed replicate aborts its branch; no discarding, retries, or model changes.'}
    (prov / 'predeclared_comparison_rules.json').write_text(json.dumps(rules, indent=2) + '\n')
    manifest = [{'role': 'raw_scientific_input', 'path': str(x), 'bytes': x.stat().st_size,
                 'sha256': sha(x)} for x in source_paths]
    for x in sorted(code.rglob('*')):
        if x.is_file() and '__pycache__' not in x.parts:
            manifest.append({'role': 'executed_code', 'path': str(x), 'bytes': x.stat().st_size, 'sha256': sha(x)})
    (prov / 'input_code_manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
    cmd = [a.rscript, '--vanilla', str(code / 'run_adjusted.R'), str(raw), str(out),
           str(a.lib.resolve()) if a.lib else '']
    env = os.environ.copy()
    env.update({'OMP_NUM_THREADS': '1', 'OPENBLAS_NUM_THREADS': '1', 'MKL_NUM_THREADS': '1'})
    metadata = {'status': 'REPRODUCTION_NEW', 'started_utc': datetime.now(timezone.utc).isoformat(),
                'launcher_argv': sys.argv, 'R_argv': cmd, 'python': sys.version, 'platform': platform.platform(),
                'numerical_threads': {k: env[k] for k in ('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS')}}
    (prov / 'actual_command.json').write_text(json.dumps(metadata, indent=2) + '\n')
    with (prov / 'execution.log').open('w', encoding='utf-8') as log:
        proc = subprocess.run(cmd, stdout=log, stderr=subprocess.STDOUT, env=env)
    metadata['fit_exit_code'] = proc.returncode
    if proc.returncode == 0 and a.baseline:
        compare_cmd = [a.rscript, '--vanilla', str(code / 'compare_adjusted.R'), str(out), str(a.baseline.resolve(strict=True))]
        metadata['comparison_argv'] = compare_cmd
        with (prov / 'comparison_execution.log').open('w', encoding='utf-8') as log:
            comparison = subprocess.run(compare_cmd, stdout=log, stderr=subprocess.STDOUT, env=env)
        metadata['comparison_exit_code'] = comparison.returncode
    metadata['finished_utc'] = datetime.now(timezone.utc).isoformat()
    # Demonstrate original raw files and source code were not mutated by the run.
    metadata['all_inputs_unchanged'] = all(sha(Path(x['path'])) == x['sha256'] for x in manifest)
    (prov / 'actual_command.json').write_text(json.dumps(metadata, indent=2) + '\n')
    output_manifest = [{'path': str(x.relative_to(out)), 'bytes': x.stat().st_size, 'sha256': sha(x)}
                       for x in sorted(out.rglob('*')) if x.is_file() and x.name != 'output_manifest.csv']
    with (prov / 'output_manifest.csv').open('w', newline='', encoding='utf-8') as f:
        w = csv.DictWriter(f, fieldnames=['path','bytes','sha256']); w.writeheader(); w.writerows(output_manifest)
    print(json.dumps(metadata, indent=2))
    return max(proc.returncode, metadata.get('comparison_exit_code', 0), 0 if metadata['all_inputs_unchanged'] else 1)


if __name__ == '__main__':
    raise SystemExit(main())
