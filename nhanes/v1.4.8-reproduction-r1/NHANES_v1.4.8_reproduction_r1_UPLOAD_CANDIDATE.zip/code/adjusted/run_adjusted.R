# REPRODUCTION_NEW. Scientific inputs: only DEMO_F/ARQ_F/DPQ_F/PAQ_F XPT.
# Reuses byte-identical pure coding and numerical functions; production entry,
# production lock, historical RDS inputs, and historical output writers are not run.
args <- commandArgs(trailingOnly=TRUE)
stopifnot(length(args)==3L)
raw_dir <- normalizePath(args[1],winslash='/',mustWork=TRUE)
out <- normalizePath(args[2],winslash='/',mustWork=TRUE)
if(nzchar(args[3])) .libPaths(c(normalizePath(args[3],winslash='/',mustWork=TRUE),.libPaths()))
script_arg <- grep('^--file=',commandArgs(),value=TRUE)
code <- dirname(normalizePath(sub('^--file=','',script_arg[1]),winslash='/',mustWork=TRUE))
suppressPackageStartupMessages(library(survey))
options(survey.lonely.psu='fail',survey.adjust.domain.lonely=FALSE,digits=17)
for(n in c('data','models','audit','environment'))dir.create(file.path(out,n),recursive=TRUE,showWarnings=FALSE)
if(length(list.files(file.path(out,'models'),recursive=TRUE)))stop('Run already contains model output')
writeLines(capture.output(sessionInfo()),file.path(out,'environment/sessionInfo.txt'))
ip<-as.data.frame(installed.packages()[,c('Package','Version','Built','LibPath')],stringsAsFactors=FALSE)
write.csv(ip,file.path(out,'environment/installed_packages.csv'),row.names=FALSE)
writeLines(c(paste('R_HOME',R.home()),paste('libPaths',.libPaths()),paste('commandArgs',paste(commandArgs(),collapse=' | '))),file.path(out,'environment/runtime.txt'))
source(file.path(code,'vendor/01_definitions.R'))
source(file.path(code,'vendor/01_derive_candidate.R'))
source(file.path(code,'vendor/02_estimator_core.R'))
source(file.path(code,'vendor/05_result_export.R'))
utc<-function()format(Sys.time(),'%Y-%m-%dT%H:%M:%OS6Z',tz='UTC')
wcsv<-function(x,path)write.csv(x,file.path(out,path),row.names=FALSE,na='NA')
cat('REPRODUCTION_NEW raw-XPT reconstruction started ',utc(),'\n')
mods<-c('DEMO_F','ARQ_F','DPQ_F','PAQ_F')
raw<-setNames(lapply(mods,function(m)foreign::read.xport(file.path(raw_dir,paste0(m,'.xpt')))),mods)
inventory<-do.call(rbind,lapply(mods,function(m)data.frame(module=m,n=nrow(raw[[m]]),fields=ncol(raw[[m]]),unique_SEQN=length(unique(raw[[m]]$SEQN)),missing_SEQN=sum(is.na(raw[[m]]$SEQN)),duplicate_SEQN=sum(duplicated(raw[[m]]$SEQN)))))
stopifnot(all(inventory$missing_SEQN==0),all(inventory$duplicate_SEQN==0))
wcsv(inventory,'audit/raw_inventory.csv')
d<-raw$DEMO_F
joinlog<-data.frame(module='DEMO_F',before=nrow(d),after=nrow(d),matched=nrow(d),demo_without_module=0,module_without_demo=0)
for(m in mods[-1]){
 x<-raw[[m]];stopifnot(identical(intersect(names(d),names(x)),'SEQN'))
 ix<-match(d$SEQN,x$SEQN);before<-nrow(d)
 d<-cbind(d,x[ix,setdiff(names(x),'SEQN'),drop=FALSE]);d[[paste0('in_',m)]]<-!is.na(ix)
 joinlog<-rbind(joinlog,data.frame(module=m,before=before,after=nrow(d),matched=sum(!is.na(ix)),demo_without_module=sum(is.na(ix)),module_without_demo=sum(!x$SEQN%in%d$SEQN)))
}
stopifnot(nrow(d)==nrow(raw$DEMO_F),!anyDuplicated(d$SEQN))
wcsv(joinlog,'audit/left_join_log.csv')
# Exact Phase 1 derivation statements, followed by pure Phase 1B definition.
d$eligible_age<-d$RIDAGEYR>=20&d$RIDAGEYR<=69
d$age_band<-ifelse(d$RIDAGEYR<18,'00_17',ifelse(d$RIDAGEYR<20,'18_19',ifelse(d$RIDAGEYR<=69,'20_69','70_plus')))
d$module_pattern<-paste(as.integer(d$in_ARQ_F),as.integer(d$in_DPQ_F),as.integer(d$in_PAQ_F),sep='')
d$state<-lumbar_state(d);d$state[!d$eligible_age]<-'OUTSIDE_ARQ_AGE';d$state<-factor(d$state,levels=state_levels)
d$DPQ010_clean<-dpq_score(d$DPQ010);d$DPQ020_clean<-dpq_score(d$DPQ020)
d$A<-ifelse(is.na(d$DPQ010_clean),NA_integer_,as.integer(d$DPQ010_clean>=1))
d$A_high<-ifelse(is.na(d$DPQ010_clean),NA_integer_,as.integer(d$DPQ010_clean>=2))
d$Y<-activity_nonparticipation(d$PAQ650,d$PAQ665)
d$G<-ifelse(d$state=='S3_current_with_3mo_history',1L,ifelse(d$state=='S1_former_qualifying_symptoms',0L,NA_integer_))
d$age10<-(d$RIDAGEYR-45)/10
d$sex<-factor(d$RIAGENDR,levels=1:2);d$race<-factor(d$RIDRETH1,levels=1:5)
d$education<-factor(ifelse(d$DMDEDUC2%in%1:2,'less_HS',ifelse(d$DMDEDUC2==3,'HS_GED',ifelse(d$DMDEDUC2%in%4:5,'above_HS',NA))),levels=c('less_HS','HS_GED','above_HS'))
d$PIR<-ifelse(!is.na(d$INDFMPIR)&d$INDFMPIR>=0&d$INDFMPIR<=5,d$INDFMPIR,NA_real_)
d$marital<-ifelse(d$DMDMARTL%in%1:6,d$DMDMARTL,NA_real_)
d$cov_complete<-complete.cases(d[c('age10','sex','race','education','PIR')])
d$valid_design<-!is.na(d$WTMEC2YR)&d$WTMEC2YR>0&!is.na(d$SDMVSTRA)&!is.na(d$SDMVPSU)
d$core_observed<-!is.na(d$G)&!is.na(d$A)&!is.na(d$Y)
d$strict_core<-d$eligible_age&d$valid_design&d$core_observed;d$strict_cc<-d$strict_core&d$cov_complete
for(v in c('PAQ650','PAQ665'))stopifnot(all(is.na(d[[v]])|d[[v]]%in%c(1,2,7,9)))
for(v in c('DPQ010','DPQ020'))stopifnot(all(is.na(d[[v]])|d[[v]]%in%c(0:3,7,9)))
d<-derive_phase1b(d);d<-d[order(d$SEQN),];rownames(d)<-NULL
stopifnot(sum(d$valid_design)==10253L,sum(d$domain_core)==4052L,sum(d$domain)==3687L,sum(d$domain_D)==3686L)
saveRDS(d,file.path(out,'data/phase2a_audit_data.rds'),compress='xz')
names_input<-c('SEQN','WTMEC2YR','SDMVSTRA','SDMVPSU','domain','domain_D','A','G','age10','sex','race','education','PIR','D','A_high')
inputs<-d[d$valid_design,names_input];rownames(inputs)<-NULL
outcome<-list(SEQN=inputs$SEQN,response=d$Y[d$valid_design],label='RESEARCH',synthetic_only=FALSE)
saveRDS(inputs,file.path(out,'data/design_inputs.rds'))
saveRDS(outcome,file.path(out,'data/research_outcome.rds'))
wcsv(data.frame(SEQN=inputs$SEQN,inputs[setdiff(names(inputs),'SEQN')],Y=outcome$response,check.names=FALSE),'data/analysis_inputs_with_Y.csv')
flow_masks<-list(DEMO_all=rep(TRUE,nrow(d)),age20_69=d$eligible_age,
 four_modules=d$eligible_age&d$in_ARQ_F&d$in_DPQ_F&d$in_PAQ_F,
 positive_MEC=d$eligible_age&d$in_ARQ_F&d$in_DPQ_F&d$in_PAQ_F&d$valid_design)
flow_masks$candidate_S3_S0<-flow_masks$positive_MEC&d$candidate
flow_masks$A_known<-flow_masks$candidate_S3_S0&!is.na(d$A)
flow_masks$Y_known_core<-flow_masks$A_known&!is.na(d$Y)
flow_masks$covariate_complete<-flow_masks$Y_known_core&d$cov_complete
flow_masks$D_known<-flow_masks$covariate_complete&!is.na(d$D)
wcsv(data.frame(stage=names(flow_masks),n=vapply(flow_masks,sum,numeric(1))),'audit/input_flow.csv')
stopifnot(identical(flow_masks$covariate_complete,d$domain),identical(flow_masks$D_known,d$domain_D))
saveRDS(list(artifact_status='REPRODUCTION_NEW',D_BASE=inputs[inputs$domain_D,c('SEQN','WTMEC2YR','age10','sex','race','education','PIR','D')],D_PLUS=inputs[inputs$domain_D,c('SEQN','WTMEC2YR','age10','sex','race','education','PIR','D')]),file.path(out,'data/D_common_reference_inputs.rds'))
rm(raw);gc()
# Capture instrumentation adds on.exit observers around two original function
# bodies. Original arithmetic, checks, convergence limits, CI rules and returns
# are left unchanged. Source bytes and hook source are hashed by the launcher.
capture_state<-new.env(parent=emptyenv())
capture_state$folder<-NULL;capture_state$fit_rows<-list()
capture_fit<-function(e){
 get_local<-function(n)if(exists(n,envir=e,inherits=FALSE))get(n,envir=e,inherits=FALSE)else NULL
 label<-get_local('label');fit<-get_local('fit');pred<-get_local('pred')
 if(is.null(fit))return(invisible(NULL))
 dat<-list(artifact_status='REPRODUCTION_NEW',model_id=capture_state$model_id,label=label,
 SEQN=capture_state$SEQN,weights=get_local('w'),active=get_local('active'),
 fit=fit,scenario_predictions=pred,scenario_names=c('P00','P10','P01','P11'),
 warnings=get_local('warns'),response=get_local('response'),
 numerical_engine='byte-identical vendor/02_estimator_core.R with on.exit capture hooks')
 saveRDS(dat,file.path(capture_state$folder,'fits',paste0(label,'.rds')),compress='gzip')
 capture_state$fit_rows[[label]]<-data.frame(model_id=capture_state$model_id,replicate=label,
 parameter=names(fit$coefficients),coefficient=unname(fit$coefficients),artifact_status='REPRODUCTION_NEW')
}
original_fit_body<-body(p2_fit_once)
body(p2_fit_once)<-bquote({on.exit(capture_fit(environment()),add=TRUE);.(original_fit_body)})
capture_design<-function(e){
 if(!exists('r',envir=e,inherits=FALSE))return(invisible(NULL))
 z<-get('z',e);domain<-get('domain',e);t<-get('t',e);r<-get('r',e)
 saveRDS(list(artifact_status='REPRODUCTION_NEW',full_Taylor=t,full_replicate=r,
 domain_Taylor=t[domain,],domain_replicate=r[domain,]),file.path(capture_state$folder,'survey_designs.rds'),compress='gzip')
 wr<-as.matrix(weights(r,type='analysis'));colnames(wr)<-sprintf('JKn_%02d',seq_len(ncol(wr)))
 ww<-data.frame(SEQN=z$SEQN,domain=domain,FULL=as.numeric(weights(r,type='sampling')),wr,check.names=FALSE)
 saveRDS(list(artifact_status='REPRODUCTION_NEW',full=ww,domain=ww[domain,],scale=r$scale,rscales=r$rscales,mse=r$mse),file.path(capture_state$folder,'analysis_weights.rds'))
 write.csv(ww,file.path(capture_state$folder,'full_analysis_weights_with_SEQN.csv'),row.names=FALSE)
 write.csv(ww[domain,],file.path(capture_state$folder,'domain_analysis_weights_with_SEQN.csv'),row.names=FALSE)
}
original_design_body<-body(p2_design)
body(p2_design)<-bquote({on.exit(capture_design(environment()),add=TRUE);.(original_design_body)})
writeLines(capture.output(body(p2_fit_once)),file.path(out,'audit/instrumented_fit_body.R.txt'))
writeLines(capture.output(body(p2_design)),file.path(out,'audit/instrumented_design_body.R.txt'))
statuses<-list();all_estimates<-list()
for(mid in p2_model_ids){
 folder<-file.path(out,'models',mid);dir.create(file.path(folder,'fits'),recursive=TRUE)
 capture_state$folder<-folder;capture_state$model_id<-mid;capture_state$fit_rows<-list()
 domain<-if(mid%in%c('D_BASE','D_PLUS'))inputs$domain_D else inputs$domain
 capture_state$SEQN<-inputs$SEQN[domain]
 started<-utc();cat('Begin ',mid,' ',started,'\n');flush.console()
 result<-tryCatch(phase2a_estimate_core(inputs,outcome,mid,synthetic_only=FALSE),error=function(e)e)
 finished<-utc()
 if(inherits(result,'error')){
  saveRDS(result,file.path(folder,'REPRODUCTION_FAILURE.rds'))
  p2_export_failure(mid,conditionMessage(result),folder,result_type='REPRODUCTION_NEW',error=result)
  status<-'FAILED';cat('FAILED ',mid,': ',conditionMessage(result),'\n')
 }else{
  result$metadata$artifact_status<-'REPRODUCTION_NEW';result$metadata$raw_XPT_only<-TRUE
  all_estimates[[mid]]<-p2_export_result(result,mid,folder,result_type='REPRODUCTION_NEW',started_utc=started,finished_utc=finished)
  stopifnot(length(capture_state$fit_rows)==32L,length(list.files(file.path(folder,'fits'),pattern='\\.rds$'))==32L)
  write.csv(do.call(rbind,capture_state$fit_rows),file.path(folder,'coefficients_32_fits.csv'),row.names=FALSE)
  status<-'SUCCESS';cat('Completed ',mid,' n=',result$metadata$n,' df=',result$metadata$ci_df,' saved 32 full fit objects and predictions\n')
 }
 statuses[[mid]]<-data.frame(model_id=mid,status=status,artifact_status='REPRODUCTION_NEW',started_utc=started,finished_utc=finished)
 wcsv(do.call(rbind,statuses),'audit/branch_status.csv')
 rm(result);gc()
}
if(length(all_estimates))wcsv(do.call(rbind,all_estimates),'all_28_estimates.csv')
stopifnot(all(vapply(statuses,function(x)x$status=='SUCCESS',logical(1))))
writeLines(c('REPRODUCTION_NEW','All four branches completed; every branch retained 1 full fit + 31 JKn fits.',
 'Scientific inputs were four XPT modules only. Historical references have not been read by this script.'),file.path(out,'FIT_SUCCESS.txt'))
cat('Completed ',utc(),'\n')
