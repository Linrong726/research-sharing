# Export only: no fitting, no historical object reads. RDS -> 17-digit + hex CSV.
# Usage: Rscript --vanilla export_exact_adjusted.R NEW_RUN NEW_EMPTY_EXPORT_OUT
args<-commandArgs(trailingOnly=TRUE);stopifnot(length(args)==2L)
run<-normalizePath(args[1],winslash='/',mustWork=TRUE)
out<-args[2]
if(dir.exists(out)&&length(list.files(out,all.files=TRUE,no..=TRUE)))stop('Export directory must be new or empty')
dir.create(out,recursive=TRUE,showWarnings=FALSE)
stopifnot(file.exists(file.path(run,'FIT_SUCCESS.txt')))
num17<-function(x)sprintf('%.17g',x)
numhex<-function(x)sprintf('%a',x)
exact<-list();ci_all<-list();roundtrip<-list()
for(mid in c('MAIN','D_BASE','D_PLUS','A_HIGH')){
 r<-readRDS(file.path(run,'models',mid,'complete_result.rds'))
 folder<-file.path(out,mid);dir.create(folder)
 stopifnot(identical(r$metadata$artifact_status,'REPRODUCTION_NEW'))
 add<-function(object,x,row_label=NULL,column_label=NULL){
  if(is.null(dim(x))){nr<-length(x);nc<-1L;vals<-as.vector(x);ri<-seq_len(nr);cj<-rep(1L,nr)
   if(is.null(row_label))row_label<-names(x)
   if(is.null(column_label))column_label<-'value'
  }else{nr<-nrow(x);nc<-ncol(x);vals<-as.vector(x);ri<-rep(seq_len(nr),times=nc);cj<-rep(seq_len(nc),each=nr)
   if(is.null(row_label))row_label<-rownames(x)
   if(is.null(column_label))column_label<-colnames(x)
  }
  if(is.null(row_label))row_label<-as.character(seq_len(nr))
  if(is.null(column_label))column_label<-as.character(seq_len(nc))
  ans<-data.frame(artifact_status='REPRODUCTION_NEW',model_id=mid,object=object,row_index=ri,column_index=cj,
   row_label=row_label[ri],column_label=column_label[cj],decimal17=num17(vals),hex=numhex(vals),stringsAsFactors=FALSE)
  exact[[length(exact)+1L]]<<-ans
  write.csv(ans,file.path(folder,paste0(object,'_exact.csv')),row.names=FALSE,na='NA')
  roundtrip[[length(roundtrip)+1L]]<<-data.frame(model_id=mid,object=object,n=length(vals),decimal17_identical=identical(as.numeric(ans$decimal17),vals),hex_identical=identical(as.numeric(ans$hex),vals))
 }
 add('estimate',r$estimate)
 ci_matrix<-as.matrix(r$ci[c('estimate','se','lower','upper')]);rownames(ci_matrix)<-r$ci$estimand
 add('ci',ci_matrix)
 add('replicates31x7',r$replicates,row_label=paste0('JKn_',1:31))
 add('covariance7x7',r$covariance)
 add('probability_logit_covariance4x4',r$probability_logit_covariance)
 # A convenient wide, 17-digit and hex version of all 28 intervals.
 ci<-data.frame(artifact_status='REPRODUCTION_NEW',model_id=mid,estimand=r$ci$estimand,n=r$metadata$n,ci_df=r$metadata$ci_df,interval=r$ci$interval,unit='probability')
 for(f in c('estimate','se','lower','upper')){
  ci[[paste0(f,'_decimal17')]]<-num17(r$ci[[f]])
  ci[[paste0(f,'_hex')]]<-numhex(r$ci[[f]])
 }
 ci_all[[mid]]<-ci
}
tab<-do.call(rbind,exact);checks<-do.call(rbind,roundtrip)
write.csv(tab,file.path(out,'all_numeric_values_exact.csv'),row.names=FALSE,na='NA')
write.csv(do.call(rbind,ci_all),file.path(out,'all_28_estimates_CIs_exact.csv'),row.names=FALSE,na='NA')
write.csv(checks,file.path(out,'exact_roundtrip_checks.csv'),row.names=FALSE)
stopifnot(all(checks$decimal17_identical),all(checks$hex_identical))
writeLines(c('REPRODUCTION_NEW','Only new complete_result.rds files were read.',
 'decimal17 uses sprintf("%.17g"); hex uses sprintf("%a").',
 'Each exported decimal and hex value was parsed back and required to be identical to the source double.',
 'Long-form matrix cells are indexed with row_index, column_index, row_label and column_label; no flattening-order inference is required.'),file.path(out,'README.txt'))
writeLines(capture.output(sessionInfo()),file.path(out,'sessionInfo.txt'))
cat(nrow(tab),'numeric values exported; all decimal17 and hex roundtrips exact.\n')
